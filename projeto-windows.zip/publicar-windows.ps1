﻿# Publicar Windows - Vetor Play Online
# Envia o projeto para o GitHub, espera o instalador ser gerado e salva o VetorPlayOnline-Setup.exe nesta pasta.
# (Mensagens sem acento de proposito, para aparecerem certas em qualquer Windows.)

$Repo = 'vetorplayonline-collab/Vetor-Play-Online'   # usuario/repositorio no GitHub
$Workflow = 'build-windows.yml'
$WorkflowPath = '.github/workflows/build-windows.yml'

$ErrorActionPreference = 'Continue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Step($t) { Write-Host ''; Write-Host "=== $t ===" -ForegroundColor Yellow }
function Fail($t) { Write-Host ''; Write-Host "ERRO: $t" -ForegroundColor Red; Write-Host 'Tire um print desta tela e envie ao Claude.'; exit 1 }

function Find-Gh {
  $c = Get-Command gh -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  foreach ($p in @("$env:ProgramFiles\GitHub CLI\gh.exe", "${env:ProgramFiles(x86)}\GitHub CLI\gh.exe", "$env:LOCALAPPDATA\Programs\GitHub CLI\gh.exe")) {
    if ($p -and (Test-Path $p)) { return $p }
  }
  return $null
}

# Envia (cria ou atualiza) um arquivo no repositorio. Retorna o commit ou $null.
function Put-RepoFile($repoPath, $bytes, $message) {
  $sha = (& $gh api "repos/$Repo/contents/$repoPath" --jq '.sha' 2> $null)
  $body = @{ message = $message; content = [Convert]::ToBase64String($bytes); branch = 'main' }
  if ($LASTEXITCODE -eq 0 -and $sha) { $body.sha = "$sha".Trim() }
  $bodyFile = Join-Path $env:TEMP 'vetor-publicar-win.json'
  ($body | ConvertTo-Json -Compress) | Set-Content -Path $bodyFile -Encoding ASCII
  $commit = (& $gh api -X PUT "repos/$Repo/contents/$repoPath" --input $bodyFile --jq '.commit.sha' 2> $null)
  $ok = ($LASTEXITCODE -eq 0)
  Remove-Item $bodyFile -Force -ErrorAction SilentlyContinue
  if ($ok -and $commit) { return "$commit".Trim() }
  return $null
}

# 1) GitHub CLI
Step 'Conferindo o GitHub CLI'
$gh = Find-Gh
if (-not $gh) {
  Write-Host 'Instalando o GitHub CLI (so na primeira vez)...'
  winget install --id GitHub.cli -e --accept-source-agreements --accept-package-agreements | Out-Host
  $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
  $gh = Find-Gh
  if (-not $gh) { Fail 'Nao consegui instalar o GitHub CLI. Instale em https://cli.github.com e rode de novo.' }
}
Write-Host "OK: $gh"

# 2) Login
Step 'Login no GitHub'
& $gh auth status -h github.com *> $null
if ($LASTEXITCODE -ne 0) {
  Write-Host 'Vai abrir o navegador: copie o codigo que aparece aqui e confirme no GitHub.'
  & $gh auth login -h github.com -p https -w -s workflow
  & $gh auth status -h github.com *> $null
  if ($LASTEXITCODE -ne 0) { Fail 'Login no GitHub nao foi concluido.' }
}
Write-Host 'OK: conectado.'

# 3) Receita de compilacao do Windows no GitHub (so muda quando o arquivo muda)
Step 'Conferindo a receita do instalador no GitHub'
$wfLocal = Join-Path $Root '.github\workflows\build-windows.yml'
if (-not (Test-Path $wfLocal)) { Fail 'Nao achei .github\workflows\build-windows.yml nesta pasta.' }
$wfBytes = [IO.File]::ReadAllBytes($wfLocal)
$remote = (& $gh api "repos/$Repo/contents/$WorkflowPath" --jq '.content' 2> $null)
$same = $false
if ($LASTEXITCODE -eq 0 -and $remote) {
  try { $same = ([Convert]::ToBase64String([Convert]::FromBase64String(("$remote" -replace '\s', ''))) -eq [Convert]::ToBase64String($wfBytes)) } catch { }
}
if (-not $same) {
  $c = Put-RepoFile $WorkflowPath $wfBytes 'Receita do instalador Windows'
  if (-not $c) {
    Write-Host 'O GitHub pediu uma permissao extra (workflow). Vai abrir o navegador uma vez para liberar.'
    & $gh auth refresh -h github.com -s workflow
    $c = Put-RepoFile $WorkflowPath $wfBytes 'Receita do instalador Windows'
    if (-not $c) { Fail 'Nao consegui enviar a receita do instalador para o GitHub.' }
  }
  Write-Host 'OK: receita enviada.'
  Start-Sleep -Seconds 3
} else { Write-Host 'OK: receita ja esta no GitHub.' }

# 4) Compactar o projeto
Step 'Compactando o projeto'
$zip = Join-Path $env:TEMP 'projeto-windows.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$skipDirs = @('node_modules', 'dist', 'vendor', '.git')
$files = Get-ChildItem -Path $Root -Recurse -File -Force | Where-Object {
  $rel = $_.FullName.Substring($Root.Length).TrimStart('\')
  $parts = $rel.Split('\')
  -not ($parts | Where-Object { $skipDirs -contains $_ }) -and $_.Extension -ne '.exe'
}
$fs = [IO.File]::Open($zip, [IO.FileMode]::Create)
$za = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
foreach ($f in $files) {
  $rel = $f.FullName.Substring($Root.Length).TrimStart('\').Replace('\', '/')
  $entry = $za.CreateEntry($rel, [IO.Compression.CompressionLevel]::Optimal)
  $in = [IO.File]::OpenRead($f.FullName)
  $out = $entry.Open()
  $in.CopyTo($out)
  $out.Dispose(); $in.Dispose()
}
$za.Dispose(); $fs.Dispose()
if (-not (Test-Path $zip)) { Fail 'Nao consegui compactar o projeto.' }
Write-Host ('OK: {0:N1} MB' -f ((Get-Item $zip).Length / 1MB))

# 5) Enviar para o GitHub
Step 'Enviando para o GitHub'
$commit = Put-RepoFile 'projeto-windows.zip' ([IO.File]::ReadAllBytes($zip)) ('Atualiza Windows ' + (Get-Date -Format 'dd/MM/yyyy HH:mm'))
if (-not $commit) { Fail 'O GitHub recusou o envio do projeto.' }
Write-Host "OK: enviado (commit $($commit.Substring(0,7)))."

# 6) Esperar o GitHub comecar a compilar
Step 'Esperando o GitHub comecar a gerar o instalador'
$runId = $null
for ($i = 0; $i -lt 18 -and -not $runId; $i++) {
  Start-Sleep -Seconds 5
  $runs = (& $gh run list -R $Repo --workflow $Workflow -L 10 --json databaseId,headSha) | ConvertFrom-Json
  $match = $runs | Where-Object { $_.headSha -eq $commit } | Select-Object -First 1
  if ($match) { $runId = $match.databaseId }
}
if (-not $runId) {
  Write-Host 'Iniciando a geracao manualmente...'
  & $gh workflow run $Workflow -R $Repo --ref main
  Start-Sleep -Seconds 8
  $runs = (& $gh run list -R $Repo --workflow $Workflow -L 1 --json databaseId) | ConvertFrom-Json
  if ($runs) { $runId = $runs[0].databaseId }
}
if (-not $runId) { Fail 'O GitHub nao iniciou a geracao do instalador.' }
Write-Host "OK: geracao #$runId iniciada. Leva uns 5 a 10 minutos..."

# 7) Acompanhar
Step 'Gerando o instalador (pode deixar rodando)'
& $gh run watch $runId -R $Repo --exit-status --interval 15
if ($LASTEXITCODE -ne 0) {
  Write-Host ''
  Write-Host 'Ultimas linhas do erro:' -ForegroundColor Red
  & $gh run view $runId -R $Repo --log-failed | Select-Object -Last 40
  Fail 'A geracao do instalador falhou.'
}

# 8) Baixar o instalador
Step 'Baixando o instalador'
$out = Join-Path $env:TEMP "vetor-win-$runId"
if (Test-Path $out) { Remove-Item $out -Recurse -Force }
& $gh run download $runId -R $Repo -n 'VetorPlayOnline-windows' -D $out
$exe = Get-ChildItem -Path $out -Filter *.exe -Recurse | Select-Object -First 1
if (-not $exe) { Fail 'Nao encontrei o instalador no resultado.' }
$dest = Join-Path $Root 'VetorPlayOnline-Setup.exe'
Copy-Item $exe.FullName $dest -Force

Write-Host ''
Write-Host '============================================================' -ForegroundColor Green
Write-Host ' PRONTO! Instalador gerado:' -ForegroundColor Green
Write-Host " $dest" -ForegroundColor Green
Write-Host ''
Write-Host ' Link fixo para os clientes baixarem:' -ForegroundColor Green
Write-Host " https://github.com/$Repo/releases/download/windows/VetorPlayOnline-Setup.exe" -ForegroundColor Green
Write-Host '============================================================' -ForegroundColor Green
Start-Process explorer.exe "/select,`"$dest`""
