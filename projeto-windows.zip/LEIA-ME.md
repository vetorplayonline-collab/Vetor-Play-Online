# Vetor Play Online — Windows

Versão para computador (Windows 10 e 11) do player Vetor Play Online, com o mesmo visual amarelo e preto do app Android.

## O que tem
- **Ativação pelo MAC e KEY** (mesmo Painel MAC do Gestor). Cada computador tem o seu MAC/KEY, que aparece na tela de entrada e em Configurações.
- Entrada por **Login** (servidor + usuário + senha), **Link M3U** ou **Arquivo .m3u** do computador
- **Início** com o cartão **Seu sinal** (vencimento + WhatsApp de renovação), Continuar assistindo, Favoritos e lançamentos
- **TV ao Vivo**, **Filmes** e **Séries** (temporadas e episódios), **Busca** que ignora acentos, botão **A–Z**
- **Data e hora** no topo e dentro do player
- Player com troca de canal (↑ ↓), avançar/voltar (← →), tela cheia (F ou duplo clique), lista de canais (L),
  áudio, legendas, ajuste de tela, volume, continuar de onde parou e reconexão automática
- **Controle dos pais**: categorias adultas bloqueadas com PIN (padrão **0000**)
- Aviso automático quando sai versão nova

## Como gerar o instalador (PUBLICAR_WINDOWS.bat)
1. Deixe esta pasta **VetorPlayOnline-Windows** ao lado da pasta do app Android (não precisa, mas fica organizado).
2. Dê dois cliques em **PUBLICAR_WINDOWS.bat**.
3. Na primeira vez, o GitHub pode abrir o navegador pedindo uma permissão a mais (**workflow**). Confirme.
4. Espere de 5 a 10 minutos. O **VetorPlayOnline-Setup.exe** aparece nesta pasta.

Não usa a chave do Android. A versão Windows fica numa página separada do GitHub e **não atrapalha** a atualização do APK.

**Link fixo para os clientes baixarem** (sempre a versão mais nova):
https://github.com/vetorplayonline-collab/Vetor-Play-Online/releases/download/windows/VetorPlayOnline-Setup.exe

## Instalar no computador do cliente
Abra o **VetorPlayOnline-Setup.exe**. Como o instalador não tem certificado pago, o Windows pode mostrar
"O Windows protegeu o computador": clique em **Mais informações › Executar assim mesmo**.
Para atualizar, é só instalar a versão nova por cima: as listas e favoritos continuam salvos.

## Personalizar
Arquivo `src/app.js`, no começo (`CONFIG`):
- `DEFAULT_SERVER` — seu DNS. Preenchido, o campo Servidor some e o cliente só digita usuário e senha.
- `WHATSAPP` / `WHATSAPP_SHOW` — WhatsApp da Vetor Play Online.

Logo: `src/logo.png` (tela) e `build/icon.ico` / `build/icon.png` (ícone do programa).

## Limitações do Windows
Canais e filmes em H.264/AAC (a maioria) tocam normalmente. Alguns filmes .mkv com áudio **AC3/DTS** podem abrir sem som,
e vídeos **HEVC/H.265** dependem da placa de vídeo do computador.
