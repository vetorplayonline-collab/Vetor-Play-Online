@echo off
chcp 65001 >nul
title Publicar Windows - Vetor Play Online
cd /d "%~dp0"

if not exist "package.json" (
  echo ERRO: rode este arquivo de dentro da pasta VetorPlayOnline-Windows.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publicar-windows.ps1"
echo.
pause
