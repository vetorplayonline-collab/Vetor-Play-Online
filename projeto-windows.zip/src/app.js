// Vetor Play Online para Windows — telas e player
'use strict';

const CONFIG = {
  /** Seu DNS (ex.: "http://meudns.com:8080"). Preenchido, o campo Servidor some do login. */
  DEFAULT_SERVER: '',
  WHATSAPP: '5544997213054',
  WHATSAPP_SHOW: '(44) 99721-3054',
  REPO: 'vetorplayonline-collab/Vetor-Play-Online',
  RELEASE_TAG: 'windows',
  FIREBASE: 'https://gestor-vetorplayonline-default-rtdb.firebaseio.com',
};

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const show = (el, v = true) => (typeof el === 'string' ? $(el) : el).classList.toggle('hidden', !v);
const fmtTime = (s) => {
  if (!isFinite(s) || s < 0) s = 0;
  s = Math.floor(s);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0');
};
const zapUrl = (text) => `https://wa.me/${CONFIG.WHATSAPP}` + (text ? `?text=${encodeURIComponent(text)}` : '');

// ======================================================================
// Dados salvos no computador
// ======================================================================
const Prefs = {
  get(k, d) { try { const v = localStorage.getItem('vp_' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('vp_' + k, JSON.stringify(v)); } catch (e) { } },
  del(k) { localStorage.removeItem('vp_' + k); },

  playlists() { return this.get('playlists', []); },
  savePlaylists(l) { this.set('playlists', l); },
  addOrUpdate(p) { this.savePlaylists([...this.playlists().filter((x) => x.id !== p.id), p]); },
  remove(id) {
    this.savePlaylists(this.playlists().filter((x) => x.id !== id));
    if (this.activeId === id) this.activeId = (this.playlists()[0] || {}).id || null;
  },
  get activeId() { return this.get('active', null); },
  set activeId(v) { this.set('active', v); },
  active() { const l = this.playlists(); return l.find((p) => p.id === this.activeId) || l[0] || null; },

  favorites() { return this.get('favs_' + this.activeId, []); },
  isFav(k) { return this.favorites().includes(k); },
  toggleFav(k) {
    const f = this.favorites(); const i = f.indexOf(k);
    if (i >= 0) f.splice(i, 1); else f.unshift(k);
    this.set('favs_' + this.activeId, f);
    return i < 0;
  },
  recents() { return this.get('recents_' + this.activeId, []); },
  addRecent(k) { this.set('recents_' + this.activeId, [k, ...this.recents().filter((x) => x !== k)].slice(0, 40)); },
  clearHistory() {
    this.del('recents_' + this.activeId);
    Object.keys(localStorage).filter((k) => k.startsWith('vp_pos_')).forEach((k) => localStorage.removeItem(k));
  },
  posKey(url) { let h = 0; for (let i = 0; i < url.length; i++) h = (h * 31 + url.charCodeAt(i)) | 0; return 'pos_' + h; },
  position(url) { return this.get(this.posKey(url), 0); },
  savePosition(url, p) { if (p > 0) this.set(this.posKey(url), p); else this.del(this.posKey(url)); },

  get pin() { return this.get('pin', '0000'); }, set pin(v) { this.set('pin', v); },
  get adultLock() { return this.get('adultLock', true); }, set adultLock(v) { this.set('adultLock', v); },
  get sortAlpha() { return this.get('sortAlpha', false); }, set sortAlpha(v) { this.set('sortAlpha', v); },
  get volume() { return this.get('volume', 1); }, set volume(v) { this.set('volume', v); },
  get aspect() { return this.get('aspect', 0); }, set aspect(v) { this.set('aspect', v); },
  account(id) { return this.get('account_' + id, null); },
  saveAccount(id, a) { this.set('account_' + id, a); },
};

let unlockedAdult = false; // PIN digitado nesta sessão
const hideAdult = () => Prefs.adultLock && !unlockedAdult;

// ======================================================================
// Ativação por MAC + KEY (mesmo painel do app Android)
// ======================================================================
const Mac = {
  dev: null,
  async device() { if (!this.dev) this.dev = await window.vetor.device(); return this.dev; },
  async docId(mac, key) {
    const data = new TextEncoder().encode(`${mac.toUpperCase().trim()}:${key.trim()}`);
    const h = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
    return [...h].map((b) => b.toString(16).padStart(2, '0')).join('');
  },
  xtreamUrl(server, user, pass) {
    let host = server.trim().replace(/\/+$/, '');
    if (!/^https?:\/\//i.test(host)) host = 'http://' + host;
    return `${host}/get.php?username=${encodeURIComponent(user)}&password=${encodeURIComponent(pass)}&type=m3u_plus&output=ts`;
  },
  /** null = computador ainda não cadastrado no painel */
  async fetch() {
    if (!CONFIG.FIREBASE) return null;
    const { mac, key } = await this.device();
    const id = await this.docId(mac, key);
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
    let res;
    try { res = await fetch(`${CONFIG.FIREBASE.replace(/\/+$/, '')}/devices/${id}.json`, { signal: ctl.signal, cache: 'no-store' }); }
    catch (e) { throw new Error('Sem conexão com o painel da Vetor Play Online.'); }
    finally { clearTimeout(t); }
    if (res.status === 401 || res.status === 403) throw new Error('Acesso ao painel bloqueado (publique as regras do banco do Gestor).');
    if (!res.ok) throw new Error(`Painel respondeu com erro ${res.status}.`);
    const root = await res.json();
    if (!root) return null;
    if (root.active === false) return [];
    let items = [];
    const pls = root.playlists;
    if (Array.isArray(pls)) items = pls.filter(Boolean);
    else if (pls && typeof pls === 'object') items = Object.keys(pls).sort().map((k) => pls[k]).filter(Boolean);
    const out = [];
    items.forEach((f, i) => {
      const s = (k) => String(f[k] ?? '').trim();
      const kind = s('kind') || 'url';
      const name = s('name') || 'Vetor Play Online';
      if (kind === 'xtream') {
        const server = s('server') || CONFIG.DEFAULT_SERVER;
        if (server && s('username')) out.push({ id: 'mac' + i, name, kind: 'xtream', url: this.xtreamUrl(server, s('username'), s('password')), server: server.replace(/\/+$/, ''), username: s('username'), password: s('password') });
      } else {
        const u = s('url');
        if (u.startsWith('http')) out.push({ id: 'mac' + i, name, kind: 'url', url: u });
      }
    });
    return out;
  },
  /** Aplica as listas do painel. Retorna quantas vieram (null = não cadastrado). */
  async sync() {
    const remote = await this.fetch();
    if (remote == null) return null;
    const local = Prefs.playlists().filter((p) => p.id.startsWith('mac'));
    for (const l of local) if (!remote.some((r) => r.id === l.id)) { Prefs.remove(l.id); await window.vetor.deleteCache(l.id); }
    for (const r of remote) {
      const old = local.find((l) => l.id === r.id);
      if (old && old.url !== r.url) await window.vetor.deleteCache(r.id);
      Prefs.addOrUpdate(r);
    }
    if (!Prefs.active() || !Prefs.playlists().some((p) => p.id === Prefs.activeId)) {
      Prefs.activeId = (remote[0] || Prefs.playlists()[0] || {}).id || null;
    }
    return remote.length;
  },
};

// ======================================================================
// Vencimento do sinal (painel Xtream)
// ======================================================================
const Account = {
  creds(p) {
    if (p.kind === 'xtream' && p.server && p.username) return { server: p.server.replace(/\/+$/, ''), user: p.username, pass: p.password };
    if (p.kind === 'url') {
      try {
        const u = new URL(p.url);
        const user = u.searchParams.get('username'), pass = u.searchParams.get('password');
        if (user && pass != null) return { server: `${u.protocol}//${u.host}`, user, pass };
      } catch (e) { }
    }
    return null;
  },
  async fetch(p) {
    const c = this.creds(p); if (!c) return null;
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 20000);
    try {
      const r = await fetch(`${c.server}/player_api.php?username=${encodeURIComponent(c.user)}&password=${encodeURIComponent(c.pass)}`, { signal: ctl.signal, cache: 'no-store' });
      if (!r.ok) return null;
      const ui = (await r.json()).user_info; if (!ui) return null;
      const exp = parseInt(ui.exp_date, 10);
      return { exp: exp > 0 ? exp * 1000 : null, status: String(ui.status || ''), max: String(ui.max_connections ?? ''), active: String(ui.active_cons ?? ''), at: Date.now() };
    } catch (e) { return null; } finally { clearTimeout(t); }
  },
};

// ======================================================================
// Carregar a lista
// ======================================================================
const Loader = {
  async load(pl, force, onStatus = () => { }) {
    if (pl.kind !== 'file' && (force || !(await window.vetor.hasCache(pl.id)))) {
      onStatus('Baixando sua lista…');
      const r = await window.vetor.download(pl.id, pl.url);
      if (!r.ok) throw new Error(r.error);
    }
    onStatus('Organizando canais, filmes e séries…');
    await sleep(30);
    const r = await window.vetor.readCache(pl.id);
    if (!r.ok) throw new Error(r.error);
    const list = M3U.parse(r.text);
    if (!list.length) throw new Error('A lista está vazia ou não é uma lista M3U válida.');
    Repo.index(list, pl.id);
    return list.length;
  },
  /** Carrega mostrando uma janelinha de espera. */
  async withDialog(pl, force) {
    const box = openModal(`<h3>Aguarde</h3><p id="ldMsg" class="muted">Carregando…</p><div class="progress" id="ldBar"><div></div></div>`, { small: true, locked: true });
    try {
      const n = await this.load(pl, force, (m) => { const e = $('#ldMsg', box); if (e) e.textContent = m; });
      closeModal();
      return n;
    } catch (e) { closeModal(); throw e; }
  },
};

window.vetor.onProgress(({ got, total }) => {
  const mb = (got / 1048576).toFixed(1);
  const txt = total ? `Baixando sua lista… ${Math.round(got * 100 / total)}%` : `Baixando sua lista… ${mb} MB`;
  const s = $('#splashStatus'); if (s && !$('#splash').classList.contains('hidden')) s.textContent = txt;
  const m = $('#ldMsg'); if (m) m.textContent = txt;
});

// ======================================================================
// Janela de diálogo e avisos
// ======================================================================
let modalLocked = false;
function openModal(html, { small = false, locked = false } = {}) {
  const box = $('#modalBox');
  box.className = 'modal-box' + (small ? ' small' : '');
  box.innerHTML = html;
  modalLocked = locked;
  show('#modal');
  return box;
}
function closeModal() { show('#modal', false); $('#modalBox').innerHTML = ''; modalLocked = false; }
$('#modal').addEventListener('mousedown', (e) => { if (e.target.id === 'modal' && !modalLocked) closeModal(); });

function confirmBox(title, text, okLabel = 'OK', danger = false) {
  return new Promise((resolve) => {
    const box = openModal(`<h3>${esc(title)}</h3><p class="muted">${esc(text)}</p>
      <div class="modal-actions"><button class="btn" data-a="no">Cancelar</button><button class="btn ${danger ? 'danger' : 'primary'}" data-a="ok">${esc(okLabel)}</button></div>`, { small: true });
    box.onclick = (e) => { const a = e.target.dataset.a; if (a) { closeModal(); resolve(a === 'ok'); } };
  });
}

function askPin(title = 'Digite o PIN') {
  return new Promise((resolve) => {
    const box = openModal(`<h3>${esc(title)}</h3><input class="input" id="pinIn" type="password" maxlength="8" inputmode="numeric" placeholder="PIN">
      <div id="pinErr" class="status error hidden">PIN incorreto</div>
      <div class="modal-actions"><button class="btn" data-a="no">Cancelar</button><button class="btn primary" data-a="ok">Confirmar</button></div>`, { small: true });
    const inp = $('#pinIn', box); inp.focus();
    const done = (ok) => {
      if (!ok) { closeModal(); return resolve(false); }
      if (inp.value === Prefs.pin) { closeModal(); resolve(true); } else { show($('#pinErr', box)); inp.select(); }
    };
    inp.onkeydown = (e) => { if (e.key === 'Enter') done(true); };
    box.onclick = (e) => { const a = e.target.dataset.a; if (a) done(a === 'ok'); };
  });
}

let toastTimer = null;
function toast(msg, action, ms = 3500) {
  const t = $('#toast');
  t.innerHTML = `<span>${esc(msg)}</span>` + (action ? `<button class="btn">${esc(action.label)}</button>` : '');
  if (action) $('button', t).onclick = () => { show(t, false); action.fn(); };
  show(t);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => show(t, false), ms);
}

function friendly(e) {
  const m = (e && e.message) || String(e);
  if (/Failed to fetch|NetworkError|aborted/i.test(m)) return 'Sem conexão com o servidor. Confira a internet e tente de novo.';
  return m;
}

// ======================================================================
// Relógio (data e hora)
// ======================================================================
function tickClock() {
  const d = new Date();
  const time = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const wd = d.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '');
  const date = `${wd}, ${d.toLocaleDateString('pt-BR')}`;
  $('#clockTime').textContent = time; $('#clockDate').textContent = date;
  $('#pClockTime').textContent = time; $('#pClockDate').textContent = date;
}
tickClock();
setTimeout(() => { tickClock(); setInterval(tickClock, 60000); }, (60 - new Date().getSeconds()) * 1000 + 50);

// ======================================================================
// Telas: abertura e entrada
// ======================================================================
function showScreen(id) { ['splash', 'login', 'main'].forEach((s) => show('#' + s, s === id)); }

async function startApp(force = false) {
  showScreen('splash');
  show('#splashError', false); show('#splashProgress');
  $('#splashStatus').textContent = 'Carregando…';
  await sleep(150);
  if (CONFIG.FIREBASE) {
    if (!Prefs.playlists().length) {
      try { await Promise.race([Mac.sync(), sleep(8000)]); } catch (e) { }
    } else {
      Mac.sync().then((n) => { if (n != null && Prefs.active() && Repo.loadedId !== Prefs.active().id) toast('Sua lista foi atualizada pelo painel.', { label: 'Recarregar', fn: () => startApp(true) }, 8000); }).catch(() => { });
    }
  }
  const pl = Prefs.active();
  if (!pl) return openLogin();
  try {
    await Loader.load(pl, force, (m) => { $('#splashStatus').textContent = m; });
    openMain();
  } catch (e) {
    show('#splashProgress', false);
    $('#splashStatus').textContent = friendly(e);
    show('#splashError');
  }
}
$('#btnRetry').onclick = () => startApp(true);
$('#btnOtherList').onclick = () => openLogin();

let loginMode = 'xtream';
async function openLogin() {
  showScreen('login');
  show('#btnLoginBack', Prefs.playlists().length > 0 && Repo.loadedId);
  show('#macCard', !!CONFIG.FIREBASE);
  show('#lblServer', !CONFIG.DEFAULT_SERVER);
  show('#loginError', false); show('#macStatus', false);
  const { mac, key } = await Mac.device();
  $('#macText').textContent = mac; $('#keyText').textContent = key;
}
$('#btnLoginBack').onclick = () => { if (Repo.loadedId) openMain(); };
$('#btnSupport').onclick = () => window.vetor.openExternal(zapUrl());
$('#btnMacZap').onclick = async () => {
  const { mac, key } = await Mac.device();
  window.vetor.openExternal(zapUrl(`Olá! Quero ativar o Vetor Play Online no computador.\nMAC: ${mac}\nKEY: ${key}`));
};
$$('#loginTabs button').forEach((b) => b.onclick = () => {
  loginMode = b.dataset.mode;
  $$('#loginTabs button').forEach((x) => x.classList.toggle('on', x === b));
  show('#boxXtream', loginMode === 'xtream'); show('#boxUrl', loginMode === 'url'); show('#boxFile', loginMode === 'file');
  $('#btnEnter').textContent = loginMode === 'file' ? 'Escolher arquivo e entrar' : 'Entrar';
});

$('#btnMacSync').onclick = async () => {
  const btn = $('#btnMacSync'), st = $('#macStatus');
  btn.disabled = true; show(st); st.className = 'status'; st.textContent = 'Procurando sua lista…';
  try {
    const n = await Mac.sync();
    if (n == null) st.textContent = 'Computador ainda não cadastrado.\nEnvie o MAC e a KEY para a Vetor Play Online e tente de novo.';
    else if (n === 0) st.textContent = 'Nenhuma lista ativa para este computador. Fale com a Vetor Play Online.';
    else {
      st.className = 'status ok'; st.textContent = `${n} lista(s) encontrada(s)!`;
      const pl = Prefs.active();
      await Loader.withDialog(pl, false);
      openMain();
    }
  } catch (e) { st.className = 'status error'; st.textContent = friendly(e); }
  finally { btn.disabled = false; }
};

function loginError(msg) { const e = $('#loginError'); e.textContent = msg; show(e); }

$('#btnEnter').onclick = async () => {
  show('#loginError', false);
  const id = Math.random().toString(36).slice(2, 10);
  const title = $('#inName').value.trim();
  let pl;
  if (loginMode === 'xtream') {
    let host = (CONFIG.DEFAULT_SERVER || $('#inServer').value).trim().replace(/\/+$/, '');
    const u = $('#inUser').value.trim(), p = $('#inPass').value.trim();
    if (!host) return loginError('Informe o servidor (DNS).');
    if (!u) return loginError('Informe o usuário.');
    if (!p) return loginError('Informe a senha.');
    if (!/^https?:\/\//i.test(host)) host = 'http://' + host;
    pl = { id, name: title || u, kind: 'xtream', url: Mac.xtreamUrl(host, u, p), server: host, username: u, password: p };
  } else if (loginMode === 'url') {
    const url = $('#inUrl').value.trim();
    if (!/^https?:\/\//i.test(url)) return loginError('Cole o link completo, começando com http:// ou https://');
    pl = { id, name: title || 'Minha lista', kind: 'url', url };
  } else {
    const r = await window.vetor.importFile(id);
    if (r.canceled) return;
    if (!r.ok) return loginError(r.error);
    pl = { id, name: title || r.name || 'Lista do computador', kind: 'file', url: r.name || '' };
  }
  const previous = Prefs.activeId;
  Prefs.addOrUpdate(pl); Prefs.activeId = pl.id;
  try {
    const n = await Loader.withDialog(pl, pl.kind !== 'file');
    toast(`${n.toLocaleString('pt-BR')} itens carregados`);
    ['inName', 'inUser', 'inPass', 'inUrl'].forEach((k) => { $('#' + k).value = ''; });
    openMain();
  } catch (e) {
    Prefs.remove(pl.id); await window.vetor.deleteCache(pl.id); Prefs.activeId = previous;
    loginError(friendly(e));
  }
};

// ======================================================================
// Tela principal
// ======================================================================
let currentView = 'home';
const catState = { live: null, movie: null, series: null }; // categoria escolhida em cada aba

function openMain() {
  showScreen('main');
  go(currentView === 'settings' ? 'home' : currentView);
  checkUpdate();
}

$$('#sidebar button').forEach((b) => b.onclick = () => go(b.dataset.view));
$('#btnRefresh').onclick = async () => {
  const pl = Prefs.active(); if (!pl) return;
  try {
    const n = await Loader.withDialog(pl, pl.kind !== 'file');
    toast(`Lista atualizada: ${n.toLocaleString('pt-BR')} itens`);
    go(currentView);
  } catch (e) { toast(friendly(e), null, 6000); }
};
$('#btnSort').onclick = () => { Prefs.sortAlpha = !Prefs.sortAlpha; go(currentView); };

const TITLES = { home: 'Início', live: 'TV ao Vivo', movie: 'Filmes', series: 'Séries', search: 'Buscar', settings: 'Configurações' };
function go(view) {
  currentView = view;
  $$('#sidebar button').forEach((b) => b.classList.toggle('on', b.dataset.view === view));
  $('#pageTitle').textContent = TITLES[view];
  const isCat = view === 'live' || view === 'movie' || view === 'series';
  show('#btnSort', isCat);
  $('#btnSort').classList.toggle('on', Prefs.sortAlpha);
  const v = $('#view'); v.innerHTML = ''; v.scrollTop = 0;
  v.classList.toggle('fixed', isCat);
  if (view === 'home') renderHome(v);
  else if (isCat) renderCatalog(v, view);
  else if (view === 'search') renderSearch(v);
  else renderSettings(v);
}

// ---------- Itens (cartões) ----------
function tileHtml(item, i, wide) {
  const key = Repo.keyOf(item);
  const fav = Prefs.isFav(key);
  const pos = !item.isSeries && item.type !== LIVE ? Prefs.position(item.url) : 0;
  const ic = item.isSeries ? '🎞' : item.type === LIVE ? '📺' : '🎬';
  return `<div class="tile${wide ? ' wide' : ''}" data-i="${i}" title="${esc(item.name)}">
    <div class="pic" ${item.logo ? `style="background-image:url('${esc(item.logo).replace(/'/g, '%27')}')"` : ''}>${item.logo ? '' : ic}</div>
    ${pos > 0 ? '<div class="bar" title="Continuar de onde parou"></div>' : ''}
    <div class="name">${esc(item.name)}</div>
    <button class="fav${fav ? ' on' : ''}" data-fav="${i}" title="Favorito">${fav ? '★' : '☆'}</button>
  </div>`;
}

/** Grade com carregamento aos poucos (listas com milhares de itens). */
function renderGrid(container, items, { wide = false, queue = null } = {}) {
  container.innerHTML = '';
  if (!items.length) { container.innerHTML = '<div class="empty">Nada por aqui.</div>'; return; }
  const grid = document.createElement('div');
  grid.className = 'grid' + (wide ? ' live' : '');
  container.appendChild(grid);
  let shown = 0;
  const sentinel = document.createElement('div'); sentinel.className = 'sentinel';
  container.appendChild(sentinel);
  const more = () => {
    const next = Math.min(items.length, shown + 120);
    let html = '';
    for (let i = shown; i < next; i++) html += tileHtml(items[i], i, wide);
    grid.insertAdjacentHTML('beforeend', html);
    shown = next;
    if (shown >= items.length) { io.disconnect(); sentinel.remove(); }
  };
  const io = new IntersectionObserver((en) => { if (en.some((e) => e.isIntersecting)) more(); }, { root: container.closest('.grid-wrap') || $('#view'), rootMargin: '600px' });
  more();
  if (shown < items.length) io.observe(sentinel);
  bindTiles(grid, items, queue);
}

function bindTiles(root, items, queue) {
  root.addEventListener('click', (e) => {
    const f = e.target.closest('[data-fav]');
    if (f) {
      e.stopPropagation();
      const item = items[+f.dataset.fav];
      const on = Prefs.toggleFav(Repo.keyOf(item));
      f.classList.toggle('on', on); f.textContent = on ? '★' : '☆';
      toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
      return;
    }
    const t = e.target.closest('.tile'); if (!t) return;
    openItem(items[+t.dataset.i], queue || items);
  });
  root.addEventListener('contextmenu', (e) => {
    const t = e.target.closest('.tile'); if (!t) return;
    e.preventDefault();
    $('[data-fav]', t).click();
  });
}

function openItem(item, queue) {
  if (item.isSeries) return openSeries(item);
  const list = item.type === LIVE ? (queue || [item]).filter((x) => x.type === LIVE) : [item];
  Player.open(list, Math.max(0, list.indexOf(item)));
}

// ---------- Início ----------
async function renderHome(v) {
  const pl = Prefs.active();
  const hide = hideAdult();
  const visible = (x) => !(hide && Repo.isAdult(x.group));
  v.innerHTML = `<p class="muted" style="margin:0 0 14px">Lista: <b style="color:var(--text)">${esc(pl ? pl.name : '-')}</b></p>
    <div class="home-top">
      <div class="acc" id="accCard"><h4>SEU SINAL</h4><div class="t">Consultando…</div></div>
      <button class="shortcut" data-go="live"><span class="ic">📺</span><b>TV ao Vivo</b><span>${Repo.count(LIVE).toLocaleString('pt-BR')} canais</span></button>
      <button class="shortcut" data-go="movie"><span class="ic">🎬</span><b>Filmes</b><span>${Repo.count(MOVIE).toLocaleString('pt-BR')} filmes</span></button>
      <button class="shortcut" data-go="series"><span class="ic">🎞</span><b>Séries</b><span>${Repo.count(SERIES).toLocaleString('pt-BR')} séries</span></button>
    </div><div id="homeRows"></div>`;
  $$('[data-go]', v).forEach((b) => b.onclick = () => go(b.dataset.go));

  const rows = [
    ['Continuar assistindo', Repo.itemsForKeys(Prefs.recents()).filter(visible)],
    ['Meus favoritos', Repo.itemsForKeys(Prefs.favorites()).filter(visible)],
    ['Filmes adicionados recentemente', Repo.latest(MOVIE, 30, hide)],
    ['Séries adicionadas recentemente', Repo.latest(SERIES, 30, hide)],
  ];
  const box = $('#homeRows', v);
  for (const [label, items] of rows) {
    if (!items.length) continue;
    const sec = document.createElement('div');
    sec.innerHTML = `<h3 class="row-title">${esc(label)}</h3><div class="hrow">${items.map((x, i) => tileHtml(x, i, false)).join('')}</div>`;
    box.appendChild(sec);
    bindTiles($('.hrow', sec), items, null);
  }
  if (pl) renderAccount($('#accCard', v), pl);
}

async function renderAccount(card, pl) {
  if (!Account.creds(pl)) { card.innerHTML = `<h4>SEU SINAL</h4><div class="t">Lista ativa</div><div class="d">Suporte: WhatsApp ${esc(CONFIG.WHATSAPP_SHOW)}</div><button class="btn zap">Falar no WhatsApp</button>`; bindZap(card); return; }
  const cached = Prefs.account(pl.id);
  if (cached) paintAccount(card, cached, true);
  const fresh = await Account.fetch(pl);
  if (fresh) { Prefs.saveAccount(pl.id, fresh); if (document.body.contains(card)) paintAccount(card, fresh, false); }
  else if (!cached && document.body.contains(card)) card.innerHTML = `<h4>SEU SINAL</h4><div class="t">Não foi possível consultar</div><div class="d">WhatsApp ${esc(CONFIG.WHATSAPP_SHOW)}</div><button class="btn zap">Falar no WhatsApp</button>`, bindZap(card);
}
function bindZap(card) { const b = $('.btn', card); if (b) b.onclick = () => window.vetor.openExternal(zapUrl('Olá! Quero renovar meu sinal da Vetor Play Online.')); }

function paintAccount(card, a, fromCache) {
  const fmt = (ms) => new Date(ms).toLocaleDateString('pt-BR');
  const expired = /expired/i.test(a.status) || (a.exp && a.exp < Date.now());
  const days = a.exp ? Math.floor((a.exp - Date.now()) / 86400000) : null;
  let title, badge, cls = '';
  if (expired) { title = a.exp ? `Venceu em ${fmt(a.exp)}` : 'Sinal vencido'; badge = 'VENCIDO'; cls = 'bad'; }
  else if (!a.exp) { title = 'Sem data de vencimento'; badge = 'ATIVO'; }
  else { title = `Vence em ${fmt(a.exp)}`; badge = days === 0 ? 'HOJE' : days === 1 ? '1 dia' : `${days} dias`; if (days <= 5) cls = 'warn'; }
  const urgent = expired || (days != null && days <= 5);
  const conns = a.max ? `Telas: ${a.active || '0'}/${a.max}` : '';
  const first = urgent ? 'Renove para não ficar sem sinal' : conns;
  const zap = (urgent ? 'Renovação no WhatsApp ' : 'WhatsApp ') + CONFIG.WHATSAPP_SHOW;
  card.innerHTML = `<h4>SEU SINAL</h4><span class="badge ${cls}">${badge}</span><div class="t">${esc(title)}</div>
    <div class="d${urgent ? ' urgent' : ''}">${esc([first, zap].filter(Boolean).join('\n') || (fromCache ? 'Última consulta salva' : 'Atualizado agora'))}</div>
    <button class="btn zap">${urgent ? 'Renovar no WhatsApp' : 'Falar no WhatsApp'}</button>`;
  bindZap(card);
}

// ---------- Catálogo (TV, Filmes, Séries) ----------
const FAV_CAT = '\u0001fav', ALL_CAT = '\u0001all';

function renderCatalog(v, type) {
  const hide = hideAdult();
  const cats = Repo.categories(type);
  const sorted = Prefs.sortAlpha ? [...cats].sort((a, b) => a.localeCompare(b, 'pt-BR')) : cats;
  v.innerHTML = `<div class="catalog"><div class="cats" id="cats"></div>
    <div class="cat-main"><div class="cat-tools"><input class="input" id="catFilter" placeholder="Filtrar nesta categoria…"><span class="count" id="catCount"></span></div>
    <div class="grid-wrap" id="gridWrap"></div></div></div>`;
  const catsEl = $('#cats', v);
  const size = (c) => Repo.items(type, c).length;
  let html = `<button data-c="${ALL_CAT}"><span>Todos</span><small>${Repo.allItems(type, hide).length}</small></button>`;
  html += `<button data-c="${FAV_CAT}"><span>★ Favoritos</span></button>`;
  for (const c of sorted) html += `<button data-c="${esc(c)}"><span>${Repo.isAdult(c) && hide ? '🔒 ' : ''}${esc(c)}</span><small>${size(c)}</small></button>`;
  catsEl.innerHTML = html;

  const pick = async (c, btn) => {
    if (c !== ALL_CAT && c !== FAV_CAT && Repo.isAdult(c) && hideAdult()) {
      if (!(await askPin('Categoria bloqueada — digite o PIN'))) return;
      unlockedAdult = true;
      $$('span', catsEl).forEach((s) => { s.textContent = s.textContent.replace(/^🔒 /, ''); });
    }
    catState[type] = c;
    $$('button', catsEl).forEach((b) => b.classList.toggle('on', b === btn));
    $('#catFilter', v).value = '';
    paint();
  };
  const listFor = (c) => {
    let items;
    if (c === ALL_CAT) items = Repo.allItems(type, hideAdult());
    else if (c === FAV_CAT) {
      const favs = Repo.itemsForKeys(Prefs.favorites());
      items = favs.filter((x) => (type === SERIES ? x.isSeries : !x.isSeries && x.type === type) && !(hideAdult() && Repo.isAdult(x.group)));
    } else items = Repo.items(type, c);
    if (Prefs.sortAlpha) items = [...items].sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
    return items;
  };
  const paint = () => {
    const c = catState[type];
    let items = listFor(c);
    const q = normalize($('#catFilter', v).value.trim());
    if (q) items = items.filter((x) => normalize(x.name).includes(q));
    $('#catCount', v).textContent = `${items.length.toLocaleString('pt-BR')} ${type === LIVE ? 'canais' : type === MOVIE ? 'filmes' : 'séries'}`;
    renderGrid($('#gridWrap', v), items, { wide: type === LIVE, queue: items });
  };
  let ft = null;
  $('#catFilter', v).oninput = () => { clearTimeout(ft); ft = setTimeout(paint, 200); };
  catsEl.onclick = (e) => { const b = e.target.closest('button'); if (b) pick(b.dataset.c, b); };

  // categoria inicial: a última aberta, senão a primeira liberada
  let start = catState[type];
  if (!start || (start !== ALL_CAT && start !== FAV_CAT && !cats.includes(start)) || (Repo.isAdult(start) && hideAdult())) {
    start = sorted.find((c) => !(Repo.isAdult(c) && hide)) || ALL_CAT;
  }
  const btn = $$('button', catsEl).find((b) => b.dataset.c === start);
  catState[type] = start;
  if (btn) { btn.classList.add('on'); setTimeout(() => btn.scrollIntoView({ block: 'nearest' }), 0); }
  paint();
}

// ---------- Séries ----------
function openSeries(sg) {
  const seasons = [...new Set(sg.episodes.map((e) => e.season))];
  const key = 'series:' + sg.name;
  // temporada do último episódio visto
  const lastUrl = Prefs.get('lastEp_' + sg.name, null);
  const lastEp = sg.episodes.find((e) => e.url === lastUrl);
  let season = lastEp ? lastEp.season : seasons[0];
  const box = openModal(`<div class="series-head">
      <div class="poster" ${sg.logo ? `style="background-image:url('${esc(sg.logo).replace(/'/g, '%27')}')"` : ''}></div>
      <div style="flex:1;min-width:0"><h2>${esc(sg.name)}</h2><p class="muted">${esc(sg.group)} · ${sg.episodes.length} episódios</p>
        <button class="btn primary" id="sPlay">${lastEp ? '▶ Continuar ' + epLabel(lastEp) : '▶ Assistir'}</button>
        <button class="btn" id="sFav">${Prefs.isFav(key) ? '★ Favorito' : '☆ Favoritar'}</button>
        <button class="btn ghost" id="sClose">Fechar</button></div></div>
    <div class="seasons" id="sSeasons"></div><div class="eps" id="sEps"></div>`);
  const paint = () => {
    $('#sSeasons', box).innerHTML = seasons.map((s) => `<button class="chip${s === season ? ' on' : ''}" data-s="${s}">${s ? 'Temporada ' + s : 'Episódios'}</button>`).join('');
    const eps = sg.episodes.filter((e) => e.season === season);
    $('#sEps', box).innerHTML = eps.map((e) => {
      const i = sg.episodes.indexOf(e);
      const p = Prefs.position(e.url);
      return `<button class="ep" data-i="${i}"><span class="n">${e.episode ? 'EP ' + e.episode : '▶'}</span><span class="t">${esc(e.name)}</span>${e.url === lastUrl ? '<span class="w">último visto</span>' : p ? `<span class="w">parou em ${fmtTime(p / 1000)}</span>` : ''}</button>`;
    }).join('');
  };
  paint();
  $('#sSeasons', box).onclick = (e) => { const b = e.target.closest('[data-s]'); if (b) { season = +b.dataset.s; paint(); } };
  $('#sEps', box).onclick = (e) => { const b = e.target.closest('[data-i]'); if (b) { closeModal(); Player.open(sg.episodes, +b.dataset.i, sg); } };
  $('#sPlay', box).onclick = () => { closeModal(); Player.open(sg.episodes, lastEp ? sg.episodes.indexOf(lastEp) : 0, sg); };
  $('#sFav', box).onclick = (e) => { const on = Prefs.toggleFav(key); e.target.textContent = on ? '★ Favorito' : '☆ Favoritar'; };
  $('#sClose', box).onclick = closeModal;
}
function epLabel(e) { return e.season || e.episode ? `T${e.season} E${e.episode}` : ''; }

// ---------- Busca ----------
let lastQuery = '';
function renderSearch(v) {
  v.innerHTML = `<input class="input" id="sq" placeholder="Digite o nome do canal, filme ou série…" style="max-width:560px;margin-bottom:16px" value="${esc(lastQuery)}">
    <div id="sres"></div>`;
  const inp = $('#sq', v); inp.focus();
  let t = null;
  const run = () => {
    lastQuery = inp.value;
    const res = $('#sres', v);
    if (inp.value.trim().length < 2) { res.innerHTML = '<div class="empty">Digite pelo menos 2 letras. A busca ignora acentos.</div>'; return; }
    const items = Repo.search(inp.value, hideAdult());
    renderGrid(res, items, { queue: items });
  };
  inp.oninput = () => { clearTimeout(t); t = setTimeout(run, 250); };
  run();
}

// ---------- Configurações ----------
async function renderSettings(v) {
  const pls = Prefs.playlists();
  const ver = await window.vetor.version();
  const { mac, key } = await Mac.device();
  v.innerHTML = `<div class="settings">
    <div class="card"><h3>Minhas listas</h3><div id="plList"></div>
      <button class="btn primary" id="addList" style="margin-top:12px">+ Adicionar lista</button>
      ${CONFIG.FIREBASE ? '<button class="btn" id="macSync" style="margin-top:12px">Buscar lista no painel (MAC)</button>' : ''}</div>
    <div class="card"><h3>Este computador</h3>
      <div class="set-row"><span>MAC</span><b style="color:var(--yellow);font-family:Consolas,monospace;user-select:text">${esc(mac)}</b></div>
      <div class="set-row"><span>KEY</span><b style="color:var(--yellow);font-family:Consolas,monospace;user-select:text">${esc(key)}</b></div></div>
    <div class="card"><h3>Preferências</h3>
      <div class="set-row"><span>Organizar em ordem alfabética (A–Z)</span><button class="switch${Prefs.sortAlpha ? ' on' : ''}" id="swSort"></button></div>
      <div class="set-row"><span>Bloquear categorias adultas com PIN</span><button class="switch${Prefs.adultLock ? ' on' : ''}" id="swAdult"></button></div>
      <div class="set-row"><span>PIN do controle dos pais</span><button class="btn" id="chPin">Trocar PIN</button></div>
      <div class="set-row"><span>Histórico e "continuar assistindo"</span><button class="btn danger" id="clrHist">Limpar</button></div></div>
    <div class="card"><h3>Suporte</h3>
      <div class="set-row"><span>WhatsApp ${esc(CONFIG.WHATSAPP_SHOW)}</span><button class="btn zap" id="zapSup">Abrir WhatsApp</button></div>
      <div class="set-row"><span>Versão ${esc(ver)}</span><button class="btn" id="chkUpd">Procurar atualização</button></div>
      <div class="set-row"><span>Atalhos: Espaço pausa · F tela cheia · ↑↓ troca canal · ←→ avança/volta · L lista · Esc sai</span></div></div>
  </div>`;
  const list = $('#plList', v);
  list.innerHTML = pls.length ? pls.map((p) => `<div class="pl-item"><div class="nm">${p.id === Prefs.activeId ? '<b style="color:var(--yellow)">● </b>' : ''}${esc(p.name)}
      <small>${p.kind === 'xtream' ? 'Login ' + esc(p.username) : p.kind === 'file' ? 'Arquivo do computador' : 'Link M3U'}${p.id.startsWith('mac') ? ' · enviada pelo painel' : ''}</small></div>
      ${p.id !== Prefs.activeId ? `<button class="btn" data-use="${esc(p.id)}">Usar</button>` : ''}
      ${p.id.startsWith('mac') ? '' : `<button class="btn danger" data-del="${esc(p.id)}">Remover</button>`}</div>`).join('') : '<p class="muted">Nenhuma lista.</p>';
  list.onclick = async (e) => {
    const use = e.target.dataset.use, del = e.target.dataset.del;
    if (use) {
      const prev = Prefs.activeId; Prefs.activeId = use;
      try { await Loader.withDialog(Prefs.active(), false); unlockedAdult = false; Object.keys(catState).forEach((k) => catState[k] = null); toast('Lista trocada'); renderSettings(v); }
      catch (err) { Prefs.activeId = prev; toast(friendly(err), null, 6000); }
    }
    if (del && await confirmBox('Remover lista?', 'Os favoritos dessa lista também deixam de aparecer.', 'Remover', true)) {
      const wasActive = del === Prefs.activeId;
      Prefs.remove(del); await window.vetor.deleteCache(del);
      if (!Prefs.playlists().length) { Repo.loadedId = null; return openLogin(); }
      if (wasActive) { try { await Loader.withDialog(Prefs.active(), false); } catch (err) { toast(friendly(err), null, 6000); } }
      renderSettings(v);
    }
  };
  $('#addList', v).onclick = () => openLogin();
  const ms = $('#macSync', v);
  if (ms) ms.onclick = async () => {
    try {
      const n = await Mac.sync();
      if (n == null) toast('Computador ainda não cadastrado no painel.', null, 5000);
      else if (n === 0) toast('Nenhuma lista ativa para este computador.', null, 5000);
      else { toast(`${n} lista(s) do painel atualizada(s)`); renderSettings(v); }
    } catch (err) { toast(friendly(err), null, 6000); }
  };
  $('#swSort', v).onclick = (e) => { Prefs.sortAlpha = !Prefs.sortAlpha; e.target.classList.toggle('on', Prefs.sortAlpha); };
  $('#swAdult', v).onclick = async (e) => {
    if (Prefs.adultLock && !(await askPin('Digite o PIN para desbloquear'))) return;
    Prefs.adultLock = !Prefs.adultLock; unlockedAdult = false;
    e.target.classList.toggle('on', Prefs.adultLock);
  };
  $('#chPin', v).onclick = async () => {
    if (!(await askPin('Digite o PIN atual'))) return;
    const box = openModal(`<h3>Novo PIN</h3><input class="input" id="np1" type="password" maxlength="8" placeholder="Novo PIN (4 a 8 números)">
      <input class="input" id="np2" type="password" maxlength="8" placeholder="Repita o novo PIN" style="margin-top:10px">
      <div id="npErr" class="status error hidden"></div>
      <div class="modal-actions"><button class="btn" data-a="no">Cancelar</button><button class="btn primary" data-a="ok">Salvar</button></div>`, { small: true });
    $('#np1', box).focus();
    box.onclick = (e) => {
      const a = e.target.dataset.a; if (!a) return;
      if (a === 'no') return closeModal();
      const p1 = $('#np1', box).value, p2 = $('#np2', box).value, err = $('#npErr', box);
      if (!/^\d{4,8}$/.test(p1)) { err.textContent = 'Use de 4 a 8 números.'; return show(err); }
      if (p1 !== p2) { err.textContent = 'Os dois PINs não são iguais.'; return show(err); }
      Prefs.pin = p1; closeModal(); toast('PIN trocado');
    };
  };
  $('#clrHist', v).onclick = async () => { if (await confirmBox('Limpar histórico?', 'Some a lista "Continuar assistindo" e o ponto onde os filmes pararam.', 'Limpar', true)) { Prefs.clearHistory(); toast('Histórico limpo'); } };
  $('#zapSup', v).onclick = () => window.vetor.openExternal(zapUrl());
  $('#chkUpd', v).onclick = () => checkUpdate(true);
}

// ======================================================================
// Atualização (versões novas publicadas no GitHub)
// ======================================================================
async function checkUpdate(manual = false) {
  if (!CONFIG.REPO) return;
  if (!manual && Date.now() - Prefs.get('updCheck', 0) < 6 * 3600 * 1000) return;
  Prefs.set('updCheck', Date.now());
  try {
    const r = await fetch(`https://api.github.com/repos/${CONFIG.REPO}/releases/tags/${CONFIG.RELEASE_TAG}`, { cache: 'no-store' });
    if (!r.ok) { if (manual) toast('Não consegui procurar atualização agora.'); return; }
    const rel = await r.json();
    const m = String(rel.name || '').match(/(\d+)\.(\d+)\.(\d+)/);
    const asset = (rel.assets || []).find((a) => /\.exe$/i.test(a.name));
    const cur = (await window.vetor.version()).split('.').map(Number);
    const remote = m ? [+m[1], +m[2], +m[3]] : null;
    const newer = remote && asset && (remote[0] - cur[0] || remote[1] - cur[1] || remote[2] - cur[2]) > 0;
    if (!newer) { if (manual) toast('Você já está com a versão mais nova.'); return; }
    const b = $('#updateBanner');
    b.innerHTML = `<span>Nova versão ${remote.join('.')} do Vetor Play Online disponível.</span><button class="btn primary">Baixar e instalar</button><button class="btn ghost">Depois</button>`;
    const [dl, later] = $$('button', b);
    dl.onclick = () => { window.vetor.openExternal(asset.browser_download_url); toast('Abra o arquivo baixado para instalar por cima. Suas listas continuam salvas.', null, 8000); };
    later.onclick = () => show(b, false);
    show(b);
  } catch (e) { if (manual) toast('Não consegui procurar atualização agora.'); }
}

// ======================================================================
// Player
// ======================================================================
const video = $('#video');
const Player = {
  queue: [], index: 0, series: null, hls: null, ts: null, retries: 0, saveTimer: null, idleTimer: null, open_: false, resumeAt: 0,

  item() { return this.queue[this.index]; },
  isLive() { const it = this.item(); return it && it.type === LIVE; },

  open(queue, index, series = null) {
    this.queue = queue; this.index = index; this.series = series;
    show('#player'); this.open_ = true;
    $('#player').className = ['', 'fill', 'zoom'][Prefs.aspect] || '';
    $('#pAspect').textContent = ['Ajustar', 'Esticar', 'Zoom'][Prefs.aspect];
    video.volume = Prefs.volume; $('#pVol').value = Math.round(Prefs.volume * 100);
    this.play(true);
    this.wake();
  },

  async play(first = false) {
    const it = this.item(); if (!it) return;
    this.stopEngines();
    this.retries = first ? 0 : this.retries;
    show('#playerMsg', false); show('#pMenu', false); show('#playerSpinner');
    const live = it.type === LIVE;
    $('#pTitle').textContent = it.name;
    $('#pSub').textContent = live ? `${it.group} · canal ${this.index + 1} de ${this.queue.length}` : this.series ? `${this.series.name} · ${epLabel(it)}` : it.group;
    ['#pPrev', '#pNext'].forEach((s) => show(s, live || !!this.series));
    $('#pPrev').title = live ? 'Canal anterior (↑)' : 'Episódio anterior';
    $('#pNext').title = live ? 'Próximo canal (↓)' : 'Próximo episódio';
    ['#pBack10', '#pFwd10', '#pSeekWrap'].forEach((s) => show(s, !live));
    show('#pLive', live); show('#pList', live && this.queue.length > 1);
    if (!$('#pQueue').classList.contains('hidden')) this.renderQueue();

    await window.vetor.setPlayHeaders({ ua: it.ua, referer: it.referer });
    Prefs.addRecent(this.series ? 'series:' + this.series.name : it.url);
    if (this.series) Prefs.set('lastEp_' + this.series.name, it.url);

    this.resumeAt = !live ? Prefs.position(it.url) : 0;
    const url = it.url;
    const path = url.split('?')[0].toLowerCase();
    try {
      if ((path.endsWith('.m3u8') || /m3u8/i.test(url)) && window.Hls && Hls.isSupported()) {
        this.hls = new Hls({ enableWorker: true, lowLatencyMode: false, backBufferLength: 30 });
        this.hls.on(Hls.Events.ERROR, (_e, d) => { if (d.fatal) this.fail(d.details); });
        this.hls.loadSource(url);
        this.hls.attachMedia(video);
      } else if (live && window.mpegts && mpegts.getFeatureList().mseLivePlayback && !/\.(mp4|mkv|avi|mov|m4v)$/.test(path)) {
        this.ts = mpegts.createPlayer({ type: 'mpegts', isLive: true, url }, {
          enableWorker: true, enableStashBuffer: true, stashInitialSize: 384 * 1024,
          liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 6, liveBufferLatencyMinRemain: 1.5,
          autoCleanupSourceBuffer: true,
        });
        this.ts.on(mpegts.Events.ERROR, (t, d) => this.fail(`${t} ${d}`));
        this.ts.attachMediaElement(video);
        this.ts.load();
      } else {
        video.src = url;
      }
      const p = video.play(); if (p && p.catch) p.catch(() => { });
    } catch (e) { this.fail(e.message); }
  },

  stopEngines() {
    this.savePos();
    if (this.hls) { try { this.hls.destroy(); } catch (e) { } this.hls = null; }
    if (this.ts) { try { this.ts.pause(); this.ts.unload(); this.ts.detachMediaElement(); this.ts.destroy(); } catch (e) { } this.ts = null; }
    video.removeAttribute('src'); try { video.load(); } catch (e) { }
  },

  fail(detail) {
    if (!this.open_) return;
    show('#playerSpinner', false);
    if (this.isLive() && this.retries < 5) {
      this.retries++;
      this.msg(`Reconectando… (${this.retries}/5)`);
      clearTimeout(this.retryT);
      this.retryT = setTimeout(() => { if (this.open_) this.play(false); }, 2500);
      return;
    }
    const codec = /mkv|avi|wmv|flv/.test((this.item().url.split('?')[0]).toLowerCase());
    this.msg((this.isLive() ? 'Este canal não está abrindo agora.' : 'Não foi possível abrir este vídeo.')
      + (codec ? '\nO formato pode não ser compatível com o Windows.' : '\nConfira a internet ou tente outro.'), true);
    console.warn('player:', detail);
  },

  msg(text, actions = false) {
    const m = $('#playerMsg');
    m.innerHTML = esc(text) + (actions ? `<div><button class="btn primary" data-a="retry">Tentar de novo</button><button class="btn" data-a="close">Voltar</button></div>` : '');
    m.onclick = (e) => { const a = e.target.dataset.a; if (a === 'retry') { this.retries = 0; this.play(false); } if (a === 'close') this.close(); };
    show(m);
  },

  savePos() {
    const it = this.item();
    if (!it || it.type === LIVE || !video.duration || !isFinite(video.duration)) return;
    const t = video.currentTime;
    if (t > 30 && t < video.duration - 60) Prefs.savePosition(it.url, Math.floor(t * 1000));
    else if (t >= video.duration - 60) Prefs.savePosition(it.url, 0);
  },

  step(d) {
    const n = this.index + d;
    if (n < 0 || n >= this.queue.length) return;
    this.index = n; this.retries = 0; this.play(false);
  },

  close() {
    this.open_ = false;
    clearTimeout(this.retryT);
    this.stopEngines();
    window.vetor.setPlayHeaders(null);
    show('#player', false); show('#pQueue', false); show('#pMenu', false);
    if (document.fullscreenElement) document.exitFullscreen();
    window.vetor.toggleFullscreen(false);
    if (currentView === 'home') go('home');
  },

  wake() {
    $('#player').classList.remove('idle');
    clearTimeout(this.idleTimer);
    this.idleTimer = setTimeout(() => {
      if (!video.paused && $('#pMenu').classList.contains('hidden') && $('#pQueue').classList.contains('hidden')) $('#player').classList.add('idle');
    }, 3000);
  },

  renderQueue() {
    const q = $('#pQueue');
    q.innerHTML = this.queue.map((c, i) => `<button data-i="${i}" class="${i === this.index ? 'on' : ''}"><small>${i + 1}</small>${c.logo ? `<img src="${esc(c.logo)}" loading="lazy" onerror="this.style.visibility='hidden'">` : '<img style="visibility:hidden">'}<span>${esc(c.name)}</span></button>`).join('');
    const on = $('.on', q); if (on) on.scrollIntoView({ block: 'center' });
  },

  menu(kind) {
    const m = $('#pMenu');
    if (!m.classList.contains('hidden') && m.dataset.kind === kind) return show(m, false);
    m.dataset.kind = kind;
    let opts = [];
    if (kind === 'audio') {
      if (this.hls && this.hls.audioTracks.length) opts = this.hls.audioTracks.map((t, i) => ({ label: t.name || t.lang || 'Faixa ' + (i + 1), on: i === this.hls.audioTrack, fn: () => { this.hls.audioTrack = i; } }));
      else if (video.audioTracks && video.audioTracks.length) opts = [...video.audioTracks].map((t, i) => ({ label: t.label || t.language || 'Faixa ' + (i + 1), on: t.enabled, fn: () => { [...video.audioTracks].forEach((x, j) => { x.enabled = j === i; }); } }));
    } else if (kind === 'subs') {
      if (this.hls && this.hls.subtitleTracks.length) {
        opts = [{ label: 'Desligada', on: this.hls.subtitleTrack < 0, fn: () => { this.hls.subtitleTrack = -1; } },
          ...this.hls.subtitleTracks.map((t, i) => ({ label: t.name || t.lang || 'Legenda ' + (i + 1), on: i === this.hls.subtitleTrack, fn: () => { this.hls.subtitleTrack = i; this.hls.subtitleDisplay = true; } }))];
      } else if (video.textTracks && video.textTracks.length) {
        const tt = [...video.textTracks];
        opts = [{ label: 'Desligada', on: tt.every((t) => t.mode !== 'showing'), fn: () => tt.forEach((t) => { t.mode = 'disabled'; }) },
          ...tt.map((t, i) => ({ label: t.label || t.language || 'Legenda ' + (i + 1), on: t.mode === 'showing', fn: () => tt.forEach((x, j) => { x.mode = j === i ? 'showing' : 'disabled'; }) }))];
      }
    }
    if (!opts.length) opts = [{ label: kind === 'audio' ? 'Só há uma faixa de áudio' : 'Sem legendas neste vídeo', on: false, fn: () => { } }];
    m.innerHTML = opts.map((o, i) => `<button data-i="${i}" class="${o.on ? 'on' : ''}">${o.on ? '✓ ' : ''}${esc(o.label)}</button>`).join('');
    m.onclick = (e) => { const b = e.target.closest('[data-i]'); if (b) { opts[+b.dataset.i].fn(); show(m, false); } };
    show(m);
  },
};

// eventos do vídeo
video.addEventListener('playing', () => { show('#playerSpinner', false); show('#playerMsg', false); Player.retries = 0; $('#pPlay').textContent = '⏸'; });
video.addEventListener('waiting', () => show('#playerSpinner'));
video.addEventListener('pause', () => { $('#pPlay').textContent = '▶'; Player.wake(); });
video.addEventListener('play', () => { $('#pPlay').textContent = '⏸'; });
video.addEventListener('loadedmetadata', () => {
  if (Player.resumeAt > 0 && isFinite(video.duration) && Player.resumeAt / 1000 < video.duration - 60) {
    const at = Player.resumeAt / 1000;
    video.currentTime = at;
    toast(`Continuando de ${fmtTime(at)}`, { label: 'Ver do início', fn: () => { video.currentTime = 0; } }, 7000);
  }
  Player.resumeAt = 0;
});
video.addEventListener('error', () => { if (!Player.hls && !Player.ts && video.getAttribute('src')) Player.fail(video.error && video.error.message); });
video.addEventListener('timeupdate', () => {
  if (Player.isLive() || !isFinite(video.duration)) return;
  $('#pCur').textContent = fmtTime(video.currentTime);
  $('#pDur').textContent = fmtTime(video.duration);
  if (!seeking) $('#pSeek').value = Math.round((video.currentTime / video.duration) * 1000) || 0;
  const now = Date.now();
  if (now - (Player.lastSave || 0) > 10000) { Player.lastSave = now; Player.savePos(); }
});
video.addEventListener('ended', () => {
  const it = Player.item();
  if (it && it.type !== LIVE) Prefs.savePosition(it.url, 0);
  if (Player.series && Player.index < Player.queue.length - 1) { toast('Próximo episódio…'); setTimeout(() => { if (Player.open_) Player.step(1); }, 1500); }
  else if (Player.isLive()) Player.fail('ended');
});

let seeking = false;
$('#pSeek').addEventListener('input', () => { seeking = true; if (isFinite(video.duration)) $('#pCur').textContent = fmtTime(($('#pSeek').value / 1000) * video.duration); });
$('#pSeek').addEventListener('change', () => { if (isFinite(video.duration)) video.currentTime = ($('#pSeek').value / 1000) * video.duration; seeking = false; });

$('#pBack').onclick = () => Player.close();
$('#pPlay').onclick = () => (video.paused ? video.play() : video.pause());
$('#pBack10').onclick = () => { video.currentTime = Math.max(0, video.currentTime - 10); };
$('#pFwd10').onclick = () => { video.currentTime = Math.min(video.duration || 0, video.currentTime + 10); };
$('#pPrev').onclick = () => Player.step(-1);
$('#pNext').onclick = () => Player.step(1);
$('#pMute').onclick = () => { video.muted = !video.muted; $('#pMute').textContent = video.muted ? '🔇' : '🔊'; };
$('#pVol').oninput = (e) => { video.volume = e.target.value / 100; video.muted = false; Prefs.volume = video.volume; $('#pMute').textContent = '🔊'; };
$('#pAspect').onclick = () => {
  Prefs.aspect = (Prefs.aspect + 1) % 3;
  $('#player').className = ['', 'fill', 'zoom'][Prefs.aspect];
  $('#pAspect').textContent = ['Ajustar', 'Esticar', 'Zoom'][Prefs.aspect];
};
$('#pAudio').onclick = () => Player.menu('audio');
$('#pSubs').onclick = () => Player.menu('subs');
$('#pFull').onclick = () => window.vetor.toggleFullscreen();
$('#pList').onclick = () => { const q = $('#pQueue'); show(q, q.classList.contains('hidden')); if (!q.classList.contains('hidden')) Player.renderQueue(); };
$('#pQueue').onclick = (e) => { const b = e.target.closest('[data-i]'); if (b) { Player.index = +b.dataset.i; Player.retries = 0; Player.play(false); } };
video.addEventListener('dblclick', () => window.vetor.toggleFullscreen());
video.addEventListener('click', () => { if (!$('#pMenu').classList.contains('hidden')) return show('#pMenu', false); video.paused ? video.play() : video.pause(); });
$('#player').addEventListener('mousemove', () => Player.wake());

document.addEventListener('keydown', (e) => {
  if (!Player.open_) {
    if (e.key === 'Escape' && !$('#modal').classList.contains('hidden') && !modalLocked) closeModal();
    if (e.key === 'F11') { e.preventDefault(); window.vetor.toggleFullscreen(); }
    return;
  }
  if (e.target.tagName === 'INPUT' && e.target.type !== 'range') return;
  Player.wake();
  const live = Player.isLive();
  switch (e.key) {
    case ' ': case 'k': e.preventDefault(); video.paused ? video.play() : video.pause(); break;
    case 'Escape':
      if (!$('#pMenu').classList.contains('hidden')) show('#pMenu', false);
      else if (!$('#pQueue').classList.contains('hidden')) show('#pQueue', false);
      else window.vetor.toggleFullscreen(false).then((fs) => { if (!fs && !wasFull) Player.close(); });
      break;
    case 'f': case 'F': case 'F11': e.preventDefault(); window.vetor.toggleFullscreen(); break;
    case 'm': case 'M': $('#pMute').click(); break;
    case 'l': case 'L': if (live) $('#pList').click(); break;
    case 'ArrowUp': case 'PageUp': e.preventDefault(); if (live) Player.step(-1); else { video.volume = Math.min(1, video.volume + 0.1); Prefs.volume = video.volume; $('#pVol').value = video.volume * 100; } break;
    case 'ArrowDown': case 'PageDown': e.preventDefault(); if (live) Player.step(1); else { video.volume = Math.max(0, video.volume - 0.1); Prefs.volume = video.volume; $('#pVol').value = video.volume * 100; } break;
    case 'ArrowLeft': if (!live) { e.preventDefault(); $('#pBack10').click(); } break;
    case 'ArrowRight': if (!live) { e.preventDefault(); $('#pFwd10').click(); } break;
    default:
  }
});
// Esc em tela cheia: o primeiro sai da tela cheia, o segundo fecha o player
let wasFull = false;
window.vetor.onFullscreen((v) => { if (v) wasFull = true; else setTimeout(() => { wasFull = false; }, 300); });

window.addEventListener('beforeunload', () => Player.savePos());

// ======================================================================
startApp(false);
