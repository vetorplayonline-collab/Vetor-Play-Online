// Leitura da lista M3U e organização em TV ao Vivo, Filmes e Séries (mesma lógica do app Android)
'use strict';

const LIVE = 'live', MOVIE = 'movie', SERIES = 'series';

const M3U = (() => {
  const episodeRe = /\bS(\d{1,2})\s*[ ._-]?\s*E(\d{1,3})\b/i;
  const seriesGroupRe = /(s[ée]rie|series|novela|temporada|anime|desenho)/i;
  const movieGroupRe = /(filme|movie|vod|cinema|lan[çc]amento|4k uhd|legendado|dublado)/i;
  const liveHintRe = /(24\s?h|24 horas|ao vivo|canais|tv\b|live)/i;
  const vodExt = ['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.m4v', '.flv'];

  function readExtinf(h) {
    const r = { logo: null, group: null, tvgName: null, ua: null, title: '' };
    let i = h.indexOf(':'); i = i < 0 ? 0 : i + 1;
    const n = h.length;
    while (i < n) {
      const c = h[i];
      if (c === ',') { r.title = h.substring(i + 1).trim(); break; }
      if (c === '=' && h[i + 1] === '"') {
        let s = i - 1;
        while (s >= 0 && h[s] !== ' ' && h[s] !== ':') s--;
        const key = h.substring(s + 1, i).toLowerCase();
        let end = h.indexOf('"', i + 2); if (end < 0) end = n;
        const value = h.substring(i + 2, end).trim();
        if (key === 'tvg-logo') r.logo = value;
        else if (key === 'group-title') r.group = value;
        else if (key === 'tvg-name') r.tvgName = value;
        else if (key === 'user-agent') r.ua = value;
        i = end + 1;
        continue;
      }
      i++;
    }
    return r;
  }

  function detectType(url, group, name, hints) {
    const lu = url.toLowerCase();
    if (lu.includes('/series/')) return SERIES;
    if (lu.includes('/movie/')) return MOVIE;
    if (lu.includes('/live/')) return LIVE;
    let hint;
    if (hints.has(group)) hint = hints.get(group);
    else {
      hint = liveHintRe.test(group) ? LIVE : seriesGroupRe.test(group) ? SERIES : movieGroupRe.test(group) ? MOVIE : null;
      hints.set(group, hint);
    }
    if (name.length > 4 && episodeRe.test(name)) return SERIES;
    if (hint) return hint;
    const p = lu.split('?')[0];
    for (const e of vodExt) if (p.endsWith(e)) return MOVIE;
    return LIVE;
  }

  function build(header, url, ua, referer, groupOverride, hints) {
    const e = readExtinf(header);
    const name = e.title || e.tvgName || url.substring(url.lastIndexOf('/') + 1);
    const group = (groupOverride || e.group || '').trim() || 'Sem categoria';
    const logo = e.logo && e.logo.startsWith('http') ? e.logo : null;
    const type = detectType(url, group, name, hints);
    const ch = { name, url, logo, group, type, ua: ua || e.ua || null, referer: referer || null };
    if (type === SERIES) {
      const m = episodeRe.exec(name);
      let sn = null;
      ch.season = 0; ch.episode = 0;
      if (m) {
        ch.season = parseInt(m[1], 10) || 0;
        ch.episode = parseInt(m[2], 10) || 0;
        sn = name.substring(0, m.index).trim().replace(/[-|:.([]+$/, '').trim();
      }
      ch.seriesName = sn || name;
    }
    return ch;
  }

  function parse(text) {
    const out = [];
    const hints = new Map();
    let info = null, ua = null, referer = null, grp = null;
    let pos = 0;
    const len = text.length;
    if (text.charCodeAt(0) === 0xfeff) pos = 1;
    while (pos < len) {
      let nl = text.indexOf('\n', pos);
      if (nl < 0) nl = len;
      let line = text.substring(pos, nl);
      pos = nl + 1;
      if (!line) continue;
      if (line.charCodeAt(line.length - 1) === 13 || line[0] === ' ' || line[line.length - 1] === ' ') line = line.trim();
      if (!line) continue;
      if (line[0] === '#') {
        const up = line.substring(0, 11).toUpperCase();
        if (up.startsWith('#EXTINF')) { info = line; ua = null; referer = null; grp = null; }
        else if (up.startsWith('#EXTVLCOPT')) {
          const opt = line.substring(line.indexOf(':') + 1);
          const val = opt.substring(opt.indexOf('=') + 1).trim();
          const ol = opt.toLowerCase();
          if (ol.startsWith('http-user-agent')) ua = val;
          else if (ol.startsWith('http-referrer') || ol.startsWith('http-referer')) referer = val;
        } else if (up.startsWith('#EXTGRP')) grp = line.substring(line.indexOf(':') + 1).trim();
        continue;
      }
      if (info) out.push(build(info, line, ua, referer, grp, hints));
      else if (line.includes('://')) out.push(build('#EXTINF:-1,' + line.substring(line.lastIndexOf('/') + 1), line, null, null, null, hints));
      info = null;
    }
    return out;
  }

  return { parse, episodeRe };
})();

/** Normaliza para busca: minúsculas e sem acento. */
function normalize(s) {
  return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
}

const adultRe = /(adult|xxx|\+18|18\+|adulto|porn|er[óo]tic)/i;

/** Lista carregada em memória, já separada. */
const Repo = {
  loadedId: null,
  all: [],
  groups: { live: new Map(), movie: new Map(), series: new Map() },
  seriesByName: new Map(),
  searchIndex: null,

  isAdult(cat) { return adultRe.test(cat); },

  index(list, id) {
    const live = new Map(), movie = new Map(), eps = new Map(), sCat = new Map();
    for (const c of list) {
      if (c.type === LIVE) { if (!live.has(c.group)) live.set(c.group, []); live.get(c.group).push(c); }
      else if (c.type === MOVIE) { if (!movie.has(c.group)) movie.set(c.group, []); movie.get(c.group).push(c); }
      else {
        const n = c.seriesName || c.name;
        if (!eps.has(n)) { eps.set(n, []); sCat.set(n, c.group); }
        eps.get(n).push(c);
      }
    }
    const series = new Map(), byName = new Map();
    for (const [name, list2] of eps) {
      list2.sort((a, b) => (a.season - b.season) || (a.episode - b.episode));
      const sg = { name, group: sCat.get(name) || 'Séries', logo: (list2.find((x) => x.logo) || {}).logo || null, episodes: list2, isSeries: true };
      if (!series.has(sg.group)) series.set(sg.group, []);
      series.get(sg.group).push(sg);
      byName.set(name, sg);
    }
    this.all = list;
    this.groups = { live, movie, series };
    this.seriesByName = byName;
    this.searchIndex = null;
    this.loadedId = id;
  },

  categories(type) { return [...this.groups[type].keys()]; },
  count(type) {
    if (type === SERIES) return this.seriesByName.size;
    let n = 0; for (const l of this.groups[type].values()) n += l.length; return n;
  },
  items(type, cat) { return this.groups[type].get(cat) || []; },
  allItems(type, hideAdult) {
    const out = [];
    for (const [cat, l] of this.groups[type]) if (!hideAdult || !this.isAdult(cat)) for (const x of l) out.push(x);
    return out;
  },
  keyOf(item) { return item.isSeries ? 'series:' + item.name : item.url; },

  itemsForKeys(keys) {
    if (!keys.length) return [];
    const found = new Map(), wanted = new Set();
    for (const k of keys) {
      if (k.startsWith('series:')) { const s = this.seriesByName.get(k.substring(7)); if (s) found.set(k, s); }
      else wanted.add(k);
    }
    if (wanted.size) for (const c of this.all) if (wanted.has(c.url)) { found.set(c.url, c); wanted.delete(c.url); if (!wanted.size) break; }
    return keys.map((k) => found.get(k)).filter(Boolean);
  },

  latest(type, limit, hideAdult) {
    const out = [];
    const entries = [...this.groups[type].entries()].reverse();
    for (const [cat, l] of entries) {
      if (hideAdult && this.isAdult(cat)) continue;
      for (let i = l.length - 1; i >= 0; i--) { out.push(l[i]); if (out.length >= limit) return out; }
    }
    return out;
  },

  search(q, hideAdult, limit = 300) {
    q = normalize(q.trim());
    if (q.length < 2) return [];
    if (!this.searchIndex || this.searchIndex.adult !== hideAdult) {
      const items = [...this.allItems(LIVE, hideAdult), ...this.allItems(MOVIE, hideAdult), ...this.allItems(SERIES, hideAdult)];
      this.searchIndex = { adult: hideAdult, items, keys: items.map((x) => normalize(x.name)) };
    }
    const out = [];
    const { items, keys } = this.searchIndex;
    for (let i = 0; i < keys.length; i++) if (keys[i].includes(q)) { out.push(items[i]); if (out.length >= limit) break; }
    return out;
  },
};

if (typeof module !== 'undefined') module.exports = { M3U, Repo, normalize, LIVE, MOVIE, SERIES };
