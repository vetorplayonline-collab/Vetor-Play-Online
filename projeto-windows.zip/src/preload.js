// Ponte segura entre a tela e o Windows (arquivos, rede e janela)
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('vetor', {
  device: () => ipcRenderer.invoke('device'),
  version: () => ipcRenderer.invoke('version'),
  hasCache: (id) => ipcRenderer.invoke('has-cache', id),
  deleteCache: (id) => ipcRenderer.invoke('delete-cache', id),
  download: (id, url) => ipcRenderer.invoke('download', id, url),
  readCache: (id) => ipcRenderer.invoke('read-cache', id),
  importFile: (id) => ipcRenderer.invoke('import-file', id),
  setPlayHeaders: (h) => ipcRenderer.invoke('set-play-headers', h),
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  toggleFullscreen: (v) => ipcRenderer.invoke('toggle-fullscreen', v),
  quit: () => ipcRenderer.invoke('quit'),
  onProgress: (fn) => ipcRenderer.on('download-progress', (_e, p) => fn(p)),
  onFullscreen: (fn) => ipcRenderer.on('fullscreen', (_e, v) => fn(v)),
});
