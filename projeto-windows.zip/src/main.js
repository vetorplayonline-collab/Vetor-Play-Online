// Vetor Play Online para Windows — processo principal (janela, arquivos e rede)
const { app, BrowserWindow, ipcMain, session, shell, dialog, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const zlib = require('zlib');
const { execFileSync } = require('child_process');

const DEFAULT_UA = 'Mozilla/5.0 (Linux; Android 10) VetorPlayOnline/1.0';

// Faixas de áudio e legendas embutidas nos filmes
app.commandLine.appendSwitch('enable-blink-features', 'AudioVideoTracks');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();

let win = null;
// Cabeçalhos do canal que está tocando (alguns servidores exigem User-Agent/Referer próprios)
let playHeaders = { ua: null, referer: null };

const dataDir = () => app.getPath('userData');
const cacheFile = (id) => path.join(dataDir(), `playlist_${String(id).replace(/[^\w-]/g, '')}.m3u`);

function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1366, height: 800, minWidth: 980, minHeight: 600,
    backgroundColor: '#0A0A0A',
    title: 'Vetor Play Online',
    icon: path.join(__dirname, 'logo.png'),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      // Listas IPTV não liberam acesso de outros sites (CORS) e muitas são http://
      webSecurity: false,
      allowRunningInsecureContent: true,
      backgroundThrottling: false,
    },
  });
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  win.loadFile(path.join(__dirname, 'index.html'));

  // Links externos (WhatsApp, GitHub) abrem no navegador
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file:')) { e.preventDefault(); shell.openExternal(url); }
  });
  win.on('enter-full-screen', () => win.webContents.send('fullscreen', true));
  win.on('leave-full-screen', () => win.webContents.send('fullscreen', false));
}

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

app.whenReady().then(() => {
  if (!gotLock) return;
  const ses = session.defaultSession;
  ses.webRequest.onBeforeSendHeaders((details, cb) => {
    const h = details.requestHeaders;
    if (/^https?:/i.test(details.url) && !/firebaseio\.com|api\.github\.com|googleapis\.com/i.test(details.url)) {
      h['User-Agent'] = playHeaders.ua || DEFAULT_UA;
      if (playHeaders.referer) h['Referer'] = playHeaders.referer;
      // Origin "null" (arquivo local) faz alguns servidores recusarem o vídeo
      delete h['Origin'];
    }
    cb({ requestHeaders: h });
  });
  createWindow();
});

app.on('window-all-closed', () => app.quit());

// ---------- MAC / KEY do computador ----------
function machineId() {
  try {
    const out = execFileSync('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
      { encoding: 'utf8', windowsHide: true, timeout: 5000 });
    const m = out.match(/MachineGuid\s+REG_\w+\s+([0-9a-fA-F-]+)/);
    if (m) return m[1].toLowerCase();
  } catch (e) { /* segue para o plano B */ }
  // Plano B: um código gerado uma vez e guardado (não muda ao atualizar o app)
  const f = path.join(dataDir(), 'device.json');
  try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); if (j.id) return j.id; } catch (e) { }
  const id = crypto.randomUUID();
  try { fs.mkdirSync(dataDir(), { recursive: true }); fs.writeFileSync(f, JSON.stringify({ id })); } catch (e) { }
  return id;
}

function device() {
  const h = crypto.createHash('sha256').update('vetorplay:win:' + machineId()).digest();
  const b = Buffer.from(h.subarray(0, 6));
  b[0] = (b[0] & 0xfc) | 0x02;
  const mac = [...b].map((x) => x.toString(16).toUpperCase().padStart(2, '0')).join(':');
  const n = ((h[10] << 16) | (h[11] << 8) | h[12]) >>> 0;
  const key = String(n % 1000000).padStart(6, '0');
  return { mac, key };
}

// ---------- Download da lista ----------
function httpGet(address, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 7) return reject(new Error('Muitos redirecionamentos.'));
    let u;
    try { u = new URL(address); } catch (e) { return reject(new Error('Endereço da lista inválido.')); }
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.get(u, {
      headers: { 'User-Agent': DEFAULT_UA, Accept: '*/*', 'Accept-Encoding': 'gzip' },
      timeout: 30000,
    }, (res) => {
      const code = res.statusCode || 0;
      if (code >= 300 && code < 400) {
        res.resume();
        if (!res.headers.location) return reject(new Error('Redirecionamento inválido do servidor.'));
        return resolve(httpGet(new URL(res.headers.location, u).toString(), redirects + 1));
      }
      if (code !== 200) {
        res.resume();
        const msg = (code === 401 || code === 403) ? `Acesso negado pelo servidor (código ${code}). Confira usuário e senha.`
          : code === 404 ? 'Endereço da lista não encontrado (404).' : `O servidor respondeu com erro ${code}.`;
        return reject(new Error(msg));
      }
      resolve(res);
    });
    req.on('timeout', () => req.destroy(new Error('O servidor demorou demais para responder.')));
    req.on('error', (e) => reject(new Error(friendlyNet(e))));
  });
}

function friendlyNet(e) {
  const c = e && e.code;
  if (c === 'ENOTFOUND' || c === 'EAI_AGAIN') return 'Servidor não encontrado. Confira o endereço e a internet.';
  if (c === 'ECONNREFUSED') return 'O servidor recusou a conexão.';
  if (c === 'ECONNRESET' || c === 'ETIMEDOUT') return 'A conexão com o servidor caiu. Tente de novo.';
  return (e && e.message) || 'Falha de rede.';
}

function validateHead(file) {
  const fd = fs.openSync(file, 'r');
  const buf = Buffer.alloc(4096);
  const n = fs.readSync(fd, buf, 0, 4096, 0);
  fs.closeSync(fd);
  const head = buf.subarray(0, n).toString('utf8').toUpperCase();
  if (!head.includes('#EXTM3U') && !head.includes('#EXTINF')) {
    throw new Error('O servidor não devolveu uma lista M3U. Confira os dados de acesso.');
  }
}

async function download(id, address) {
  fs.mkdirSync(dataDir(), { recursive: true });
  const target = cacheFile(id);
  const tmp = target + '.tmp';
  const res = await httpGet(address);
  const total = Number(res.headers['content-length']) || 0;
  let got = 0;
  await new Promise((resolve, reject) => {
    const out = fs.createWriteStream(tmp);
    let stream = res;
    res.on('data', (c) => {
      got += c.length;
      if (win && !win.isDestroyed()) win.webContents.send('download-progress', { got, total });
    });
    if (/gzip/i.test(res.headers['content-encoding'] || '')) stream = res.pipe(zlib.createGunzip());
    stream.on('error', (e) => reject(new Error(friendlyNet(e))));
    res.on('error', (e) => reject(new Error(friendlyNet(e))));
    out.on('error', reject);
    out.on('finish', resolve);
    stream.pipe(out);
  });
  try { validateHead(tmp); } catch (e) { try { fs.unlinkSync(tmp); } catch (_) { } throw e; }
  try { fs.unlinkSync(target); } catch (_) { }
  fs.renameSync(tmp, target);
}

// ---------- Ponte com a tela ----------
ipcMain.handle('device', () => device());
ipcMain.handle('version', () => app.getVersion());
ipcMain.handle('has-cache', (_e, id) => { try { return fs.statSync(cacheFile(id)).size > 0; } catch (e) { return false; } });
ipcMain.handle('delete-cache', (_e, id) => { try { fs.unlinkSync(cacheFile(id)); } catch (e) { } return true; });
ipcMain.handle('download', async (_e, id, url) => {
  try { await download(id, url); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('read-cache', (_e, id) => {
  try { return { ok: true, text: fs.readFileSync(cacheFile(id), 'utf8') }; }
  catch (e) { return { ok: false, error: 'Lista não encontrada. Adicione novamente.' }; }
});
ipcMain.handle('import-file', async (_e, id) => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Escolha a lista .m3u',
    properties: ['openFile'],
    filters: [{ name: 'Listas M3U', extensions: ['m3u', 'm3u8', 'txt'] }, { name: 'Todos os arquivos', extensions: ['*'] }],
  });
  if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
  try {
    fs.mkdirSync(dataDir(), { recursive: true });
    validateHead(r.filePaths[0]);
    fs.copyFileSync(r.filePaths[0], cacheFile(id));
    return { ok: true, name: path.basename(r.filePaths[0]).replace(/\.[^.]+$/, '') };
  } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('set-play-headers', (_e, h) => { playHeaders = { ua: (h && h.ua) || null, referer: (h && h.referer) || null }; return true; });
ipcMain.handle('open-external', (_e, url) => { if (/^https?:/i.test(url)) shell.openExternal(url); return true; });
ipcMain.handle('toggle-fullscreen', (_e, v) => {
  if (!win) return false;
  win.setFullScreen(typeof v === 'boolean' ? v : !win.isFullScreen());
  return win.isFullScreen();
});
ipcMain.handle('quit', () => app.quit());
