# Vetor Play Online — App Android

> **Versão de 23/11/2026 (15h50)**: TV ao Vivo com prévia do canal, correção de travamentos, sem WhatsApp na TV/TV Box e Configurações no menu da esquerda. Use sempre esta pasta para publicar.

Player de listas IPTV (M3U e Xtream Codes) com a identidade amarela e preta da Vetor Play Online.
Funciona em **celular, tablet, Android TV e TV Box** (Android 5.0 ou mais novo).

## O que o app faz
- **Entrada por Login** (servidor + usuário + senha, padrão Xtream Codes), **Link M3U** ou **Arquivo .m3u** do aparelho
- Várias listas salvas, com troca rápida nas Configurações
- Abas **Início**, **TV ao Vivo**, **Filmes** e **Séries**, com categorias da própria lista
- Séries agrupadas por **temporada e episódio**, com "Assistir" que continua de onde parou
- **Continuar assistindo** (filmes e episódios voltam no ponto em que pararam)
- **Favoritos** (segure o dedo ou o botão OK do controle sobre o item) e **Recentes**
- **Busca** em tudo ao mesmo tempo, ignorando acentos
- Botão **A–Z** para organizar canais, filmes e séries em ordem alfabética (ou voltar à ordem da lista)
- Cartão **Seu sinal** na tela inicial com o vencimento e o WhatsApp da Vetor Play Online (44) 99721-3054 para renovação
- Player Media3/ExoPlayer: HLS (.m3u8), MPEG-TS, MP4, MKV; troca de canal com CH+/CH− ou setas do controle,
  ajuste de tela (ajustar / esticar / zoom), legendas e faixas de áudio, reconexão automática nos canais ao vivo
- **Controle dos pais**: categorias adultas bloqueadas por PIN (padrão **0000**, dá para trocar)

## Como gerar o APK (PUBLICAR_APK.bat)
O projeto já está ligado ao GitHub **vetorplayonline-collab/Vetor-Play-Online**. Para gerar um APK novo:

1. Dê dois cliques em **PUBLICAR_APK.bat** (dentro desta pasta).
2. Só na primeira vez: ele instala o *GitHub CLI* e abre o navegador para você entrar no GitHub
   (copie o código que aparece na janela preta e confirme no site).
3. Ele compacta o projeto, envia para o GitHub, espera compilar (3 a 6 minutos) e salva
   **VetorPlayOnline.apk** aqui na pasta, já abrindo o Explorer com o arquivo selecionado.

Cada APK sai com um número de versão novo (1.0.2, 1.0.3...), então instala por cima do anterior sem perder as listas.
Se der erro, tire um print da janela preta e envie ao Claude.

Outra opção: abrir a pasta no Android Studio e usar **Build › Build APK(s)**.

## Instalar no aparelho
Copie o APK para o celular/TV Box e abra. Se o Android pedir, permita **"Instalar apps desconhecidos"**.
Na TV Box, o app Downloader ou um pendrive resolvem.

## Personalizar para a sua revenda
Arquivo `app/src/main/java/br/com/vetorplayonline/app/Config.kt`:
- `DEFAULT_SERVER` — coloque seu DNS (ex.: `"http://meudns.com:8080"`). O campo servidor some e o cliente só digita usuário e senha.
- `WHATSAPP_SUPORTE` / `WHATSAPP_EXIBICAO` — WhatsApp da Vetor Play Online (já configurado: (44) 99721-3054), usado no cartão de vencimento e no botão de suporte.

**Logo oficial:** substitua `app/src/main/res/drawable-nodpi/logo_vetor.png` pela sua logo (PNG quadrado, de preferência 512×512)
mantendo o mesmo nome. Os ícones do app ficam em `res/mipmap-*` e o banner da Android TV em `res/drawable-xhdpi/tv_banner.png`.

**Cores:** `app/src/main/res/values/colors.xml` (`vetor_yellow`, `vetor_orange`, `vetor_black`).

**Versão:** ao lançar uma atualização, aumente `versionCode` e `versionName` em `app/build.gradle.kts`.

## Ativação pelo MAC (Painel MAC do Gestor)
Cada aparelho mostra um **MAC** e uma **KEY** na tela de entrada. O cliente te manda esses dados e você envia a lista
pelo **Gestor Vetor Play Online › Painel MAC** (ou pelo botão **📺 Lista** na aba Aplicativos). No aparelho, o cliente toca em
**"Já enviei · Buscar minha lista"**. O app também confere o painel toda vez que abre, então se você trocar o servidor,
bloquear ou liberar o cliente, o aparelho já recebe a mudança.

O app já vem apontando para o banco do Gestor (`FIREBASE_DB_URL` em `Config.kt`). Não precisa configurar nada aqui.

**Segurança:** cada aparelho só consegue ler a própria lista, e só se souber o MAC **e** a KEY juntos.
Ninguém consegue listar os aparelhos. Só você, logado no Gestor, envia, bloqueia ou tira listas.

## Observação
O APK vem assinado com chave de teste, ótimo para instalar direto nos aparelhos dos clientes.
Para publicar na Google Play é preciso criar uma chave própria de assinatura.

## Modo leve (TV Box)
O app reduz animações, usa imagens mais leves, guarda menos itens em memória e usa um buffer de vídeo menor
para não travar em TV Box simples. No modo "automático" isso liga sozinho em toda TV/TV Box e em aparelhos com pouca memória.
Para mudar: Configurações > Desempenho > Modo leve (automático / ligado / desligado). Reabra o app depois de mudar.

## Correção de travamentos (nov/2026)
- Canais começam a tocar com 3 s guardados (antes 1 s) e, depois de uma travada, só voltam com 5 s: acaba o "trava-solta".
- Se o servidor congelar a conexão, o app reconecta em até 10 s sozinho ("Reconectando…") em vez de ficar parado.
- Até 15 reconexões automáticas nos canais ao vivo antes de mostrar erro (antes eram 3).
- Wi-Fi mantido em desempenho máximo enquanto o vídeo toca (TV Box costuma economizar energia e travar).
- Leitor de MPEG-TS mais tolerante: menos tela preta ao trocar de canal.
- Na TV ao Vivo, a prévia só troca quando o cliente para de navegar (a lista não engasga mais ao descer com o controle).
- Se um canal ao vivo travar duas vezes seguidas, o app passa sozinho a pedir a versão HLS (.m3u8) do canal, como os apps tipo Smarters fazem. Se o servidor não tiver HLS, volta para o formato normal.

## TV / TV Box (23/11/2026)
- Sem botões de WhatsApp na TV e na TV Box (o número de renovação continua escrito no cartão "Seu sinal").
- **Buscar**, **Atualizar** e **Configurações** agora ficam no menu da esquerda, onde o controle chega.
  O botão **Menu** do controle (se tiver) também abre as Configurações.
