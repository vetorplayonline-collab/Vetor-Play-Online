# Vetor Play Online — App Android

Player de listas IPTV (M3U e Xtream Codes) com a identidade amarela e preta da Vetor Play Online.
Funciona em **celular, tablet, Android TV e TV Box** (Android 5.0 ou mais novo).

## O que o app faz
- **Entrada por Login** (servidor + usuário + senha, padrão Xtream Codes), **Link M3U** ou **Arquivo .m3u** do aparelho
- Várias listas salvas, com troca rápida nas Configurações
- Abas **Início**, **TV ao Vivo**, **Filmes** e **Séries**, com categorias da própria lista
- Séries agrupadas por **temporada e episódio**, com "Assistir" que continua de onde parou
- **Continuar assistindo** (filmes e episódios voltam no ponto em que pararam)
- **Favoritos** (segure o dedo ou o botão OK do controle sobre o item) e **Recentes**
- **Busca** em tudo ao mesmo tempo, ignorando acentos
- Player Media3/ExoPlayer: HLS (.m3u8), MPEG-TS, MP4, MKV; troca de canal com CH+/CH− ou setas do controle,
  ajuste de tela (ajustar / esticar / zoom), legendas e faixas de áudio, reconexão automática nos canais ao vivo
- **Jogos do dia**: aba com os jogos (ao vivo, próximos e encerrados), placar e o botão **Onde assistir** que abre o canal direto da lista do cliente
- **Controle dos pais**: categorias adultas bloqueadas por PIN (padrão **0000**, dá para trocar)

## Como gerar o APK — opção 1: GitHub (sem instalar nada no computador)
1. Crie uma conta grátis em github.com e clique em **New repository** (pode ser privado).
2. Na página do repositório, clique em **uploading an existing file** e arraste **todo o conteúdo** desta pasta
   (inclusive a pasta `.github`). Clique em **Commit changes**.
3. Abra a aba **Actions**. O processo "Gerar APK Vetor Play Online" começa sozinho (leva uns 5–8 minutos).
4. Quando ficar verde ✔, clique nele e baixe **VetorPlayOnline-apk** em *Artifacts*. Dentro do .zip está o `VetorPlayOnline.apk`.

> Dica: se a pasta `.github` não subir pelo navegador, crie o arquivo pelo botão **Add file → Create new file**
> com o nome `.github/workflows/build-apk.yml` e cole o conteúdo do arquivo.

## Como gerar o APK — opção 2: Android Studio
1. Instale o Android Studio (developer.android.com/studio).
2. **File → Open** e escolha esta pasta. Aguarde a sincronização.
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. O arquivo sai em `app/build/outputs/apk/`.

## Instalar no aparelho
Copie o APK para o celular/TV Box e abra. Se o Android pedir, permita **"Instalar apps desconhecidos"**.
Na TV Box, o app Downloader ou um pendrive resolvem.

## Personalizar para a sua revenda
Arquivo `app/src/main/java/br/com/vetorplayonline/app/Config.kt`:
- `DEFAULT_SERVER` — coloque seu DNS (ex.: `"http://meudns.com:8080"`). O campo servidor some e o cliente só digita usuário e senha.
- `WHATSAPP_SUPORTE` — seu número com DDI e DDD (ex.: `"5544999999999"`) para mostrar o botão de suporte no login.

**Logo oficial:** substitua `app/src/main/res/drawable-nodpi/logo_vetor.png` pela sua logo (PNG quadrado, de preferência 512×512)
mantendo o mesmo nome. Os ícones do app ficam em `res/mipmap-*` e o banner da Android TV em `res/drawable-xhdpi/tv_banner.png`.

**Cores:** `app/src/main/res/values/colors.xml` (`vetor_yellow`, `vetor_orange`, `vetor_black`).

**Versão:** ao lançar uma atualização, aumente `versionCode` e `versionName` em `app/build.gradle.kts`.

## Jogos do dia — como funciona
O app lê um arquivo **JSON** com a agenda e, ao tocar em "Onde assistir", procura o canal pelo nome na lista do cliente
(ex.: "SporTV" encontra "SPORTV FHD" e "SporTV HD"; se houver mais de uma versão, o cliente escolhe).
A tela se atualiza sozinha a cada 1 minuto.

**Jeito mais simples de manter a agenda:** use o arquivo `jogos.json` que já está neste projeto.
1. No GitHub, abra `jogos.json`, toque no lápis ✏️, edite os jogos do dia e salve (**Commit changes**). Dá para fazer pelo celular.
2. O link do arquivo é: `https://raw.githubusercontent.com/SEU_USUARIO/SEU_REPOSITORIO/main/jogos.json`
   (o repositório precisa ser **público** para o app conseguir ler).
3. Coloque esse link em `Config.kt` (`JOGOS_URL`) antes de gerar o APK, ou no app em **Configurações › Jogos do dia**.

Campos de cada jogo: `competicao`, `horario`, `status` (vazio = em breve; `35'` = ao vivo; `INT` = intervalo; `FIM DE JOGO`),
`time1`, `time2`, `img_time1_url`, `img_time2_url` (escudos, opcional), `placar_time1`, `placar_time2` e `canais`
(nomes como aparecem na sua lista). Também aceita o formato `"times": {"time1": {"nome","img_url","placar"}}`
usado por painéis de revenda, então dá para apontar para o JSON de um painel que você contratar.

## Ativação pelo MAC (Painel MAC do Gestor)
Cada aparelho mostra um **MAC** e uma **KEY** na tela de entrada. O cliente te manda esses dados e você envia a lista
pelo **Gestor Vetor Play Online › Painel MAC** (ou pelo botão **📺 Lista** na aba Aplicativos). No aparelho, o cliente toca em
**"Já enviei · Buscar minha lista"**. O app também confere o painel toda vez que abre, então se você trocar o servidor,
bloquear ou liberar o cliente, o aparelho já recebe a mudança.

O app já vem apontando para o banco do Gestor (`FIREBASE_DB_URL` em `Config.kt`). Não precisa configurar nada aqui.

**Segurança:** cada aparelho só consegue ler a própria lista, e só se souber o MAC **e** a KEY juntos.
Ninguém consegue listar os aparelhos. Só você, logado no Gestor, envia, bloqueia ou tira listas.

## Observação
O APK vem assinado com chave de teste, ótimo para instalar direto nos aparelhos dos clientes.
Para publicar na Google Play é preciso criar uma chave própria de assinatura.
