package br.com.vetorplayonline.app.data

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/** Dados da assinatura do cliente (painel Xtream Codes). */
data class AccountInfo(
    val expiresAt: Long?,        // milissegundos; null = sem vencimento
    val status: String,          // Active, Expired, Banned, Disabled...
    val maxConnections: String,
    val activeConnections: String,
    val checkedAt: Long
) {
    /** Dias que faltam (negativo = vencido). */
    val daysLeft: Long?
        get() = expiresAt?.let { TimeUnit.MILLISECONDS.toDays(it - System.currentTimeMillis()) }

    val isExpired: Boolean
        get() = status.equals("Expired", true) || (expiresAt != null && expiresAt < System.currentTimeMillis())

    fun toJson(): String = JSONObject().apply {
        put("exp", expiresAt ?: -1L); put("status", status)
        put("max", maxConnections); put("active", activeConnections); put("at", checkedAt)
    }.toString()

    companion object {
        fun fromJson(s: String?): AccountInfo? = try {
            if (s.isNullOrBlank()) null else JSONObject(s).let {
                AccountInfo(
                    expiresAt = it.optLong("exp", -1L).takeIf { v -> v > 0 },
                    status = it.optString("status"),
                    maxConnections = it.optString("max"),
                    activeConnections = it.optString("active"),
                    checkedAt = it.optLong("at")
                )
            }
        } catch (e: Exception) { null }
    }
}

object AccountRepository {

    data class Creds(val server: String, val user: String, val pass: String)

    /** Pega servidor/usuário/senha da lista (login Xtream ou link get.php). */
    fun credentials(p: Playlist): Creds? {
        if (p.kind == "xtream" && p.server.isNotBlank() && p.username.isNotBlank()) {
            return Creds(p.server.trimEnd('/'), p.username, p.password)
        }
        if (p.kind == "url") {
            val uri = Uri.parse(p.url)
            val user = uri.getQueryParameter("username")
            val pass = uri.getQueryParameter("password")
            if (!user.isNullOrBlank() && pass != null && uri.scheme != null && uri.host != null) {
                val port = if (uri.port > 0) ":${uri.port}" else ""
                return Creds("${uri.scheme}://${uri.host}$port", user, pass)
            }
        }
        return null
    }

    fun supports(p: Playlist) = credentials(p) != null

    /** Consulta o painel. Retorna null se a lista não for de um painel Xtream. */
    suspend fun fetch(p: Playlist): AccountInfo? = withContext(Dispatchers.IO) {
        val c = credentials(p) ?: return@withContext null
        val url = "${c.server}/player_api.php?username=${Uri.encode(c.user)}&password=${Uri.encode(c.pass)}"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("User-Agent", PlaylistRepository.DEFAULT_UA)
        }
        try {
            if (conn.responseCode != 200) return@withContext null
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val ui = JSONObject(text).optJSONObject("user_info") ?: return@withContext null
            // exp_date vem em segundos (texto ou número); vazio/null = ilimitado
            val expRaw = ui.opt("exp_date")
            val expSec = when (expRaw) {
                is Number -> expRaw.toLong()
                is String -> expRaw.trim().toLongOrNull()
                else -> null
            }
            AccountInfo(
                expiresAt = expSec?.takeIf { it > 0 }?.times(1000),
                status = ui.optString("status"),
                maxConnections = ui.optString("max_connections"),
                activeConnections = ui.optString("active_cons"),
                checkedAt = System.currentTimeMillis()
            )
        } finally {
            conn.disconnect()
        }
    }
}
