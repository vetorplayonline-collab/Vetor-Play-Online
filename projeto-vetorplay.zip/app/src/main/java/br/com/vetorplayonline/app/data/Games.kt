package br.com.vetorplayonline.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Um jogo do dia. */
data class Game(
    val competition: String,
    val time: String,
    val status: String,
    val team1: String,
    val team2: String,
    val logo1: String?,
    val logo2: String?,
    val score1: String,
    val score2: String,
    val channels: List<String>
) {
    enum class State { LIVE, BREAK, SOON, FINISHED }

    val state: State
        get() {
            val s = status.trim().uppercase()
            return when {
                s.contains("FIM") || s.contains("ENCERR") || s == "FT" -> State.FINISHED
                s == "INT" || s.contains("INTERVALO") || s == "HT" -> State.BREAK
                Regex("^\\d+'").containsMatchIn(s) || s.contains("AO VIVO") || s == "LIVE" -> State.LIVE
                else -> State.SOON
            }
        }

    val statusLabel: String
        get() = when (state) {
            State.FINISHED -> "FIM DE JOGO"
            State.BREAK -> "INTERVALO"
            State.LIVE -> if (status.contains("'")) "AO VIVO • ${status.trim()}" else "AO VIVO"
            State.SOON -> status.trim().ifEmpty { "EM BREVE" }.uppercase()
        }
}

object GamesRepository {

    /**
     * Baixa a lista de jogos. Aceita dois formatos:
     *  - { "jogos": [ ... ] }  ou  [ ... ]
     *  - cada jogo com "times": {"time1": {"nome","img_url","placar"}, "time2": {...}}
     *    ou com "time1","time2","img_time1_url","img_time2_url","placar_time1","placar_time2"
     *  - "canais": [ {"nome": "SporTV"} ]  ou  [ "SporTV" ]
     */
    suspend fun fetch(url: String): List<Game> = withContext(Dispatchers.IO) {
        val sep = if (url.contains('?')) '&' else '?'
        val conn = (URL("$url${sep}t=${System.currentTimeMillis() / 60000}").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("User-Agent", PlaylistRepository.DEFAULT_UA)
        }
        try {
            if (conn.responseCode != 200) throw IOException("Servidor dos jogos respondeu ${conn.responseCode}")
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }.trim()
            parse(text)
        } finally {
            conn.disconnect()
        }
    }

    fun parse(text: String): List<Game> {
        val arr: JSONArray = if (text.startsWith("[")) JSONArray(text)
        else JSONObject(text).let { it.optJSONArray("jogos") ?: it.optJSONArray("games") ?: JSONArray() }

        val out = ArrayList<Game>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val times = o.optJSONObject("times")
            val t1 = times?.optJSONObject("time1")
            val t2 = times?.optJSONObject("time2")
            val channels = ArrayList<String>()
            o.optJSONArray("canais")?.let { ca ->
                for (j in 0 until ca.length()) {
                    val c = ca.opt(j)
                    val name = when (c) {
                        is JSONObject -> c.optString("nome")
                        is String -> c
                        else -> ""
                    }
                    if (name.isNotBlank()) channels.add(name.trim())
                }
            }
            out.add(
                Game(
                    competition = o.optString("competicao").ifBlank { o.optString("campeonato") },
                    time = o.optString("horario"),
                    status = o.optString("status"),
                    team1 = t1?.optString("nome").orEmpty().ifBlank { o.optString("time1") },
                    team2 = t2?.optString("nome").orEmpty().ifBlank { o.optString("time2") },
                    logo1 = (t1?.optString("img_url").orEmpty().ifBlank { o.optString("img_time1_url") }).takeIf { it.startsWith("http") },
                    logo2 = (t2?.optString("img_url").orEmpty().ifBlank { o.optString("img_time2_url") }).takeIf { it.startsWith("http") },
                    score1 = t1?.optString("placar").orEmpty().ifBlank { o.optString("placar_time1", "0") }.ifBlank { "0" },
                    score2 = t2?.optString("placar").orEmpty().ifBlank { o.optString("placar_time2", "0") }.ifBlank { "0" },
                    channels = channels
                )
            )
        }
        // Ao vivo primeiro, depois os próximos, encerrados por último
        return out.sortedBy {
            when (it.state) {
                Game.State.LIVE, Game.State.BREAK -> 0
                Game.State.SOON -> 1
                Game.State.FINISHED -> 2
            }
        }
    }

    // ------------------------------------------------------------------
    // Encontrar o canal do jogo na lista do cliente
    // ------------------------------------------------------------------
    private val brackets = Regex("\\[.*?]|\\(.*?\\)")
    private val noise = Regex("\\b(fhd|uhd|hd|sd|4k|h265|hevc|alt|backup|br)\\b")
    private val nonAlnum = Regex("[^a-z0-9]+")

    private fun key(s: String): String =
        PlaylistRepository.normalize(s).replace(brackets, " ").replace(noise, " ").replace(nonAlnum, "")

    /** Canais da lista que correspondem ao nome (ex.: "SporTV 2" -> "SPORTV 2 FHD", "SporTV 2 HD"). */
    fun findChannels(name: String): List<Channel> {
        val k = key(name)
        if (k.isEmpty()) return emptyList()
        val live = PlaylistRepository.all.filter { it.type == ContentType.LIVE }
        val exact = live.filter { key(it.name) == k }
        if (exact.isNotEmpty()) return exact
        // "sportv" não deve casar com "sportv2": só aceita sobra que não seja número
        return live.filter {
            val ck = key(it.name)
            ck.startsWith(k) && !ck.substring(k.length).firstOrNull().let { c -> c != null && c.isDigit() }
        }.take(12)
    }
}
