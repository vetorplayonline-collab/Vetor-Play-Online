package br.com.vetorplayonline.app.ui

import br.com.vetorplayonline.app.data.Channel

/** Fila de reprodução compartilhada com o player (evita passar listas enormes por Intent). */
object PlayerQueue {
    var items: List<Channel> = emptyList()
        private set
    var index: Int = 0

    fun set(list: List<Channel>, start: Int) {
        items = list
        index = start.coerceIn(0, (list.size - 1).coerceAtLeast(0))
    }

    val current: Channel? get() = items.getOrNull(index)
}
