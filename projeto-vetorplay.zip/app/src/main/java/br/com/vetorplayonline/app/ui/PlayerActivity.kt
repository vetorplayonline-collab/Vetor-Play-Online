package br.com.vetorplayonline.app.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.Channel
import br.com.vetorplayonline.app.data.ContentType
import br.com.vetorplayonline.app.data.PlaylistRepository

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private lateinit var zapInfo: TextView
    private lateinit var errorBox: View
    private lateinit var errorText: TextView
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnFav: ImageButton

    private val handler = Handler(Looper.getMainLooper())
    private var retries = 0
    private val current: Channel? get() = PlayerQueue.current
    private val isLive: Boolean get() = current?.type == ContentType.LIVE

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("Ajustar à tela", "Esticar", "Zoom")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (PlayerQueue.items.isEmpty()) { finish(); return }
        setContentView(R.layout.activity_player)
        hideSystemBars()

        playerView = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        titleView = findViewById(R.id.playerTitle)
        subtitleView = findViewById(R.id.playerSubtitle)
        zapInfo = findViewById(R.id.zapInfo)
        errorBox = findViewById(R.id.errorBox)
        errorText = findViewById(R.id.errorText)
        btnPrev = findViewById(R.id.btnPrev)
        btnNext = findViewById(R.id.btnNext)
        btnFav = findViewById(R.id.btnFav)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        btnPrev.setOnClickListener { step(-1) }
        btnNext.setOnClickListener { step(+1) }
        btnFav.setOnClickListener { toggleFav() }
        findViewById<View>(R.id.btnAspect).setOnClickListener { cycleResize() }
        findViewById<View>(R.id.btnRetry).setOnClickListener { retries = 0; playCurrent() }
        findViewById<View>(R.id.btnSkip).setOnClickListener { step(+1) }

        playerView.setShowPreviousButton(false)
        playerView.setShowNextButton(false)
        playerView.resizeMode = resizeModes[VetorApp.prefs.resizeMode.coerceIn(0, 2)]
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
            topBar.visibility = visibility
            if (visibility != View.VISIBLE) hideSystemBars()
        })

        val renderers = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        player = ExoPlayer.Builder(this, renderers).build().also { p ->
            playerView.player = p
            p.addListener(listener)
            p.playWhenReady = true
        }
        playerView.requestFocus()
        playCurrent()
    }

    // ---------------------------------------------------------------------------------
    // Reprodução
    // ---------------------------------------------------------------------------------
    private fun playCurrent() {
        val ch = current ?: return
        val p = player ?: return
        handler.removeCallbacksAndMessages(null)
        errorBox.visibility = View.GONE

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ch.userAgent ?: PlaylistRepository.DEFAULT_UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        ch.referer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }
        val factory = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))

        val item = MediaItem.Builder()
            .setUri(Uri.parse(ch.url))
            .setMediaId(ch.url)
            .apply { if (ch.url.contains(".m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()

        p.setMediaSource(factory.createMediaSource(item))
        val resume = if (ch.type != ContentType.LIVE) VetorApp.prefs.position(ch.url) else 0L
        if (resume > 0) {
            p.seekTo(resume)
            toast("Continuando de ${fmt(resume)}")
        }
        p.prepare()
        p.play()

        updateInfo()
        VetorApp.prefs.addRecent(ch.url)
    }

    private fun updateInfo() {
        val ch = current ?: return
        val many = PlayerQueue.items.size > 1
        titleView.text = ch.name
        subtitleView.text = when (ch.type) {
            ContentType.LIVE -> "${ch.group}  •  ${PlayerQueue.index + 1}/${PlayerQueue.items.size}"
            ContentType.SERIES -> listOfNotNull(
                ch.seriesName,
                if (ch.season > 0) "T${ch.season} E${ch.episode}" else null
            ).joinToString("  •  ")
            ContentType.MOVIE -> ch.group
        }
        btnPrev.visibility = if (many) View.VISIBLE else View.GONE
        btnNext.visibility = if (many) View.VISIBLE else View.GONE
        updateFavIcon()
        if (ch.type == ContentType.LIVE && many) showZap("${PlayerQueue.index + 1}  ${ch.name}")
    }

    private fun step(delta: Int) {
        val size = PlayerQueue.items.size
        if (size <= 1) return
        saveProgress()
        val next = PlayerQueue.index + delta
        PlayerQueue.index = if (isLive) (next + size) % size else next.coerceIn(0, size - 1)
        retries = 0
        playCurrent()
    }

    private fun showZap(text: String) {
        zapInfo.text = text
        zapInfo.visibility = View.VISIBLE
        zapInfo.removeCallbacks(hideZap)
        zapInfo.postDelayed(hideZap, 3000)
    }

    private val hideZap = Runnable { zapInfo.visibility = View.GONE }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) {
                retries = 0
                errorBox.visibility = View.GONE
            }
            if (state == Player.STATE_ENDED) {
                val ch = current ?: return
                when (ch.type) {
                    ContentType.LIVE -> { player?.seekToDefaultPosition(); player?.prepare() }
                    ContentType.MOVIE -> { VetorApp.prefs.savePosition(ch.url, 0); finish() }
                    ContentType.SERIES -> {
                        VetorApp.prefs.savePosition(ch.url, 0)
                        if (PlayerQueue.index < PlayerQueue.items.size - 1) {
                            PlayerQueue.index++
                            playCurrent()
                        } else finish()
                    }
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val p = player ?: return
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            // Canais ao vivo costumam oscilar: tenta de novo sozinho algumas vezes
            if (isLive && retries < 3) {
                retries++
                handler.postDelayed({ playCurrent() }, 1500L * retries)
                return
            }
            errorText.text = friendlyError(error)
            errorBox.visibility = View.VISIBLE
            findViewById<View>(R.id.btnSkip).visibility =
                if (PlayerQueue.items.size > 1) View.VISIBLE else View.GONE
            findViewById<View>(R.id.btnRetry).requestFocus()
        }
    }

    private fun friendlyError(e: PlaybackException): String = when (e.errorCode) {
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
            "Este conteúdo está fora do ar ou o acesso foi negado pelo servidor."
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Falha de conexão. Verifique sua internet e tente novamente."
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "Conteúdo não encontrado no servidor."
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
            "Formato de vídeo não suportado por este aparelho."
        else -> "Não foi possível reproduzir (${e.errorCodeName})."
    }

    // ---------------------------------------------------------------------------------
    // Botões
    // ---------------------------------------------------------------------------------
    private fun favKey(ch: Channel): String =
        if (ch.type == ContentType.SERIES && ch.seriesName != null) "series:${ch.seriesName}" else ch.url

    private fun toggleFav() {
        val ch = current ?: return
        val added = VetorApp.prefs.toggleFavorite(favKey(ch))
        toast(if (added) "★ Adicionado aos favoritos" else "Removido dos favoritos")
        updateFavIcon()
    }

    private fun updateFavIcon() {
        val ch = current ?: return
        btnFav.setImageResource(
            if (VetorApp.prefs.isFavorite(favKey(ch))) R.drawable.ic_star else R.drawable.ic_star_outline
        )
    }

    private fun cycleResize() {
        val next = (VetorApp.prefs.resizeMode + 1) % resizeModes.size
        VetorApp.prefs.resizeMode = next
        playerView.resizeMode = resizeModes[next]
        toast(resizeNames[next])
    }

    // ---------------------------------------------------------------------------------
    // Controle remoto: CH+/CH- e setas para cima/baixo trocam de canal
    // ---------------------------------------------------------------------------------
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && PlayerQueue.items.size > 1) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> { step(+1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> { step(-1); return true }
                KeyEvent.KEYCODE_DPAD_UP -> if (isLive && !playerView.isControllerFullyVisible) { step(+1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN -> if (isLive && !playerView.isControllerFullyVisible) { step(-1); return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ---------------------------------------------------------------------------------
    // Ciclo de vida
    // ---------------------------------------------------------------------------------
    private fun saveProgress() {
        val ch = current ?: return
        val p = player ?: return
        if (ch.type == ContentType.LIVE) return
        val pos = p.currentPosition
        val dur = p.duration
        if (dur == C.TIME_UNSET || dur <= 0) return
        val keep = pos > 30_000 && pos < dur - 60_000
        VetorApp.prefs.savePosition(ch.url, if (keep) pos else 0)
    }

    override fun onStart() {
        super.onStart()
        val p = player ?: return
        if (isLive) p.seekToDefaultPosition()
        p.play()
    }

    override fun onStop() {
        super.onStop()
        saveProgress()
        player?.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.removeListener(listener)
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @SuppressLint("WrongConstant")
    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    companion object {
        fun fmt(ms: Long): String {
            val s = ms / 1000
            val h = s / 3600
            val m = (s % 3600) / 60
            val sec = s % 60
            return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
        }
    }
}
