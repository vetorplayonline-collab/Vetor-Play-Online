package br.com.vetorplayonline.app

import android.app.Application
import br.com.vetorplayonline.app.data.Prefs
import br.com.vetorplayonline.app.ui.DeviceUi
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

class VetorApp : Application(), ImageLoaderFactory {

    lateinit var prefs: Prefs
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
    }

    override fun newImageLoader(): ImageLoader {
        val lite = br.com.vetorplayonline.app.ui.DeviceUi.lite(this)
        return ImageLoader.Builder(this)
            .crossfade(!lite)                       // sem animação de entrada nas imagens no modo leve
            .allowRgb565(true)                      // fotos sem transparência usam metade da memória
            .respectCacheHeaders(false)             // logos não precisam ser baixados de novo toda hora
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(if (lite) 0.10 else 0.20).build() }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("logos"))
                    .maxSizeBytes(if (lite) 80L * 1024 * 1024 else 150L * 1024 * 1024)
                    .build()
            }
            .build()
    }

    companion object {
        lateinit var instance: VetorApp
            private set
        val prefs: Prefs get() = instance.prefs
    }
}
