package br.com.vetorplayonline.app

import android.app.Application
import br.com.vetorplayonline.app.data.Prefs
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

class VetorApp : Application(), ImageLoaderFactory {

    lateinit var prefs: Prefs
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
    }

    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .crossfade(true)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.20).build() }
        .diskCache {
            DiskCache.Builder()
                .directory(cacheDir.resolve("logos"))
                .maxSizeBytes(150L * 1024 * 1024)
                .build()
        }
        .build()

    companion object {
        lateinit var instance: VetorApp
            private set
        val prefs: Prefs get() = instance.prefs
    }
}
