package br.com.vetorplayonline.app.ui

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import br.com.vetorplayonline.app.data.MacActivation
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.Playlist
import br.com.vetorplayonline.app.data.PlaylistRepository
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class SettingsActivity : AppCompatActivity() {

    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DeviceUi.lockPhonePortrait(this)
        setContentView(R.layout.activity_settings)
        val prefs = VetorApp.prefs

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        listBox = findViewById(R.id.playlistBox)

        findViewById<View>(R.id.btnAddList).setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
        findViewById<View>(R.id.btnUpdateList).setOnClickListener {
            val pl = prefs.active() ?: return@setOnClickListener
            Loader.load(this, pl, force = pl.kind != "file") { n ->
                toast("Lista atualizada: $n itens")
                Loader.openMain(this)
            }
        }

        val lock = findViewById<MaterialSwitch>(R.id.switchAdult)
        lock.isChecked = prefs.adultLock
        var ignore = false
        lock.setOnCheckedChangeListener { sw, checked ->
            if (ignore) return@setOnCheckedChangeListener
            if (checked) {
                prefs.adultLock = true
                Session.adultUnlocked = false
            } else {
                // Para desligar o bloqueio é preciso o PIN
                ignore = true; sw.isChecked = true; ignore = false
                PinDialog.ask(this, "Desligar bloqueio adulto") {
                    prefs.adultLock = false
                    ignore = true; sw.isChecked = false; ignore = false
                }
            }
        }
        findViewById<View>(R.id.btnChangePin).setOnClickListener { PinDialog.change(this) }

        val btnLite = findViewById<com.google.android.material.button.MaterialButton>(R.id.btnLite)
        fun showLite() {
            btnLite.text = when (prefs.liteMode) {
                "on" -> "Modo leve: ligado"
                "off" -> "Modo leve: desligado"
                else -> "Modo leve: automático (" + (if (DeviceUi.isLowEnd(this)) "ativo" else "inativo") + ")"
            }
        }
        showLite()
        btnLite.setOnClickListener {
            prefs.liteMode = when (prefs.liteMode) { "auto" -> "on"; "on" -> "off"; else -> "auto" }
            showLite()
            toast("Reabra o app para aplicar em tudo")
        }

        if (MacActivation.enabled) {
            findViewById<View>(R.id.macSection).visibility = View.VISIBLE
            findViewById<TextView>(R.id.macInfo).text =
                "MAC: ${MacActivation.mac(this)}\nKEY: ${MacActivation.key(this)}"
            findViewById<View>(R.id.btnMacSync).setOnClickListener {
                lifecycleScope.launch {
                    try {
                        when (val n = MacActivation.sync(this@SettingsActivity)) {
                            null -> toast("Aparelho ainda não cadastrado no painel")
                            else -> { toast("$n lista(s) do painel atualizada(s)"); renderPlaylists() }
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        toast(Loader.friendly(e))
                    }
                }
            }
        }

        findViewById<View>(R.id.btnClearHistory).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Limpar histórico?")
                .setMessage("Apaga a lista de assistidos recentemente e as posições salvas dos filmes.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Limpar") { _, _ -> prefs.clearHistory(); toast("Histórico apagado") }
                .show()
        }

        findViewById<View>(R.id.btnUpdate).setOnClickListener { Updater.check(this, manual = true) }

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) { "1.0" }
        findViewById<TextView>(R.id.aboutText).text =
            "Vetor Play Online • versão $version\nReprodutor de listas M3U e Xtream Codes.\nO conteúdo das listas é fornecido pelo seu provedor."
    }

    override fun onResume() {
        super.onResume()
        renderPlaylists()
        Updater.resumePending(this)
    }

    private fun renderPlaylists() {
        val prefs = VetorApp.prefs
        listBox.removeAllViews()
        val activeId = prefs.active()?.id
        val inflater = LayoutInflater.from(this)
        prefs.playlists().forEach { pl ->
            val row = inflater.inflate(R.layout.item_playlist, listBox, false)
            row.findViewById<RadioButton>(R.id.plRadio).isChecked = pl.id == activeId
            row.findViewById<TextView>(R.id.plName).text = pl.name
            row.findViewById<TextView>(R.id.plDetail).text = when (pl.kind) {
                "xtream" -> "Xtream • ${pl.server} • ${pl.username}"
                "file" -> "Arquivo do aparelho"
                else -> "Link M3U"
            }
            row.setOnClickListener { activate(pl) }
            row.findViewById<View>(R.id.plDelete).setOnClickListener { confirmDelete(pl) }
            listBox.addView(row)
        }
        if (prefs.playlists().isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Nenhuma lista cadastrada."
                setPadding(dp(8), dp(8), dp(8), dp(8))
            })
        }
    }

    private fun activate(pl: Playlist) {
        val prefs = VetorApp.prefs
        if (pl.id == PlaylistRepository.loadedPlaylistId && pl.id == prefs.activeId) {
            toast("Essa já é a lista em uso"); return
        }
        val previous = prefs.activeId
        prefs.activeId = pl.id
        Session.adultUnlocked = false
        Loader.load(this, pl, force = false, onError = { prefs.activeId = previous; renderPlaylists() }) {
            Loader.openMain(this)
        }
    }

    private fun confirmDelete(pl: Playlist) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Excluir \"${pl.name}\"?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Excluir") { _, _ ->
                val prefs = VetorApp.prefs
                prefs.remove(pl.id)
                PlaylistRepository.deleteCache(this, pl.id)
                if (prefs.playlists().isEmpty()) {
                    startActivity(
                        Intent(this, LoginActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    )
                    finish()
                } else {
                    renderPlaylists()
                }
            }
            .show()
    }
}
