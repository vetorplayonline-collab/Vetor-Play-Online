package br.com.vetorplayonline.app.ui

import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.Channel
import br.com.vetorplayonline.app.data.ContentType
import br.com.vetorplayonline.app.data.Game
import br.com.vetorplayonline.app.data.GamesRepository
import br.com.vetorplayonline.app.data.PlaylistRepository
import coil.load
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Aba "Jogos": jogos do dia com botão para abrir o canal que transmite. */
class GamesFragment : Fragment() {

    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var info: TextView
    private val adapter = GamesAdapter { name -> openChannel(name) }
    private val handler = Handler(Looper.getMainLooper())
    private val autoRefresh = object : Runnable {
        override fun run() {
            load(silent = true)
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View =
        inflater.inflate(R.layout.fragment_games, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        swipe = view.findViewById(R.id.gamesSwipe)
        info = view.findViewById(R.id.gamesInfo)
        swipe.setColorSchemeColors(ContextCompat.getColor(requireContext(), R.color.vetor_yellow))
        swipe.setProgressBackgroundColorSchemeColor(ContextCompat.getColor(requireContext(), R.color.surface_2))
        swipe.setOnRefreshListener { load(silent = false) }
        val list = view.findViewById<RecyclerView>(R.id.gamesList)
        if (DeviceUi.useWideLayout(requireContext())) {
            // TV: dois jogos por linha; os títulos ocupam a linha inteira
            val glm = GridLayoutManager(requireContext(), 2)
            glm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int) = if (adapter.isHeader(position)) 2 else 1
            }
            list.layoutManager = glm
        } else {
            list.layoutManager = LinearLayoutManager(requireContext())
        }
        list.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        if (!isHidden) startAuto()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(autoRefresh)
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) handler.removeCallbacks(autoRefresh) else startAuto()
    }

    private fun startAuto() {
        handler.removeCallbacks(autoRefresh)
        handler.post(autoRefresh)
    }

    private fun load(silent: Boolean) {
        val url = VetorApp.prefs.gamesUrl
        if (url.isBlank()) {
            swipe.isRefreshing = false
            adapter.submit(emptyList())
            info.visibility = View.VISIBLE
            info.text = "Os jogos do dia ainda não foram configurados.\n\nEm Configurações › Jogos do dia, informe o link da agenda de jogos."
            return
        }
        if (!silent) swipe.isRefreshing = true
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val games = GamesRepository.fetch(url)
                adapter.submit(games)
                info.visibility = if (games.isEmpty()) View.VISIBLE else View.GONE
                info.text = "Nenhum jogo cadastrado para hoje."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                if (adapter.itemCount == 0) {
                    info.visibility = View.VISIBLE
                    info.text = "Não foi possível carregar os jogos.\n${Loader.friendly(e)}\n\nPuxe para baixo para tentar de novo."
                }
            } finally {
                swipe.isRefreshing = false
            }
        }
    }

    /** Procura o canal na lista do cliente e abre. Se houver várias versões (HD, FHD...), pergunta qual. */
    private fun openChannel(name: String) {
        val found = GamesRepository.findChannels(name)
        when {
            found.isEmpty() -> requireContext().toast("O canal \"$name\" não foi encontrado na sua lista")
            found.size == 1 -> play(found[0])
            else -> MaterialAlertDialogBuilder(requireContext())
                .setTitle("Assistir em $name")
                .setItems(found.map { it.name }.toTypedArray()) { _, which -> play(found[which]) }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun play(ch: Channel) {
        // Fila = canais da mesma categoria, para poder trocar com CH+/CH-
        val group = PlaylistRepository.tiles(ContentType.LIVE, ch.group).mapNotNull { it.channel }
        val queue = if (group.contains(ch)) group else listOf(ch)
        Nav.play(requireActivity(), queue, queue.indexOf(ch).coerceAtLeast(0))
    }

    // ----------------------------------------------------------------------------------
    class GamesAdapter(private val onChannel: (String) -> Unit) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        private sealed class Row {
            data class Header(val text: String) : Row()
            data class Item(val game: Game) : Row()
        }

        private var rows: List<Row> = emptyList()

        fun submit(games: List<Game>) {
            val active = games.filter { it.state != Game.State.FINISHED }
            val done = games.filter { it.state == Game.State.FINISHED }
            val r = ArrayList<Row>()
            if (active.isNotEmpty()) { r.add(Row.Header("Jogos de hoje")); active.forEach { r.add(Row.Item(it)) } }
            if (done.isNotEmpty()) { r.add(Row.Header("Encerrados")); done.forEach { r.add(Row.Item(it)) } }
            rows = r
            notifyDataSetChanged()
        }

        override fun getItemCount() = rows.size
        fun isHeader(position: Int) = rows.getOrNull(position) is Row.Header
        override fun getItemViewType(position: Int) = if (rows[position] is Row.Header) 0 else 1

        class HeaderVH(val text: TextView) : RecyclerView.ViewHolder(text)

        class GameVH(v: View) : RecyclerView.ViewHolder(v) {
            val competition: TextView = v.findViewById(R.id.gCompetition)
            val status: TextView = v.findViewById(R.id.gStatus)
            val logo1: ImageView = v.findViewById(R.id.gLogo1)
            val logo2: ImageView = v.findViewById(R.id.gLogo2)
            val team1: TextView = v.findViewById(R.id.gTeam1)
            val team2: TextView = v.findViewById(R.id.gTeam2)
            val score: TextView = v.findViewById(R.id.gScore)
            val time: TextView = v.findViewById(R.id.gTime)
            val channels: LinearLayout = v.findViewById(R.id.gChannels)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inf = LayoutInflater.from(parent.context)
            return if (viewType == 0) {
                val tv = inf.inflate(R.layout.item_section_header, parent, false) as TextView
                HeaderVH(tv)
            } else GameVH(inf.inflate(R.layout.item_game, parent, false))
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val row = rows[position]) {
                is Row.Header -> (holder as HeaderVH).text.text = row.text
                is Row.Item -> bindGame(holder as GameVH, row.game)
            }
        }

        private fun bindGame(h: GameVH, g: Game) {
            val ctx = h.itemView.context
            h.competition.text = g.competition
            h.status.text = g.statusLabel
            val (bg, fg) = when (g.state) {
                Game.State.LIVE -> R.color.live_green to R.color.vetor_black
                Game.State.BREAK -> R.color.vetor_yellow to R.color.vetor_black
                Game.State.SOON -> R.color.vetor_orange to R.color.vetor_black
                Game.State.FINISHED -> R.color.card_stroke to R.color.text_secondary
            }
            h.status.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, bg))
            h.status.setTextColor(ContextCompat.getColor(ctx, fg))

            h.team1.text = g.team1
            h.team2.text = g.team2
            h.logo1.load(g.logo1) { placeholder(R.drawable.ic_ball); error(R.drawable.ic_ball); fallback(R.drawable.ic_ball) }
            h.logo2.load(g.logo2) { placeholder(R.drawable.ic_ball); error(R.drawable.ic_ball); fallback(R.drawable.ic_ball) }
            h.score.text = if (g.state == Game.State.SOON) "VS" else "${g.score1} - ${g.score2}"
            h.time.text = g.time

            h.channels.removeAllViews()
            val inf = LayoutInflater.from(ctx)
            if (g.state == Game.State.FINISHED) {
                val t = inf.inflate(R.layout.item_game_channel, h.channels, false)
                t.findViewById<TextView>(R.id.gcBadge).visibility = View.GONE
                t.findViewById<TextView>(R.id.gcName).text = "Transmissão encerrada"
                t.isFocusable = false
                t.isClickable = false
                h.channels.addView(t)
                return
            }
            if (g.channels.isEmpty()) {
                val t = inf.inflate(R.layout.item_game_channel, h.channels, false)
                t.findViewById<TextView>(R.id.gcBadge).visibility = View.GONE
                t.findViewById<TextView>(R.id.gcName).text = "Canal ainda não informado"
                t.isFocusable = false
                h.channels.addView(t)
                return
            }
            g.channels.forEach { name ->
                val row = inf.inflate(R.layout.item_game_channel, h.channels, false)
                row.findViewById<TextView>(R.id.gcName).text = name
                row.setOnClickListener { onChannel(name) }
                row.tvFocusEffect(null)
                h.channels.addView(row)
            }
        }
    }
}
