package br.com.vetorplayonline.app.data

import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Um programa da grade (horários em milissegundos). */
data class EpgProgram(val title: String, val description: String, val start: Long, val end: Long) {
    fun isNow(now: Long = System.currentTimeMillis()) = now in start until end
    fun progress(now: Long = System.currentTimeMillis()): Int =
        if (end <= start) 0 else (((now - start) * 100) / (end - start)).toInt().coerceIn(0, 100)
}

/**
 * Programação dos canais ao vivo, buscada no painel Xtream da lista (player_api.php).
 * Só funciona com listas de painel (login Xtream ou link get.php com usuário e senha).
 */
object EpgRepository {

    private const val CACHE_MS = 30 * 60 * 1000L
    private val cache = object : LinkedHashMap<String, Pair<Long, List<EpgProgram>>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, List<EpgProgram>>>?) = size > 80
    }
    private val idRegex = Regex("/(\\d+)(?:\\.[A-Za-z0-9]+)?$")

    /** A lista ativa tem painel para consultar a programação? */
    fun supported(p: Playlist?): Boolean = p != null && AccountRepository.credentials(p) != null

    /** Número do canal no painel, tirado do endereço (…/usuario/senha/12345.ts). */
    fun streamId(ch: Channel): String? {
        val path = Uri.parse(ch.url).path ?: return null
        return idRegex.find(path)?.groupValues?.get(1)
    }

    /** Programas do canal (cache de 30 min). Lista vazia = sem programação. */
    suspend fun programs(p: Playlist, ch: Channel): List<EpgProgram> = withContext(Dispatchers.IO) {
        val c = AccountRepository.credentials(p) ?: return@withContext emptyList()
        val id = streamId(ch) ?: return@withContext emptyList()
        val key = "${p.id}:$id"
        synchronized(cache) {
            cache[key]?.let { if (System.currentTimeMillis() - it.first < CACHE_MS) return@withContext it.second }
        }
        val base = "${c.server}/player_api.php?username=${Uri.encode(c.user)}&password=${Uri.encode(c.pass)}"
        // Grade completa (vários dias); se o painel não tiver, pega só os próximos programas
        var list = runCatching { parse(get("$base&action=get_simple_data_table&stream_id=$id")) }.getOrDefault(emptyList())
        if (list.isEmpty()) {
            list = runCatching { parse(get("$base&action=get_short_epg&stream_id=$id&limit=30")) }.getOrDefault(emptyList())
        }
        synchronized(cache) { cache[key] = System.currentTimeMillis() to list }
        list
    }

    private fun get(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("User-Agent", PlaylistRepository.DEFAULT_UA)
        }
        try {
            if (conn.responseCode != 200) return ""
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(text: String): List<EpgProgram> {
        if (text.isBlank()) return emptyList()
        val arr: JSONArray = JSONObject(text).optJSONArray("epg_listings") ?: return emptyList()
        val out = ArrayList<EpgProgram>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val start = seconds(o.opt("start_timestamp")) ?: continue
            val end = seconds(o.opt("stop_timestamp")) ?: seconds(o.opt("end_timestamp")) ?: continue
            if (end <= start) continue
            out.add(EpgProgram(b64(o.optString("title")), b64(o.optString("description")), start * 1000, end * 1000))
        }
        return out.distinctBy { it.start }.sortedBy { it.start }
    }

    private fun seconds(v: Any?): Long? = when (v) {
        is Number -> v.toLong()
        is String -> v.trim().toLongOrNull()
        else -> null
    }?.takeIf { it > 0 }

    /** O painel manda título e descrição em Base64; se não for, usa o texto como veio. */
    private fun b64(s: String): String {
        if (s.isBlank()) return ""
        return try {
            val t = String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8).trim()
            if (t.isEmpty() || t.any { it == '�' || (it < ' ' && it != '\n' && it != '\r' && it != '\t') }) s else t
        } catch (e: IllegalArgumentException) {
            s
        }
    }
}
