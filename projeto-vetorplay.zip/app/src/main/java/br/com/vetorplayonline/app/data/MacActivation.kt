package br.com.vetorplayonline.app.data

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import br.com.vetorplayonline.app.Config
import br.com.vetorplayonline.app.VetorApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Ativação por MAC + KEY.
 * Cada aparelho tem um MAC e uma KEY fixos. A revenda cadastra a lista para esse
 * MAC/KEY pelo Gestor Vetor Play Online (aba "Painel MAC") e o app busca a lista no Realtime Database.
 * O documento fica em devices/{sha256("MAC:KEY")}: só quem sabe o MAC E a KEY consegue ler.
 */
object MacActivation {

    val enabled: Boolean
        get() = Config.FIREBASE_DB_URL.isNotBlank()

    private fun sha256(s: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    @SuppressLint("HardwareIds")
    private fun seed(ctx: Context): ByteArray {
        val androidId = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "vetor"
        return sha256("vetorplay:$androidId")
    }

    /** MAC no formato 0A:1B:2C:3D:4E:5F (gerado do aparelho, não muda ao reinstalar). */
    fun mac(ctx: Context): String {
        val h = seed(ctx)
        val bytes = h.copyOfRange(0, 6)
        bytes[0] = ((bytes[0].toInt() and 0xFC) or 0x02).toByte()
        return bytes.joinToString(":") { "%02X".format(it) }
    }

    /** KEY de 6 números. */
    fun key(ctx: Context): String {
        val h = seed(ctx)
        val n = ((h[10].toLong() and 0xFF) shl 16) or ((h[11].toLong() and 0xFF) shl 8) or (h[12].toLong() and 0xFF)
        return "%06d".format(n % 1_000_000)
    }

    /** Mesmo cálculo do painel: sha256("MAC:KEY"), MAC em maiúsculas. */
    fun docId(mac: String, key: String) = hex(sha256("${mac.uppercase().trim()}:${key.trim()}"))

    fun xtreamUrl(server: String, user: String, pass: String): String {
        var host = server.trim().trimEnd('/')
        if (!host.startsWith("http://") && !host.startsWith("https://")) host = "http://$host"
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
        return "$host/get.php?username=${enc(user)}&password=${enc(pass)}&type=m3u_plus&output=ts"
    }

    /** Busca as listas cadastradas para este aparelho. null = aparelho ainda não cadastrado. */
    suspend fun fetch(ctx: Context): List<Playlist>? = withContext(Dispatchers.IO) {
        val id = docId(mac(ctx), key(ctx))
        val url = "${Config.FIREBASE_DB_URL.trimEnd('/')}/devices/$id.json"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
        }
        try {
            when (conn.responseCode) {
                200 -> Unit
                401, 403 -> throw IOException("Acesso ao painel bloqueado (publique as regras do banco do Gestor).")
                else -> throw IOException("Painel respondeu com erro ${conn.responseCode}.")
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            if (text.isEmpty() || text == "null") return@withContext null
            val root = JSONObject(text)
            if (!root.optBoolean("active", true)) return@withContext emptyList()

            // O Realtime Database pode devolver a lista como array [..] ou objeto {"0":..}
            val items = ArrayList<JSONObject>()
            when (val pls = root.opt("playlists")) {
                is JSONArray -> for (i in 0 until pls.length()) pls.optJSONObject(i)?.let { items.add(it) }
                is JSONObject -> pls.keys().asSequence().sorted().forEach { k -> pls.optJSONObject(k)?.let { items.add(it) } }
            }
            val out = ArrayList<Playlist>()
            items.forEachIndexed { i, f ->
                fun str(k: String) = f.optString(k).trim()
                val kind = str("kind").ifBlank { "url" }
                val name = str("name").ifBlank { "Vetor Play Online" }
                if (kind == "xtream") {
                    val server = str("server").ifBlank { Config.DEFAULT_SERVER }
                    if (server.isNotBlank() && str("username").isNotBlank()) {
                        out.add(Playlist("mac$i", name, "xtream", xtreamUrl(server, str("username"), str("password")),
                            server.trimEnd('/'), str("username"), str("password")))
                    }
                } else {
                    val u = str("url")
                    if (u.startsWith("http")) out.add(Playlist("mac$i", name, "url", u))
                }
            }
            out
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Aplica no aparelho as listas enviadas pelo painel.
     * Retorna o número de listas recebidas (0 = nenhuma; null = aparelho não cadastrado).
     */
    suspend fun sync(ctx: Context): Int? {
        val remote = fetch(ctx) ?: return null
        val prefs = VetorApp.prefs
        val local = prefs.playlists().filter { it.id.startsWith("mac") }
        // remove as que saíram do painel
        local.filter { l -> remote.none { it.id == l.id } }.forEach {
            prefs.remove(it.id); PlaylistRepository.deleteCache(ctx, it.id)
        }
        // adiciona/atualiza; se o endereço mudou, apaga a cópia salva para baixar de novo
        remote.forEach { r ->
            val old = local.firstOrNull { it.id == r.id }
            if (old != null && old.url != r.url) PlaylistRepository.deleteCache(ctx, r.id)
            prefs.addOrUpdate(r)
        }
        if (prefs.active() == null || prefs.playlists().none { it.id == prefs.activeId }) {
            prefs.activeId = remote.firstOrNull()?.id ?: prefs.playlists().firstOrNull()?.id
        }
        return remote.size
    }
}
