package br.com.vetorplayonline.app.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.com.vetorplayonline.app.Config
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.Channel
import br.com.vetorplayonline.app.data.ContentType
import br.com.vetorplayonline.app.data.EpgProgram
import br.com.vetorplayonline.app.data.EpgRepository
import br.com.vetorplayonline.app.data.PlaylistRepository
import coil.load
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * TV ao Vivo para TV / TV Box / tablet deitado, em 4 colunas:
 * categorias | canais | prévia do canal + programação | dias da programação.
 *
 * Controle remoto:
 * - passar o foco numa categoria abre os canais dela; passar o foco num canal mostra a prévia
 * - OK no canal = tela cheia; segurar OK ou botão azul = favoritar
 * - amarelo = ordem A–Z; verde = buscar
 *
 * A prévia só existe com a tela visível: é criada no onStart e destruída no onStop,
 * então nunca fica áudio tocando com o app fora da tela.
 */
@OptIn(UnstableApi::class)
class LiveTvActivity : AppCompatActivity() {

    private data class CatItem(val key: String, val label: String, val count: Int, val locked: Boolean)

    private lateinit var catList: RecyclerView
    private lateinit var chList: RecyclerView
    private lateinit var epgList: RecyclerView
    private lateinit var dayList: RecyclerView
    private lateinit var previewBox: View
    private lateinit var playerView: PlayerView
    private lateinit var previewLogo: ImageView
    private lateinit var previewSmallLogo: ImageView
    private lateinit var previewLoading: ProgressBar
    private lateinit var previewMsg: TextView
    private lateinit var previewTitle: TextView
    private lateinit var previewNow: TextView
    private lateinit var headCategory: TextView
    private lateinit var headCount: TextView
    private lateinit var headPosition: TextView
    private lateinit var headGuide: TextView
    private lateinit var sortBtn: TextView
    private lateinit var chEmpty: TextView
    private lateinit var epgEmpty: TextView
    private lateinit var epgLoading: ProgressBar

    private val catAdapter = CatAdapter()
    private val chAdapter = ChannelAdapter()
    private val epgAdapter = EpgAdapter()
    private val dayAdapter = DayAdapter()

    private var categories: List<CatItem> = emptyList()
    private var catIndex = 0
    private var channels: List<Channel> = emptyList()
    private var chIndex = 0                 // canal com o cursor (cabeçalho "Canal X de N")
    private var previewing: Channel? = null // canal tocando na prévia
    private var programs: List<EpgProgram> = emptyList()
    private var dayOffset = 0               // 0 = hoje
    private val dayOffsets = (-1..5).toList()

    private var player: ExoPlayer? = null
    private var previewRetried = false
    private val handler = Handler(Looper.getMainLooper())
    private var catJob: Job? = null
    private var chJob: Job? = null
    private var epgJob: Job? = null

    private val visible: Boolean get() = lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)

    // ==================================================================================
    // Tela
    // ==================================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Loader.ensureLoaded(this)) return
        setContentView(R.layout.activity_live_tv)
        hideSystemBars()

        catList = findViewById(R.id.liveCategories)
        chList = findViewById(R.id.liveChannels)
        epgList = findViewById(R.id.liveEpg)
        dayList = findViewById(R.id.liveDays)
        previewBox = findViewById(R.id.previewBox)
        playerView = findViewById(R.id.previewPlayer)
        previewLogo = findViewById(R.id.previewLogo)
        previewSmallLogo = findViewById(R.id.previewSmallLogo)
        previewLoading = findViewById(R.id.previewLoading)
        previewMsg = findViewById(R.id.previewMsg)
        previewTitle = findViewById(R.id.previewTitle)
        previewNow = findViewById(R.id.previewNow)
        headCategory = findViewById(R.id.headCategory)
        headCount = findViewById(R.id.headCount)
        headPosition = findViewById(R.id.headPosition)
        headGuide = findViewById(R.id.headGuide)
        sortBtn = findViewById(R.id.btnSortLive)
        chEmpty = findViewById(R.id.liveEmpty)
        epgEmpty = findViewById(R.id.epgEmpty)
        epgLoading = findViewById(R.id.epgLoading)
        findViewById<TextView>(R.id.footWhats).text = "Renovação: ${Config.WHATSAPP_EXIBICAO}"

        setup(catList, catAdapter)
        setup(chList, chAdapter)
        setup(epgList, epgAdapter)
        setup(dayList, dayAdapter)
        chList.setItemViewCacheSize(if (DeviceUi.lite(this)) 8 else 16)

        previewBox.setOnClickListener { previewing?.let { openFull(it) } }
        sortBtn.setOnClickListener { toggleSort() }
        updateSortLabel()

        dayAdapter.notifyDataSetChanged()
        catIndex = savedInstanceState?.getInt(STATE_CAT, 0) ?: 0
        val savedCh = savedInstanceState?.getString(STATE_CH)
        buildCategories {
            catIndex = catIndex.coerceIn(0, (categories.size - 1).coerceAtLeast(0))
            loadChannels(focusFirst = true, previewUrl = savedCh ?: PlayerQueue.current?.takeIf { it.type == ContentType.LIVE }?.url)
        }
    }

    private fun setup(rv: RecyclerView, adapter: RecyclerView.Adapter<*>) {
        rv.layoutManager = LinearLayoutManager(this)
        rv.itemAnimator = null
        rv.setHasFixedSize(true)
        rv.adapter = adapter
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(STATE_CAT, catIndex)
        previewing?.let { outState.putString(STATE_CH, it.url) }
    }

    override fun onStart() {
        super.onStart()
        if (!::playerView.isInitialized) return
        // Voltou da tela cheia: segue no canal em que o cliente parou (pode ter trocado com CH+/CH-)
        val fromPlayer = PlayerQueue.current
        if (fromPlayer != null && fromPlayer.type == ContentType.LIVE && PlayerQueue.items === channels) {
            chIndex = PlayerQueue.index
            previewing = fromPlayer
            chAdapter.notifyDataSetChanged()
            focusRow(chList, chIndex)
            updateHeader()
            showChannelInfo(fromPlayer)
            loadEpg(fromPlayer, delayMs = 0)
        }
        createPlayer()
        previewing?.let { startPreview(it) }
    }

    override fun onStop() {
        // Nada toca fora da tela: cancela tudo que estava agendado e destrói a prévia
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @SuppressLint("WrongConstant")
    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    // ==================================================================================
    // Categorias
    // ==================================================================================
    private fun buildCategories(then: (() -> Unit)? = null) {
        catJob?.cancel()
        catJob = lifecycleScope.launch {
            val list = withContext(Dispatchers.Default) {
                val hide = Session.hideAdult
                val out = ArrayList<CatItem>()
                out.add(CatItem(CAT_ALL, "Todos", PlaylistRepository.visibleCount(ContentType.LIVE, hide), false))
                out.add(CatItem(CAT_FAV, "★ Favoritos", rawChannels(CAT_FAV).size, false))
                out.add(CatItem(CAT_RECENT, "Recentes", rawChannels(CAT_RECENT).size, false))
                out.add(CatItem(CAT_SEARCH, "Buscar", -1, false))
                PlaylistRepository.categories(ContentType.LIVE).forEach { cat ->
                    val locked = hide && PlaylistRepository.isAdult(cat)
                    out.add(CatItem(cat, if (locked) "🔒 $cat" else cat, PlaylistRepository.categorySize(ContentType.LIVE, cat), locked))
                }
                out
            }
            categories = list
            catAdapter.notifyDataSetChanged()
            then?.invoke()
        }
    }

    private fun onCategoryChosen(pos: Int, fromFocus: Boolean) {
        val item = categories.getOrNull(pos) ?: return
        if (item.key == CAT_SEARCH) {
            if (!fromFocus) startActivity(Intent(this, SearchActivity::class.java))
            return
        }
        if (pos == catIndex && channels.isNotEmpty()) return
        if (item.locked) {
            if (fromFocus) return
            PinDialog.ask(this, "Conteúdo adulto") {
                Session.adultUnlocked = true
                catIndex = pos
                buildCategories { loadChannels(focusFirst = false, previewUrl = previewing?.url) }
            }
            return
        }
        val old = catIndex
        catIndex = pos
        catAdapter.notifyItemChanged(old)
        catAdapter.notifyItemChanged(pos)
        loadChannels(focusFirst = false, previewUrl = previewing?.url)
    }

    // ==================================================================================
    // Canais
    // ==================================================================================
    private fun loadChannels(focusFirst: Boolean, previewUrl: String?) {
        val cat = categories.getOrNull(catIndex) ?: return
        chJob?.cancel()
        val hadFocus = chList.hasFocus()
        chJob = lifecycleScope.launch {
            val list = withContext(Dispatchers.Default) { sorted(cat.key, rawChannels(cat.key)) }
            channels = list
            val idx = previewUrl?.let { url -> list.indexOfFirst { it.url == url } } ?: -1
            chIndex = idx.coerceAtLeast(0)
            chAdapter.notifyDataSetChanged()
            chList.scrollToPosition(chIndex)
            headCategory.text = cat.label
            headCount.text = list.size.toString()
            updateHeader()
            chEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            chEmpty.text = when (cat.key) {
                CAT_FAV -> "Nenhum canal favorito.\nSegure OK sobre um canal (ou aperte o botão azul) para favoritar."
                CAT_RECENT -> "Nenhum canal assistido ainda."
                else -> "Nenhum canal nesta categoria."
            }
            if (hadFocus && list.isNotEmpty()) focusRow(chList, chIndex)
            if (focusFirst) {
                focusRow(catList, catIndex)
                // Primeira abertura: já mostra a prévia do primeiro canal (ou do último assistido)
                val first = list.getOrNull(chIndex)
                if (first != null && previewing == null) selectChannel(chIndex, delayMs = 600)
                else if (previewing != null) previewing?.let { showChannelInfo(it); loadEpg(it, 0) }
                if (list.isNotEmpty() && idx >= 0) focusRow(chList, chIndex)
            }
        }
    }

    /** Canais de uma categoria (só TV ao vivo, respeitando o bloqueio adulto). */
    private fun rawChannels(key: String): List<Channel> {
        val prefs = VetorApp.prefs
        val hide = Session.hideAdult
        fun ok(c: Channel) = c.type == ContentType.LIVE && !(hide && PlaylistRepository.isAdult(c.group))
        return when (key) {
            CAT_ALL -> PlaylistRepository.allTiles(ContentType.LIVE, hide).mapNotNull { it.channel }
            CAT_FAV -> PlaylistRepository.tilesForKeys(prefs.favorites().toList()).mapNotNull { it.channel }
                .filter(::ok).sortedBy { it.name.lowercase() }
            CAT_RECENT -> PlaylistRepository.tilesForKeys(prefs.recents()).mapNotNull { it.channel }.filter(::ok)
            CAT_SEARCH -> emptyList()
            else -> PlaylistRepository.tiles(ContentType.LIVE, key).mapNotNull { it.channel }
        }
    }

    private fun sorted(key: String, list: List<Channel>): List<Channel> {
        if (!VetorApp.prefs.sortAlpha || key == CAT_RECENT) return list
        return list.map { PlaylistRepository.normalize(it.name) to it }.sortedBy { it.first }.map { it.second }
    }

    /** Cursor no canal: atualiza cabeçalho e, depois de um instante parado, troca a prévia. */
    private fun selectChannel(pos: Int, delayMs: Long) {
        val ch = channels.getOrNull(pos) ?: return
        chIndex = pos
        updateHeader()
        handler.removeCallbacks(previewTask)
        if (ch.url == previewing?.url) return
        pendingPreview = ch
        handler.postDelayed(previewTask, delayMs)
    }

    private var pendingPreview: Channel? = null
    private val previewTask = Runnable {
        val ch = pendingPreview ?: return@Runnable
        if (!visible) return@Runnable
        val old = previewing
        previewing = ch
        notifyChannel(old)
        notifyChannel(ch)
        showChannelInfo(ch)
        startPreview(ch)
        loadEpg(ch, delayMs = 0)
    }

    private fun notifyChannel(ch: Channel?) {
        ch ?: return
        val i = channels.indexOfFirst { it.url == ch.url }
        if (i >= 0) chAdapter.notifyItemChanged(i)
    }

    private fun onChannelClick(pos: Int) {
        val ch = channels.getOrNull(pos) ?: return
        // TV: o foco já escolheu o canal, então OK abre direto. Toque: 1º toque = prévia, 2º = tela cheia
        if (pos == chIndex && (chList.hasFocus() || ch.url == previewing?.url)) openFull(ch)
        else selectChannel(pos, delayMs = 0)
    }

    private fun openFull(ch: Channel) {
        val idx = channels.indexOfFirst { it.url == ch.url }
        val queue = if (idx >= 0) channels else listOf(ch)
        handler.removeCallbacksAndMessages(null)
        // Libera o decodificador antes de abrir a tela cheia (TV Box fraca não aguenta dois)
        releasePlayer()
        previewing = ch
        PlayerQueue.set(queue, idx.coerceAtLeast(0))
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun toggleFavorite(ch: Channel) {
        val added = VetorApp.prefs.toggleFavorite(ch.url)
        toast(if (added) "★ Adicionado aos favoritos" else "Removido dos favoritos")
        notifyChannel(ch)
        // Atualiza a contagem de favoritos (e a lista, se estiver nela)
        val inFav = categories.getOrNull(catIndex)?.key == CAT_FAV
        buildCategories { if (inFav) loadChannels(focusFirst = false, previewUrl = previewing?.url) }
    }

    private fun toggleSort() {
        VetorApp.prefs.sortAlpha = !VetorApp.prefs.sortAlpha
        updateSortLabel()
        toast(if (VetorApp.prefs.sortAlpha) "Canais de A a Z" else "Canais na ordem da lista")
        loadChannels(focusFirst = false, previewUrl = channels.getOrNull(chIndex)?.url)
    }

    private fun updateSortLabel() {
        val on = VetorApp.prefs.sortAlpha
        sortBtn.text = if (on) "A–Z ✓" else "A–Z"
        sortBtn.setTextColor(ContextCompat.getColor(this, if (on) R.color.vetor_yellow else R.color.text_secondary))
    }

    private fun updateHeader() {
        headPosition.text = if (channels.isEmpty()) "Nenhum canal" else "Canal ${chIndex + 1} de ${channels.size}"
    }

    private fun showChannelInfo(ch: Channel) {
        previewTitle.text = ch.name
        previewNow.text = ch.group
        headGuide.text = "Guia de programação  •  ${ch.name}"
        previewSmallLogo.load(ch.logo) {
            placeholder(R.drawable.ic_tv); error(R.drawable.ic_tv); fallback(R.drawable.ic_tv)
        }
        previewLogo.load(ch.logo) {
            placeholder(R.drawable.ic_tv); error(R.drawable.ic_tv); fallback(R.drawable.ic_tv)
        }
    }

    // ==================================================================================
    // Prévia (player pequeno)
    // ==================================================================================
    private fun createPlayer() {
        if (player != null) return
        val lite = DeviceUi.lite(this)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(if (lite) 6_000 else 10_000, if (lite) 15_000 else 30_000, 1_000, 2_000)
            .setTargetBufferBytes(if (lite) 8 * 1024 * 1024 else C.LENGTH_UNSET)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        // A prévia é pequena: não precisa de mais que 720p (alivia a TV Box)
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(buildUponParameters().setMaxVideoSize(1280, 720).setExceedRendererCapabilitiesIfNecessary(false))
        }
        player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(AudioAttributes.DEFAULT, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .build().also { p ->
                p.addListener(previewListener)
                playerView.player = p
            }
    }

    private fun releasePlayer() {
        player?.let {
            it.removeListener(previewListener)
            it.release()
        }
        player = null
        if (::playerView.isInitialized) playerView.player = null
    }

    private fun startPreview(ch: Channel) {
        val p = player ?: return
        if (!visible) return
        previewRetried = false
        previewMsg.visibility = View.GONE
        previewLogo.visibility = View.VISIBLE
        previewLoading.visibility = View.VISIBLE

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ch.userAgent ?: PlaylistRepository.DEFAULT_UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(12_000)
            .setReadTimeoutMs(15_000)
        ch.referer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }
        val factory = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))
        val item = MediaItem.Builder()
            .setUri(Uri.parse(ch.url))
            .setMediaId(ch.url)
            .apply { if (ch.url.contains(".m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        p.setMediaSource(factory.createMediaSource(item))
        p.prepare()
        p.playWhenReady = visible
    }

    private val previewListener = object : Player.Listener {
        override fun onRenderedFirstFrame() {
            previewLogo.visibility = View.GONE
        }

        override fun onPlaybackStateChanged(state: Int) {
            previewLoading.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (state == Player.STATE_READY) previewMsg.visibility = View.GONE
            if (state == Player.STATE_ENDED && visible) {
                player?.seekToDefaultPosition()
                player?.prepare()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            previewLoading.visibility = View.GONE
            val p = player ?: return
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition(); p.prepare(); return
            }
            val ch = previewing ?: return
            // Uma nova tentativa automática, só com a tela visível
            if (!previewRetried && visible) {
                previewRetried = true
                handler.postDelayed({ if (visible && previewing?.url == ch.url) { startPreview(ch); previewRetried = true } }, 2500)
                return
            }
            previewLogo.visibility = View.VISIBLE
            previewMsg.text = "Canal indisponível no momento"
            previewMsg.visibility = View.VISIBLE
        }
    }

    // ==================================================================================
    // Programação (EPG)
    // ==================================================================================
    private fun loadEpg(ch: Channel, delayMs: Long) {
        epgJob?.cancel()
        programs = emptyList()
        refreshEpg(loading = true)
        val playlist = VetorApp.prefs.active()
        if (!EpgRepository.supported(playlist)) {
            refreshEpg(loading = false, message = "Programação indisponível nesta lista")
            return
        }
        epgJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            val list = try { EpgRepository.programs(playlist!!, ch) } catch (e: Exception) { emptyList() }
            if (previewing?.url != ch.url) return@launch
            programs = list
            refreshEpg(loading = false, message = if (list.isEmpty()) "Programação não encontrada para este canal" else null)
        }
    }

    /** Mostra os programas do dia escolhido na coluna de datas. */
    private fun refreshEpg(loading: Boolean, message: String? = null) {
        val (dayStart, dayEnd) = dayRange(dayOffset)
        val now = System.currentTimeMillis()
        val list = programs.filter { it.end > dayStart && it.start < dayEnd }
        epgAdapter.submit(list)
        epgLoading.visibility = if (loading) View.VISIBLE else View.GONE
        val msg = message ?: if (!loading && list.isEmpty() && programs.isNotEmpty()) "Sem programação para este dia" else null
        epgEmpty.text = msg ?: ""
        epgEmpty.visibility = if (msg != null && !loading) View.VISIBLE else View.GONE
        val nowIdx = list.indexOfFirst { it.isNow(now) }
        if (nowIdx >= 0) (epgList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(nowIdx, 0)
        else epgList.scrollToPosition(0)
        // Programa atual embaixo do nome do canal, na prévia
        val current = programs.firstOrNull { it.isNow(now) }
        previewing?.let { previewNow.text = current?.title?.takeIf { t -> t.isNotBlank() } ?: it.group }
    }

    private fun dayRange(offset: Int): Pair<Long, Long> {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, offset)
        val start = c.timeInMillis
        c.add(Calendar.DAY_OF_YEAR, 1)
        return start to c.timeInMillis
    }

    private fun onDayChosen(pos: Int) {
        val off = dayOffsets.getOrNull(pos) ?: return
        if (off == dayOffset) return
        val old = dayOffsets.indexOf(dayOffset)
        dayOffset = off
        dayAdapter.notifyItemChanged(old)
        dayAdapter.notifyItemChanged(pos)
        refreshEpg(loading = epgJob?.isActive == true)
    }

    // ==================================================================================
    // Controle remoto: setas entre colunas e botões coloridos
    // ==================================================================================
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_PROG_BLUE -> {
                    (channels.getOrNull(chIndex) ?: previewing)?.let { toggleFavorite(it) }; return true
                }
                KeyEvent.KEYCODE_PROG_YELLOW -> { toggleSort(); return true }
                KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_SEARCH -> {
                    startActivity(Intent(this, SearchActivity::class.java)); return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> if (moveBetweenColumns(event.keyCode)) return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun columnOf(v: View?): View? {
        v ?: return null
        if (v === previewBox) return previewBox
        return listOf(catList, chList, epgList, dayList).firstOrNull { it.findContainingItemView(v) != null }
    }

    private fun epgNowIndex(): Int {
        val now = System.currentTimeMillis()
        return epgAdapter.items.indexOfFirst { it.isNow(now) }.coerceAtLeast(0)
    }

    /** Leva o foco para a linha "certa" da coluna vizinha (a categoria aberta, o canal atual, o dia escolhido). */
    private fun moveBetweenColumns(key: Int): Boolean {
        val focused = currentFocus
        val col = columnOf(focused) ?: return false
        val dayPos = dayOffsets.indexOf(dayOffset)
        val epgHas = epgAdapter.itemCount > 0
        return when (col) {
            catList -> when (key) {
                KeyEvent.KEYCODE_DPAD_RIGHT -> channels.isNotEmpty() && focusRow(chList, chIndex)
                KeyEvent.KEYCODE_DPAD_LEFT -> true
                else -> false
            }
            chList -> when (key) {
                KeyEvent.KEYCODE_DPAD_LEFT -> focusRow(catList, catIndex)
                KeyEvent.KEYCODE_DPAD_RIGHT -> previewBox.requestFocus()
                else -> false
            }
            previewBox -> when (key) {
                KeyEvent.KEYCODE_DPAD_LEFT -> channels.isNotEmpty() && focusRow(chList, chIndex)
                KeyEvent.KEYCODE_DPAD_RIGHT -> focusRow(dayList, dayPos)
                KeyEvent.KEYCODE_DPAD_DOWN -> if (epgHas) focusRow(epgList, epgNowIndex()) else true
                KeyEvent.KEYCODE_DPAD_UP -> true
                else -> false
            }
            epgList -> when (key) {
                KeyEvent.KEYCODE_DPAD_LEFT -> channels.isNotEmpty() && focusRow(chList, chIndex)
                KeyEvent.KEYCODE_DPAD_RIGHT -> focusRow(dayList, dayPos)
                KeyEvent.KEYCODE_DPAD_UP -> {
                    val pos = (focused?.let { epgList.findContainingItemView(it) })?.let { epgList.getChildAdapterPosition(it) } ?: 0
                    if (pos <= 0) previewBox.requestFocus() else false
                }
                else -> false
            }
            dayList -> when (key) {
                KeyEvent.KEYCODE_DPAD_LEFT -> if (epgHas) focusRow(epgList, epgNowIndex()) else previewBox.requestFocus()
                KeyEvent.KEYCODE_DPAD_RIGHT -> true
                else -> false
            }
            else -> false
        }
    }

    /** Põe o foco numa linha da lista (rolando até ela se precisar). */
    private fun focusRow(rv: RecyclerView, pos: Int): Boolean {
        val count = rv.adapter?.itemCount ?: 0
        if (count == 0) return false
        val p = pos.coerceIn(0, count - 1)
        val vh = rv.findViewHolderForAdapterPosition(p)
        if (vh != null && vh.itemView.isShown) {
            vh.itemView.requestFocus()
            return true
        }
        (rv.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(p, rv.height / 3)
        rv.post { rv.findViewHolderForAdapterPosition(p)?.itemView?.requestFocus() }
        return true
    }

    // ==================================================================================
    // Adaptadores
    // ==================================================================================
    private inner class CatAdapter : RecyclerView.Adapter<CatAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.catName)
            val count: TextView = v.findViewById(R.id.catCount)
        }

        override fun getItemCount() = categories.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val vh = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_live_category, parent, false))
            vh.itemView.setOnClickListener {
                val pos = vh.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onCategoryChosen(pos, fromFocus = false)
            }
            // TV: parar o foco numa categoria abre os canais dela, sem precisar apertar OK
            vh.itemView.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                v.removeCallbacks(v.getTag(R.id.liveCategories) as? Runnable)
                if (hasFocus) {
                    val r = Runnable {
                        val pos = vh.bindingAdapterPosition
                        if (v.hasFocus() && pos != RecyclerView.NO_POSITION) onCategoryChosen(pos, fromFocus = true)
                    }
                    v.setTag(R.id.liveCategories, r)
                    v.postDelayed(r, 450)
                }
            }
            return vh
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val c = categories[position]
            h.name.text = c.label
            h.count.text = if (c.count >= 0) c.count.toString() else ""
            h.itemView.isActivated = position == catIndex
        }
    }

    private inner class ChannelAdapter : RecyclerView.Adapter<ChannelAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val number: TextView = v.findViewById(R.id.chNumber)
            val logo: ImageView = v.findViewById(R.id.chLogo)
            val name: TextView = v.findViewById(R.id.chName)
            val fav: ImageView = v.findViewById(R.id.chFav)
        }

        override fun getItemCount() = channels.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val vh = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_live_channel, parent, false))
            vh.itemView.setOnClickListener {
                val pos = vh.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onChannelClick(pos)
            }
            vh.itemView.setOnLongClickListener {
                val pos = vh.bindingAdapterPosition
                channels.getOrNull(pos)?.let { toggleFavorite(it) }
                true
            }
            vh.itemView.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
                val pos = vh.bindingAdapterPosition
                if (hasFocus && pos != RecyclerView.NO_POSITION) selectChannel(pos, delayMs = 550)
            }
            return vh
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val c = channels[position]
            h.number.text = (position + 1).toString()
            h.name.text = c.name
            val playing = c.url == previewing?.url
            h.itemView.isActivated = playing
            h.number.setTextColor(ContextCompat.getColor(this@LiveTvActivity, if (playing) R.color.vetor_yellow else R.color.text_secondary))
            h.fav.visibility = if (VetorApp.prefs.isFavorite(c.url)) View.VISIBLE else View.GONE
            h.logo.load(c.logo) {
                placeholder(R.drawable.ic_tv); error(R.drawable.ic_tv); fallback(R.drawable.ic_tv)
            }
        }
    }

    private inner class EpgAdapter : RecyclerView.Adapter<EpgAdapter.VH>() {
        var items: List<EpgProgram> = emptyList()
            private set
        private val hour = SimpleDateFormat("HH:mm", Locale.getDefault())

        fun submit(list: List<EpgProgram>) {
            items = list
            notifyDataSetChanged()
        }

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val dot: View = v.findViewById(R.id.epgDot)
            val title: TextView = v.findViewById(R.id.epgTitle)
            val progress: ProgressBar = v.findViewById(R.id.epgProgress)
            val desc: TextView = v.findViewById(R.id.epgDesc)
            val time: TextView = v.findViewById(R.id.epgTime)
        }

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val vh = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_live_epg, parent, false))
            // Com o foco no programa, mostra a descrição
            vh.itemView.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
                val p = items.getOrNull(vh.bindingAdapterPosition)
                vh.desc.visibility = if (hasFocus && !p?.description.isNullOrBlank()) View.VISIBLE else View.GONE
            }
            return vh
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val p = items[position]
            val now = p.isNow()
            h.title.text = p.title.ifBlank { "Sem título" }
            h.title.setTypeface(null, if (now) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            h.time.text = "${hour.format(Date(p.start))} – ${hour.format(Date(p.end))}"
            h.time.setTextColor(ContextCompat.getColor(this@LiveTvActivity, if (now) R.color.vetor_yellow else R.color.text_secondary))
            h.dot.isActivated = now
            h.itemView.isActivated = now
            h.progress.visibility = if (now) View.VISIBLE else View.GONE
            if (now) h.progress.progress = p.progress()
            h.desc.text = p.description
            h.desc.visibility = if (h.itemView.hasFocus() && p.description.isNotBlank()) View.VISIBLE else View.GONE
        }
    }

    private inner class DayAdapter : RecyclerView.Adapter<DayAdapter.VH>() {
        private val week = SimpleDateFormat("EEE", Locale("pt", "BR"))

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val number: TextView = v.findViewById(R.id.dayNumber)
            val name: TextView = v.findViewById(R.id.dayName)
        }

        override fun getItemCount() = dayOffsets.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val vh = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_live_day, parent, false))
            vh.itemView.setOnClickListener {
                val pos = vh.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onDayChosen(pos)
            }
            vh.itemView.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
                val pos = vh.bindingAdapterPosition
                if (hasFocus && pos != RecyclerView.NO_POSITION) onDayChosen(pos)
            }
            return vh
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val off = dayOffsets[position]
            val start = dayRange(off).first
            val c = Calendar.getInstance().apply { timeInMillis = start }
            h.number.text = String.format(Locale.US, "%02d", c.get(Calendar.DAY_OF_MONTH))
            h.name.text = if (off == 0) "HOJE" else week.format(Date(start)).replace(".", "").uppercase(Locale("pt", "BR"))
            h.itemView.isActivated = off == dayOffset
        }
    }

    companion object {
        private const val STATE_CAT = "live_cat"
        private const val STATE_CH = "live_ch"
        private const val CAT_ALL = "\u0000all"
        private const val CAT_FAV = "\u0000fav"
        private const val CAT_RECENT = "\u0000recent"
        private const val CAT_SEARCH = "\u0000search"
    }
}
