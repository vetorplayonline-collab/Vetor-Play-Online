package br.com.vetorplayonline.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import br.com.vetorplayonline.app.Config
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.MacActivation
import br.com.vetorplayonline.app.data.Playlist
import br.com.vetorplayonline.app.data.PlaylistRepository
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.util.UUID

/** Tela de entrada: Xtream Codes (usuário e senha), link M3U ou arquivo do aparelho. */
class LoginActivity : AppCompatActivity() {

    private var mode = MODE_XTREAM
    private var pickedFile: Uri? = null

    private lateinit var name: TextInputEditText
    private lateinit var server: TextInputEditText
    private lateinit var user: TextInputEditText
    private lateinit var pass: TextInputEditText
    private lateinit var m3uUrl: TextInputEditText
    private lateinit var boxXtream: View
    private lateinit var boxUrl: View
    private lateinit var boxFile: View
    private lateinit var fileLabel: TextView

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pickedFile = uri
            fileLabel.text = displayName(uri) ?: uri.lastPathSegment ?: "Arquivo selecionado"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DeviceUi.lockPhonePortrait(this)
        setContentView(if (DeviceUi.useWideLayout(this)) R.layout.activity_login_tv else R.layout.activity_login)

        name = findViewById(R.id.inputName)
        server = findViewById(R.id.inputServer)
        user = findViewById(R.id.inputUser)
        pass = findViewById(R.id.inputPass)
        m3uUrl = findViewById(R.id.inputUrl)
        boxXtream = findViewById(R.id.boxXtream)
        boxUrl = findViewById(R.id.boxUrl)
        boxFile = findViewById(R.id.boxFile)
        fileLabel = findViewById(R.id.fileLabel)

        val back = findViewById<View>(R.id.btnBack)
        back.visibility = if (VetorApp.prefs.playlists().isEmpty()) View.GONE else View.VISIBLE
        back.setOnClickListener { finish() }

        val toggle = findViewById<MaterialButtonToggleGroup>(R.id.modeToggle)
        toggle.check(R.id.modeXtream)
        toggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            mode = when (checkedId) {
                R.id.modeUrl -> MODE_URL
                R.id.modeFile -> MODE_FILE
                else -> MODE_XTREAM
            }
            boxXtream.visibility = if (mode == MODE_XTREAM) View.VISIBLE else View.GONE
            boxUrl.visibility = if (mode == MODE_URL) View.VISIBLE else View.GONE
            boxFile.visibility = if (mode == MODE_FILE) View.VISIBLE else View.GONE
        }

        if (Config.DEFAULT_SERVER.isNotBlank()) {
            server.setText(Config.DEFAULT_SERVER)
            findViewById<View>(R.id.layoutServer).visibility = View.GONE
        }
        val support = findViewById<MaterialButton>(R.id.btnSupport)
        support.visibility = if (Config.WHATSAPP_SUPORTE.isNotBlank()) View.VISIBLE else View.GONE
        support.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${Config.WHATSAPP_SUPORTE}")))
            } catch (e: Exception) {
                toast("WhatsApp: ${Config.WHATSAPP_SUPORTE}")
            }
        }

        setupMac()

        findViewById<MaterialButton>(R.id.btnPickFile).setOnClickListener {
            pickFile.launch(arrayOf("*/*"))
        }
        findViewById<MaterialButton>(R.id.btnEnter).setOnClickListener { submit() }
    }

    private fun setupMac() {
        if (!MacActivation.enabled) return
        findViewById<View>(R.id.boxMac).visibility = View.VISIBLE
        findViewById<View>(R.id.orManual).visibility = View.VISIBLE
        findViewById<TextView>(R.id.macText).text = MacActivation.mac(this)
        findViewById<TextView>(R.id.keyText).text = MacActivation.key(this)
        val status = findViewById<TextView>(R.id.macStatus)
        val btn = findViewById<MaterialButton>(R.id.btnMacSync)
        btn.setOnClickListener {
            btn.isEnabled = false
            status.visibility = View.VISIBLE
            status.text = "Procurando sua lista…"
            lifecycleScope.launch {
                try {
                    when (val n = MacActivation.sync(this@LoginActivity)) {
                        null -> status.text = "Aparelho ainda não cadastrado.\nEnvie o MAC e a KEY para a Vetor Play Online e tente de novo."
                        0 -> status.text = "Nenhuma lista ativa para este aparelho. Fale com a Vetor Play Online."
                        else -> {
                            status.text = "$n lista(s) encontrada(s)!"
                            val pl = VetorApp.prefs.active()
                            if (pl != null) Loader.load(this@LoginActivity, pl, force = false) { Loader.openMain(this@LoginActivity) }
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    status.text = Loader.friendly(e)
                } finally {
                    btn.isEnabled = true
                }
            }
        }
    }

    private fun submit() {
        clearErrors()
        val id = UUID.randomUUID().toString().take(8)
        val title = name.text?.toString()?.trim().orEmpty()

        when (mode) {
            MODE_XTREAM -> {
                var host = server.text?.toString()?.trim().orEmpty().trimEnd('/')
                val u = user.text?.toString()?.trim().orEmpty()
                val p = pass.text?.toString()?.trim().orEmpty()
                if (host.isEmpty()) return showError(R.id.layoutServer, "Informe o servidor (DNS)")
                if (u.isEmpty()) return showError(R.id.layoutUser, "Informe o usuário")
                if (p.isEmpty()) return showError(R.id.layoutPass, "Informe a senha")
                if (!host.startsWith("http://") && !host.startsWith("https://")) host = "http://$host"
                val url = "$host/get.php?username=${enc(u)}&password=${enc(p)}&type=m3u_plus&output=ts"
                val pl = Playlist(id, title.ifEmpty { u }, "xtream", url, host, u, p)
                save(pl)
            }
            MODE_URL -> {
                val url = m3uUrl.text?.toString()?.trim().orEmpty()
                if (!url.startsWith("http://") && !url.startsWith("https://"))
                    return showError(R.id.layoutUrl, "Cole o link completo, começando com http:// ou https://")
                save(Playlist(id, title.ifEmpty { "Minha lista" }, "url", url))
            }
            MODE_FILE -> {
                val uri = pickedFile
                if (uri == null) { toast("Escolha o arquivo .m3u"); return }
                val pl = Playlist(id, title.ifEmpty { displayName(uri) ?: "Lista do aparelho" }, "file", uri.toString())
                lifecycleScope.launch {
                    try {
                        PlaylistRepository.importFile(this@LoginActivity, id, uri)
                        save(pl)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        toast(Loader.friendly(e))
                    }
                }
            }
        }
    }

    private fun save(pl: Playlist) {
        val prefs = VetorApp.prefs
        val previous = prefs.activeId
        prefs.addOrUpdate(pl)
        prefs.activeId = pl.id
        Loader.load(this, pl, force = pl.kind != "file", onError = {
            // Não deu certo: desfaz para o usuário corrigir os dados
            prefs.remove(pl.id)
            PlaylistRepository.deleteCache(this, pl.id)
            prefs.activeId = previous
        }) { total ->
            toast("$total itens carregados")
            Loader.openMain(this)
        }
    }

    private fun clearErrors() {
        listOf(R.id.layoutServer, R.id.layoutUser, R.id.layoutPass, R.id.layoutUrl)
            .forEach { findViewById<TextInputLayout>(it).error = null }
    }

    private fun showError(layoutId: Int, msg: String) {
        val l = findViewById<TextInputLayout>(layoutId)
        l.error = msg
        l.requestFocus()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.substringBeforeLast('.') else null
        }
    } catch (e: Exception) { null }

    companion object {
        private const val MODE_XTREAM = 0
        private const val MODE_URL = 1
        private const val MODE_FILE = 2
    }
}
