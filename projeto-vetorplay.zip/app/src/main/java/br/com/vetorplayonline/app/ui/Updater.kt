package br.com.vetorplayonline.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.lifecycleScope
import br.com.vetorplayonline.app.Config
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Atualização do app sem reinstalar: confere a última versão publicada no GitHub
 * (Releases do repositório), baixa o APK novo e abre o instalador do Android.
 * As listas, favoritos e configurações do cliente continuam no aparelho.
 */
object Updater {

    data class Release(val code: Long, val name: String, val apkUrl: String, val notes: String)

    fun currentCode(activity: AppCompatActivity): Long = try {
        PackageInfoCompat.getLongVersionCode(activity.packageManager.getPackageInfo(activity.packageName, 0))
    } catch (e: Exception) { 0L }

    fun currentName(activity: AppCompatActivity): String = try {
        activity.packageManager.getPackageInfo(activity.packageName, 0).versionName ?: "1.0"
    } catch (e: Exception) { "1.0" }

    private suspend fun latest(): Release? = withContext(Dispatchers.IO) {
        if (Config.UPDATE_REPO.isBlank()) return@withContext null
        val conn = (URL("https://api.github.com/repos/${Config.UPDATE_REPO}/releases/latest").openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "VetorPlayOnline")
        }
        try {
            if (conn.responseCode != 200) return@withContext null
            val o = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val code = o.optString("tag_name").trim().removePrefix("v").removePrefix("V").toLongOrNull() ?: return@withContext null
            val assets = o.optJSONArray("assets") ?: return@withContext null
            var url: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.optJSONObject(i) ?: continue
                if (a.optString("name").endsWith(".apk", true)) { url = a.optString("browser_download_url"); break }
            }
            if (url.isNullOrBlank()) return@withContext null
            Release(code, o.optString("name").ifBlank { "1.0.$code" }, url, o.optString("body"))
        } finally {
            conn.disconnect()
        }
    }

    /** Confere se há versão nova. Automático: no máximo a cada 6 horas e sem avisos quando não houver nada. */
    fun check(activity: AppCompatActivity, manual: Boolean) {
        val prefs = VetorApp.prefs
        if (!manual && System.currentTimeMillis() - prefs.lastUpdateCheck < 6 * 3600_000L) return
        activity.lifecycleScope.launch {
            try {
                if (manual) activity.toast("Procurando atualização…")
                val rel = latest()
                prefs.lastUpdateCheck = System.currentTimeMillis()
                if (rel != null && rel.code > currentCode(activity)) {
                    MaterialAlertDialogBuilder(activity)
                        .setTitle("Nova versão disponível")
                        .setMessage("Vetor Play Online ${rel.name}\n\nA atualização instala por cima: suas listas e favoritos continuam.")
                        .setNegativeButton("Depois", null)
                        .setPositiveButton("Atualizar agora") { _, _ -> download(activity, rel) }
                        .show()
                } else if (manual) {
                    activity.toast("Você já está na versão mais recente (${currentName(activity)})")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                if (manual) activity.toast("Não foi possível verificar: ${Loader.friendly(e)}")
            }
        }
    }

    private fun download(activity: AppCompatActivity, rel: Release) {
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_update, null)
        val bar = view.findViewById<LinearProgressIndicator>(R.id.updateProgress)
        val text = view.findViewById<TextView>(R.id.updateText)
        val dialog = MaterialAlertDialogBuilder(activity).setTitle("Baixando atualização").setView(view).setCancelable(false).show()

        activity.lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val dir = File(if (Build.VERSION.SDK_INT >= 24) activity.cacheDir else (activity.externalCacheDir ?: activity.cacheDir), "updates")
                    dir.mkdirs()
                    dir.listFiles()?.forEach { it.delete() }
                    val out = File(dir, "VetorPlayOnline-${rel.code}.apk")
                    val conn = (URL(rel.apkUrl).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15_000
                        readTimeout = 60_000
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "VetorPlayOnline")
                    }
                    if (conn.responseCode != 200) throw IOException("Servidor respondeu ${conn.responseCode}")
                    val total = conn.contentLengthLong
                    conn.inputStream.use { input ->
                        out.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            var done = 0L
                            var lastPct = -1
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                done += n
                                if (total > 0) {
                                    val pct = (done * 100 / total).toInt()
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        withContext(Dispatchers.Main) {
                                            bar.isIndeterminate = false
                                            bar.progress = pct
                                            text.text = "$pct%  •  ${done / 1_048_576} de ${total / 1_048_576} MB"
                                        }
                                    }
                                }
                            }
                        }
                    }
                    conn.disconnect()
                    out
                }
                dialog.dismiss()
                install(activity, file)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                dialog.dismiss()
                MaterialAlertDialogBuilder(activity)
                    .setTitle("Não foi possível baixar")
                    .setMessage(Loader.friendly(e))
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun install(activity: AppCompatActivity, file: File) {
        // Android 8+: é preciso autorizar este app a instalar atualizações (uma vez só)
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            MaterialAlertDialogBuilder(activity)
                .setTitle("Permitir atualizações")
                .setMessage("Na próxima tela, ative \"Permitir desta fonte\" e volte. Depois toque em Instalar.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Continuar") { _, _ ->
                    pendingFile = file
                    try {
                        activity.startActivity(
                            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
                        )
                    } catch (e: Exception) {
                        activity.toast("Abra Configurações › Apps › Vetor Play Online e permita instalar apps.")
                    }
                }
                .show()
            return
        }
        val uri = if (Build.VERSION.SDK_INT >= 24)
            FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
        else Uri.fromFile(file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            activity.startActivity(intent)
        } catch (e: Exception) {
            activity.toast("Não foi possível abrir o instalador: ${e.message}")
        }
    }

    /** Arquivo baixado esperando a permissão de instalar; continua quando o usuário volta. */
    private var pendingFile: File? = null

    fun resumePending(activity: AppCompatActivity) {
        val f = pendingFile ?: return
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) return
        pendingFile = null
        if (f.exists()) install(activity, f)
    }
}
