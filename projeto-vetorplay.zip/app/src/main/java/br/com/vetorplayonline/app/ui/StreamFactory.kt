package br.com.vetorplayonline.app.ui

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import br.com.vetorplayonline.app.data.Channel
import br.com.vetorplayonline.app.data.ContentType
import br.com.vetorplayonline.app.data.PlaylistRepository

/**
 * Monta a fonte de vídeo de um canal com as configurações anti-travamento.
 *
 * - Canais ao vivo: tempo de espera curto (8 s). Se o servidor "congelar" a conexão,
 *   o app reconecta logo em vez de ficar 20 s com a imagem parada.
 * - O próprio player tenta de novo várias vezes antes de dar erro (oscilações rápidas
 *   do servidor passam despercebidas).
 * - Leitor de MPEG-TS tolerante: começa a mostrar imagem mesmo em canais que não mandam
 *   quadro-chave logo de cara (menos tela preta e menos "engasgo" ao trocar de canal).
 */
@OptIn(UnstableApi::class)
object StreamFactory {

    fun mediaSource(ctx: Context, ch: Channel): MediaSource {
        val live = ch.type == ContentType.LIVE
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ch.userAgent ?: PlaylistRepository.DEFAULT_UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (live) 8_000 else 15_000)
            .setReadTimeoutMs(if (live) 8_000 else 20_000)
        ch.referer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

        val extractors = DefaultExtractorsFactory()
            .setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                    DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
            )
            .setConstantBitrateSeekingEnabled(true)

        val factory = DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http), extractors)
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(if (live) 8 else 4))

        val item = MediaItem.Builder()
            .setUri(Uri.parse(ch.url))
            .setMediaId(ch.url)
            .apply { if (ch.url.contains(".m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        return factory.createMediaSource(item)
    }

    /**
     * Buffer do player.
     * Antes o canal começava com só 1 s guardado e voltava com 2 s: qualquer oscilação
     * maior que isso na internet ou no servidor travava a imagem. Agora começa com 3 s
     * e, depois de uma travada, só volta com 5 s guardados, o que evita o "trava-solta".
     */
    fun loadControl(lite: Boolean, preview: Boolean = false): DefaultLoadControl {
        val min = if (preview) 6_000 else if (lite) 15_000 else 20_000
        val max = if (preview) 15_000 else if (lite) 40_000 else 60_000
        return DefaultLoadControl.Builder()
            .setBufferDurationsMs(min, max, if (preview) 1_500 else 3_000, if (preview) 3_000 else 5_000)
            .setTargetBufferBytes(if (lite) (if (preview) 8 else 24) * 1024 * 1024 else androidx.media3.common.C.LENGTH_UNSET)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
    }
}
