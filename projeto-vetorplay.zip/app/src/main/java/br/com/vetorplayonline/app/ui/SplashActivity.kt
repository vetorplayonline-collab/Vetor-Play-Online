package br.com.vetorplayonline.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.PlaylistRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import br.com.vetorplayonline.app.data.MacActivation

class SplashActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var errorBox: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DeviceUi.lockPhonePortrait(this)
        setContentView(R.layout.activity_splash)
        status = findViewById(R.id.splashStatus)
        progress = findViewById(R.id.splashProgress)
        errorBox = findViewById(R.id.splashErrorBox)

        findViewById<Button>(R.id.btnRetry).setOnClickListener { start(force = true) }
        findViewById<Button>(R.id.btnOtherList).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        start(force = false)
    }

    private fun start(force: Boolean) {
        errorBox.visibility = View.GONE
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            delay(600)
            if (MacActivation.enabled) {
                // Atualiza as listas enviadas pelo painel (se houver internet)
                try { withTimeoutOrNull(8000) { MacActivation.sync(this@SplashActivity) } }
                catch (e: CancellationException) { throw e } catch (e: Throwable) { }
            }
            val playlist = VetorApp.prefs.active()
            if (playlist == null) {
                startActivity(Intent(this@SplashActivity, LoginActivity::class.java))
                finish()
                return@launch
            }
            if (!force && PlaylistRepository.isLoaded && PlaylistRepository.loadedPlaylistId == playlist.id) {
                Loader.openMain(this@SplashActivity)
                return@launch
            }
            status.text = if (force || !PlaylistRepository.hasCache(this@SplashActivity, playlist.id))
                "Baixando sua lista…" else "Carregando sua lista…"
            try {
                PlaylistRepository.load(this@SplashActivity, playlist, force)
                Loader.openMain(this@SplashActivity)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                progress.visibility = View.GONE
                status.text = Loader.friendly(e)
                errorBox.visibility = View.VISIBLE
                findViewById<View>(R.id.btnRetry).requestFocus()
            }
        }
    }

    override fun onRestart() {
        super.onRestart()
        // Voltou das configurações (talvez com outra lista ativa)
        if (errorBox.visibility == View.VISIBLE) start(force = false)
    }
}
