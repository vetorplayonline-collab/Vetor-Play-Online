package br.com.vetorplayonline.app.data

enum class ContentType { LIVE, MOVIE, SERIES }

/** Um item da lista M3U (canal, filme ou episódio). */
data class Channel(
    val name: String,
    val url: String,
    val logo: String?,
    val group: String,
    val type: ContentType,
    val epgId: String?,
    val userAgent: String?,
    val referer: String?,
    val seriesName: String? = null,
    val season: Int = 0,
    val episode: Int = 0
)

/** Série agrupada a partir dos episódios da lista. */
data class SeriesGroup(
    val name: String,
    val group: String,
    val logo: String?,
    val episodes: List<Channel>
) {
    val key: String get() = "series:$name"
}

/** Lista salva pelo usuário. kind = "xtream", "url" ou "file". */
data class Playlist(
    val id: String,
    val name: String,
    val kind: String,
    val url: String,
    val server: String = "",
    val username: String = "",
    val password: String = ""
)

/** Item exibido nas grades (um canal/filme ou uma série). */
data class Tile(
    val title: String,
    val logo: String?,
    val channel: Channel? = null,
    val series: SeriesGroup? = null
) {
    val key: String get() = series?.key ?: channel?.url ?: title
}
