package br.com.vetorplayonline.app.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Tudo que fica salvo no aparelho: listas, favoritos, histórico, posição dos filmes e PIN. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("vetor_play", Context.MODE_PRIVATE)

    // ---------- Listas ----------
    fun playlists(): List<Playlist> {
        val arr = JSONArray(sp.getString(KEY_PLAYLISTS, "[]"))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Playlist(
                id = o.getString("id"),
                name = o.optString("name"),
                kind = o.optString("kind", "url"),
                url = o.optString("url"),
                server = o.optString("server"),
                username = o.optString("username"),
                password = o.optString("password")
            )
        }
    }

    private fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id); put("name", p.name); put("kind", p.kind); put("url", p.url)
                put("server", p.server); put("username", p.username); put("password", p.password)
            })
        }
        sp.edit().putString(KEY_PLAYLISTS, arr.toString()).apply()
    }

    fun addOrUpdate(p: Playlist) {
        val list = playlists().filterNot { it.id == p.id } + p
        savePlaylists(list)
    }

    fun remove(id: String) {
        savePlaylists(playlists().filterNot { it.id == id })
        if (activeId == id) activeId = playlists().firstOrNull()?.id
    }

    var activeId: String?
        get() = sp.getString(KEY_ACTIVE, null)
        set(v) = sp.edit().putString(KEY_ACTIVE, v).apply()

    fun active(): Playlist? = playlists().firstOrNull { it.id == activeId } ?: playlists().firstOrNull()

    // ---------- Favoritos ----------
    fun favorites(): Set<String> = sp.getStringSet(KEY_FAVS + activeId, emptySet()) ?: emptySet()

    fun isFavorite(key: String) = favorites().contains(key)

    /** Retorna true se passou a ser favorito. */
    fun toggleFavorite(key: String): Boolean {
        val set = favorites().toMutableSet()
        val added = if (set.contains(key)) { set.remove(key); false } else { set.add(key); true }
        sp.edit().putStringSet(KEY_FAVS + activeId, set).apply()
        return added
    }

    // ---------- Assistidos recentemente ----------
    fun recents(): List<String> {
        val arr = JSONArray(sp.getString(KEY_RECENTS + activeId, "[]"))
        return (0 until arr.length()).map { arr.getString(it) }
    }

    fun addRecent(key: String) {
        val list = (listOf(key) + recents().filterNot { it == key }).take(40)
        sp.edit().putString(KEY_RECENTS + activeId, JSONArray(list).toString()).apply()
    }

    fun clearHistory() {
        val e = sp.edit()
        e.remove(KEY_RECENTS + activeId)
        sp.all.keys.filter { it.startsWith(KEY_POS) }.forEach { e.remove(it) }
        e.apply()
    }

    // ---------- Continuar assistindo ----------
    fun position(url: String): Long = sp.getLong(KEY_POS + url.hashCode(), 0L)

    fun savePosition(url: String, pos: Long) {
        if (pos <= 0) sp.edit().remove(KEY_POS + url.hashCode()).apply()
        else sp.edit().putLong(KEY_POS + url.hashCode(), pos).apply()
    }

    // ---------- Controle dos pais ----------
    var pin: String
        get() = sp.getString(KEY_PIN, "0000") ?: "0000"
        set(v) = sp.edit().putString(KEY_PIN, v).apply()

    var adultLock: Boolean
        get() = sp.getBoolean(KEY_ADULT_LOCK, true)
        set(v) = sp.edit().putBoolean(KEY_ADULT_LOCK, v).apply()

    // ---------- Vencimento do sinal (último valor consultado) ----------
    fun account(playlistId: String): AccountInfo? = AccountInfo.fromJson(sp.getString(KEY_ACCOUNT + playlistId, null))

    fun saveAccount(playlistId: String, info: AccountInfo) =
        sp.edit().putString(KEY_ACCOUNT + playlistId, info.toJson()).apply()

    // ---------- Jogos do dia ----------
    var gamesUrl: String
        get() = sp.getString(KEY_GAMES_URL, null) ?: br.com.vetorplayonline.app.Config.JOGOS_URL
        set(v) = sp.edit().putString(KEY_GAMES_URL, v.trim()).apply()

    // ---------- Player ----------
    var resizeMode: Int
        get() = sp.getInt(KEY_RESIZE, 0)
        set(v) = sp.edit().putInt(KEY_RESIZE, v).apply()

    companion object {
        private const val KEY_PLAYLISTS = "playlists"
        private const val KEY_ACTIVE = "active_playlist"
        private const val KEY_FAVS = "favs_"
        private const val KEY_RECENTS = "recents_"
        private const val KEY_POS = "pos_"
        private const val KEY_PIN = "parental_pin"
        private const val KEY_ADULT_LOCK = "adult_lock"
        private const val KEY_RESIZE = "resize_mode"
        private const val KEY_GAMES_URL = "games_url"
        private const val KEY_ACCOUNT = "account_"
    }
}
