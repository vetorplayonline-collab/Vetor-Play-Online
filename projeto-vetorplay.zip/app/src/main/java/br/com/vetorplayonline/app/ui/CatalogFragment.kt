package br.com.vetorplayonline.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.ContentType
import br.com.vetorplayonline.app.data.PlaylistRepository
import br.com.vetorplayonline.app.data.Tile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Aba de TV ao Vivo, Filmes ou Séries.
 * - TV / TV Box: coluna de categorias à esquerda e grade à direita.
 * - Celular: primeiro a lista de categorias (com a quantidade de cada uma);
 *   ao tocar, abre a grade daquela categoria, com botão para voltar às categorias.
 */
class CatalogFragment : Fragment() {

    private lateinit var type: ContentType
    private var wide = false

    // TV
    private var categoryAdapter: CategoryAdapter? = null
    // Celular
    private var listAdapter: CategoryListAdapter? = null
    private var listBox: View? = null
    private var channelsBox: View? = null
    private var listTitle: TextView? = null
    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = showCategoryList()
    }

    private lateinit var tileAdapter: TileAdapter
    private lateinit var title: TextView
    private lateinit var empty: TextView
    private lateinit var progress: ProgressBar
    private lateinit var grid: RecyclerView

    private var categories: List<String> = emptyList()
    private var current: String = CAT_ALL
    private var loadJob: Job? = null
    private var listJob: Job? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        wide = DeviceUi.useWideLayout(requireContext())
        return inflater.inflate(if (wide) R.layout.fragment_catalog_tv else R.layout.fragment_catalog_phone, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        type = ContentType.valueOf(requireArguments().getString(ARG_TYPE, ContentType.LIVE.name))
        title = view.findViewById(R.id.categoryTitle)
        empty = view.findViewById(R.id.emptyText)
        progress = view.findViewById(R.id.gridProgress)
        grid = view.findViewById(R.id.grid)

        // ---------- Grade de itens ----------
        val poster = type != ContentType.LIVE
        val screenDp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
        // TV: desconta o menu lateral (~90dp), a coluna de categorias (270dp) e as margens
        val gridDp = if (wide) screenDp - 90f - 270f - 70f else screenDp
        val tileDp = when {
            wide && poster -> 150f
            wide -> 165f
            poster -> 112f
            else -> 104f
        }
        val span = (gridDp / tileDp).toInt().coerceIn(3, 10)
        grid.layoutManager = GridLayoutManager(requireContext(), span)
        grid.setHasFixedSize(true)
        tileAdapter = TileAdapter(
            poster = poster,
            onClick = { tile, list -> Nav.open(requireActivity(), tile, list) },
            onLongClick = { tile -> Nav.toggleFavorite(requireContext(), tile) }
        )
        grid.adapter = tileAdapter

        if (wide) setupTv(view, savedInstanceState) else setupPhone(view, savedInstanceState)
    }

    // ==================================================================================
    // TV
    // ==================================================================================
    private fun setupTv(view: View, savedInstanceState: Bundle?) {
        val col = view.findViewById<RecyclerView>(R.id.categories)
        col.layoutManager = LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
        val adapter = CategoryAdapter(R.layout.item_category_tv, onFocusSelect = true) { index, cat -> onTvCategory(index, cat) }
        categoryAdapter = adapter
        col.adapter = adapter

        buildTvCategories()
        val startIndex = savedInstanceState?.getInt(STATE_INDEX, 0) ?: 0
        val idx = startIndex.coerceIn(0, categories.size - 1)
        adapter.select(idx)
        loadCategory(categories[idx])
    }

    private fun buildTvCategories() {
        categories = listOf(CAT_ALL, CAT_FAV, CAT_RECENT) + PlaylistRepository.categories(type)
        val labels = categories.map {
            when (it) {
                CAT_ALL -> "Todos"
                CAT_FAV -> "★ Favoritos"
                CAT_RECENT -> "⏱ Recentes"
                else -> if (PlaylistRepository.isAdult(it) && Session.hideAdult) "🔒 $it" else it
            }
        }
        val adapter = categoryAdapter ?: return
        adapter.submit(categories, labels, adapter.selected.coerceAtMost(categories.size - 1))
    }

    private fun onTvCategory(index: Int, cat: String) {
        val adapter = categoryAdapter ?: return
        if (PlaylistRepository.isAdult(cat) && Session.hideAdult) {
            PinDialog.ask(requireContext(), "Conteúdo adulto") {
                Session.adultUnlocked = true
                buildTvCategories()
                adapter.select(index)
                loadCategory(cat)
            }
            return
        }
        adapter.select(index)
        loadCategory(cat)
    }

    // ==================================================================================
    // Celular: lista de categorias -> itens da categoria
    // ==================================================================================
    private fun setupPhone(view: View, savedInstanceState: Bundle?) {
        listBox = view.findViewById(R.id.categoryListBox)
        channelsBox = view.findViewById(R.id.channelsBox)
        listTitle = view.findViewById(R.id.categoryListTitle)
        listTitle?.text = when (type) {
            ContentType.LIVE -> "Categorias de canais"
            ContentType.MOVIE -> "Categorias de filmes"
            ContentType.SERIES -> "Categorias de séries"
        }

        val list = view.findViewById<RecyclerView>(R.id.categoryList)
        list.layoutManager = LinearLayoutManager(requireContext())
        val adapter = CategoryListAdapter { row -> openPhoneCategory(row) }
        listAdapter = adapter
        list.adapter = adapter

        view.findViewById<View>(R.id.btnCategories).setOnClickListener { showCategoryList() }
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, backCallback)

        buildPhoneList()
        val open = savedInstanceState?.getString(STATE_OPEN)
        if (open != null) showItems(open) else showCategoryList()
    }

    private fun typeIcon() = when (type) {
        ContentType.LIVE -> R.drawable.ic_tv
        ContentType.MOVIE -> R.drawable.ic_movie
        ContentType.SERIES -> R.drawable.ic_series
    }

    /** Monta as linhas (com a quantidade de cada categoria) fora da tela principal. */
    private fun buildPhoneList() {
        val adapter = listAdapter ?: return
        listJob?.cancel()
        listJob = viewLifecycleOwner.lifecycleScope.launch {
            val rows = withContext(Dispatchers.Default) {
                val hide = Session.hideAdult
                val real = PlaylistRepository.categories(type)
                val out = ArrayList<CategoryRow>(real.size + 3)
                out.add(CategoryRow(CAT_ALL, "Todos", PlaylistRepository.visibleCount(type, hide), R.drawable.ic_apps, false))
                out.add(CategoryRow(CAT_FAV, "Favoritos", tilesFor(CAT_FAV).size, R.drawable.ic_star, false))
                out.add(CategoryRow(CAT_RECENT, "Assistidos recentemente", tilesFor(CAT_RECENT).size, R.drawable.ic_history, false))
                real.forEach { cat ->
                    val locked = hide && PlaylistRepository.isAdult(cat)
                    out.add(CategoryRow(cat, cat, PlaylistRepository.categorySize(type, cat), typeIcon(), locked))
                }
                out
            }
            categories = rows.map { it.key }
            adapter.submit(rows)
            val total = (rows.size - 3).coerceAtLeast(0)
            listTitle?.text = when (type) {
                ContentType.LIVE -> "Categorias de canais  •  $total"
                ContentType.MOVIE -> "Categorias de filmes  •  $total"
                ContentType.SERIES -> "Categorias de séries  •  $total"
            }
        }
    }

    private fun openPhoneCategory(row: CategoryRow) {
        if (row.locked) {
            PinDialog.ask(requireContext(), "Conteúdo adulto") {
                Session.adultUnlocked = true
                buildPhoneList()
                showItems(row.key)
            }
            return
        }
        showItems(row.key)
    }

    private fun showItems(cat: String) {
        listBox?.visibility = View.GONE
        channelsBox?.visibility = View.VISIBLE
        backCallback.isEnabled = !isHidden
        loadCategory(cat)
    }

    private fun showCategoryList() {
        channelsBox?.visibility = View.GONE
        listBox?.visibility = View.VISIBLE
        backCallback.isEnabled = false
        current = CAT_NONE
        buildPhoneList()
    }

    private val showingItems: Boolean get() = channelsBox?.visibility == View.VISIBLE

    // ==================================================================================
    // Comum
    // ==================================================================================
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        categoryAdapter?.let { outState.putInt(STATE_INDEX, it.selected) }
        if (!wide && showingItems && current != CAT_NONE) outState.putString(STATE_OPEN, current)
    }

    private fun loadCategory(cat: String) {
        current = cat
        loadJob?.cancel()
        progress.visibility = View.VISIBLE
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            val tiles = withContext(Dispatchers.Default) { tilesFor(cat) }
            progress.visibility = View.GONE
            tileAdapter.submit(tiles)
            grid.scrollToPosition(0)
            val label = when (cat) {
                CAT_ALL -> "Todos"
                CAT_FAV -> "Favoritos"
                CAT_RECENT -> "Assistidos recentemente"
                else -> cat
            }
            title.text = "$label  •  ${tiles.size}"
            empty.visibility = if (tiles.isEmpty()) View.VISIBLE else View.GONE
            empty.text = when (cat) {
                CAT_FAV -> "Nenhum favorito ainda.\nSegure o dedo (ou o botão OK) sobre um item para favoritar."
                CAT_RECENT -> "Nada assistido ainda."
                else -> "Nenhum item nesta categoria."
            }
        }
    }

    private fun tilesFor(cat: String): List<Tile> {
        val prefs = VetorApp.prefs
        return when (cat) {
            CAT_ALL -> PlaylistRepository.allTiles(type, Session.hideAdult)
            CAT_FAV -> prefs.favorites().mapNotNull { PlaylistRepository.tileForKey(it) }.filter { matches(it) }
                .sortedBy { it.title.lowercase() }
            CAT_RECENT -> prefs.recents().mapNotNull { PlaylistRepository.tileForKey(it) }.filter { matches(it) }
            CAT_NONE -> emptyList()
            else -> PlaylistRepository.tiles(type, cat)
        }
    }

    private fun matches(t: Tile): Boolean {
        if (Session.hideAdult) {
            val group = t.series?.group ?: t.channel?.group
            if (group != null && PlaylistRepository.isAdult(group)) return false
        }
        return if (t.series != null) type == ContentType.SERIES else t.channel?.type == type
    }

    override fun onResume() {
        super.onResume()
        refreshVisible()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!wide) backCallback.isEnabled = !hidden && showingItems
        if (!hidden && view != null) refreshVisible()
    }

    private fun refreshVisible() {
        if (!::tileAdapter.isInitialized) return
        if (!wide && !showingItems) {
            buildPhoneList() // atualiza contagem de favoritos/recentes
            return
        }
        if (current == CAT_FAV || current == CAT_RECENT) loadCategory(current)
        else tileAdapter.notifyDataSetChanged() // atualiza estrelas de favorito
    }

    companion object {
        private const val ARG_TYPE = "type"
        private const val STATE_INDEX = "cat_index"
        private const val STATE_OPEN = "cat_open"
        private const val CAT_ALL = "\u0000all"
        private const val CAT_FAV = "\u0000fav"
        private const val CAT_RECENT = "\u0000recent"
        private const val CAT_NONE = "\u0000none"

        fun newInstance(type: ContentType) = CatalogFragment().apply {
            arguments = Bundle().apply { putString(ARG_TYPE, type.name) }
        }
    }
}
