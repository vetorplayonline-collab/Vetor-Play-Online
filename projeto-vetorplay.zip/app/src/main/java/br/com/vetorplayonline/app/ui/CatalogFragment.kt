package br.com.vetorplayonline.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.ContentType
import br.com.vetorplayonline.app.data.PlaylistRepository
import br.com.vetorplayonline.app.data.Tile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Aba de TV ao Vivo, Filmes ou Séries: categorias em cima e grade de itens embaixo. */
class CatalogFragment : Fragment() {

    private lateinit var type: ContentType
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var tileAdapter: TileAdapter
    private lateinit var title: TextView
    private lateinit var empty: TextView
    private lateinit var progress: ProgressBar
    private lateinit var grid: RecyclerView

    private var categories: List<String> = emptyList()
    private var current: String = CAT_ALL
    private var loadJob: Job? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View =
        inflater.inflate(
            if (DeviceUi.useWideLayout(requireContext())) R.layout.fragment_catalog_tv else R.layout.fragment_catalog,
            container, false
        )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        type = ContentType.valueOf(requireArguments().getString(ARG_TYPE, ContentType.LIVE.name))
        title = view.findViewById(R.id.categoryTitle)
        empty = view.findViewById(R.id.emptyText)
        progress = view.findViewById(R.id.gridProgress)
        grid = view.findViewById(R.id.grid)

        val wide = DeviceUi.useWideLayout(requireContext())
        val chips = view.findViewById<RecyclerView>(R.id.categories)
        chips.layoutManager = LinearLayoutManager(
            requireContext(), if (wide) RecyclerView.VERTICAL else RecyclerView.HORIZONTAL, false
        )
        categoryAdapter = if (wide) {
            CategoryAdapter(R.layout.item_category_tv, onFocusSelect = true) { index, cat -> onCategory(index, cat) }
        } else {
            CategoryAdapter { index, cat -> onCategory(index, cat) }
        }
        chips.adapter = categoryAdapter

        val poster = type != ContentType.LIVE
        val screenDp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
        // TV: desconta o menu lateral (~90dp), a coluna de categorias (270dp) e as margens
        val gridDp = if (wide) screenDp - 90f - 270f - 70f else screenDp
        val tileDp = when {
            wide && poster -> 150f
            wide -> 165f
            poster -> 112f
            else -> 104f
        }
        val span = (gridDp / tileDp).toInt().coerceIn(3, 10)
        grid.layoutManager = GridLayoutManager(requireContext(), span)
        grid.setHasFixedSize(true)
        tileAdapter = TileAdapter(
            poster = poster,
            onClick = { tile, list -> Nav.open(requireActivity(), tile, list) },
            onLongClick = { tile -> Nav.toggleFavorite(requireContext(), tile) }
        )
        grid.adapter = tileAdapter

        buildCategories()
        val startIndex = savedInstanceState?.getInt(STATE_INDEX, 0) ?: 0
        val idx = startIndex.coerceIn(0, categories.size - 1)
        categoryAdapter.select(idx)
        loadCategory(categories[idx])
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::categoryAdapter.isInitialized) outState.putInt(STATE_INDEX, categoryAdapter.selected)
    }

    private fun buildCategories() {
        val real = PlaylistRepository.categories(type)
        categories = listOf(CAT_ALL, CAT_FAV, CAT_RECENT) + real
        val labels = categories.map {
            when (it) {
                CAT_ALL -> "Todos"
                CAT_FAV -> "★ Favoritos"
                CAT_RECENT -> "⏱ Recentes"
                else -> if (PlaylistRepository.isAdult(it) && Session.hideAdult) "🔒 $it" else it
            }
        }
        categoryAdapter.submit(categories, labels, categoryAdapter.selected.coerceAtMost(categories.size - 1))
    }

    private fun onCategory(index: Int, cat: String) {
        if (PlaylistRepository.isAdult(cat) && Session.hideAdult) {
            PinDialog.ask(requireContext(), "Conteúdo adulto") {
                Session.adultUnlocked = true
                buildCategories()
                categoryAdapter.select(index)
                loadCategory(cat)
            }
            return
        }
        categoryAdapter.select(index)
        loadCategory(cat)
    }

    private fun loadCategory(cat: String) {
        current = cat
        loadJob?.cancel()
        progress.visibility = View.VISIBLE
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            val tiles = withContext(Dispatchers.Default) { tilesFor(cat) }
            progress.visibility = View.GONE
            tileAdapter.submit(tiles)
            grid.scrollToPosition(0)
            val label = when (cat) {
                CAT_ALL -> "Todos"
                CAT_FAV -> "Favoritos"
                CAT_RECENT -> "Assistidos recentemente"
                else -> cat
            }
            title.text = "$label  •  ${tiles.size}"
            empty.visibility = if (tiles.isEmpty()) View.VISIBLE else View.GONE
            empty.text = when (cat) {
                CAT_FAV -> "Nenhum favorito ainda.\nSegure o dedo (ou o botão OK) sobre um item para favoritar."
                CAT_RECENT -> "Nada assistido ainda."
                else -> "Nenhum item nesta categoria."
            }
        }
    }

    private fun tilesFor(cat: String): List<Tile> {
        val prefs = VetorApp.prefs
        return when (cat) {
            CAT_ALL -> PlaylistRepository.allTiles(type, Session.hideAdult)
            CAT_FAV -> prefs.favorites().mapNotNull { PlaylistRepository.tileForKey(it) }.filter { matches(it) }
                .sortedBy { it.title.lowercase() }
            CAT_RECENT -> prefs.recents().mapNotNull { PlaylistRepository.tileForKey(it) }.filter { matches(it) }
            else -> PlaylistRepository.tiles(type, cat)
        }
    }

    private fun matches(t: Tile): Boolean {
        if (Session.hideAdult) {
            val group = t.series?.group ?: t.channel?.group
            if (group != null && PlaylistRepository.isAdult(group)) return false
        }
        return if (t.series != null) type == ContentType.SERIES else t.channel?.type == type
    }

    override fun onResume() {
        super.onResume()
        refreshVisible()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden && view != null) refreshVisible()
    }

    private fun refreshVisible() {
        if (!::tileAdapter.isInitialized) return
        if (current == CAT_FAV || current == CAT_RECENT) loadCategory(current)
        else tileAdapter.notifyDataSetChanged() // atualiza estrelas de favorito
    }

    companion object {
        private const val ARG_TYPE = "type"
        private const val STATE_INDEX = "cat_index"
        private const val CAT_ALL = "\u0000all"
        private const val CAT_FAV = "\u0000fav"
        private const val CAT_RECENT = "\u0000recent"

        fun newInstance(type: ContentType) = CatalogFragment().apply {
            arguments = Bundle().apply { putString(ARG_TYPE, type.name) }
        }
    }
}
