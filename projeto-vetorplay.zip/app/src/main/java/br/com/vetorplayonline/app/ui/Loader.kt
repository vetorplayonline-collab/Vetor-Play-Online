package br.com.vetorplayonline.app.ui

import android.content.Intent
import android.view.LayoutInflater
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.Playlist
import br.com.vetorplayonline.app.data.PlaylistRepository
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.net.MalformedURLException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

object Loader {

    /** Baixa/lê a lista com uma janela de progresso. */
    fun load(
        activity: AppCompatActivity,
        playlist: Playlist,
        force: Boolean,
        onError: (() -> Unit)? = null,
        onDone: (Int) -> Unit
    ) {
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_loading, null)
        view.findViewById<TextView>(R.id.loadingText).text =
            if (force || !PlaylistRepository.hasCache(activity, playlist.id)) "Baixando a lista \"${playlist.name}\"…\nListas grandes podem levar alguns minutos."
            else "Carregando a lista \"${playlist.name}\"…"
        val dialog = MaterialAlertDialogBuilder(activity).setView(view).setCancelable(false).show()

        activity.lifecycleScope.launch {
            try {
                val n = PlaylistRepository.load(activity, playlist, force)
                dialog.dismiss()
                onDone(n)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                dialog.dismiss()
                MaterialAlertDialogBuilder(activity)
                    .setTitle("Não foi possível carregar a lista")
                    .setMessage(friendly(e))
                    .setPositiveButton("OK") { _, _ -> onError?.invoke() }
                    .setCancelable(false)
                    .show()
            }
        }
    }

    fun friendly(e: Throwable): String = when (e) {
        is UnknownHostException -> "Sem internet ou o endereço do servidor não existe."
        is SocketTimeoutException -> "O servidor demorou demais para responder. Tente novamente."
        is SSLException -> "Falha na conexão segura (SSL) com o servidor."
        is MalformedURLException -> "Endereço inválido. Confira se começa com http:// ou https://"
        is FileNotFoundException -> "Lista não encontrada no servidor."
        is OutOfMemoryError -> "A lista é grande demais para a memória deste aparelho."
        else -> e.message ?: e.javaClass.simpleName
    }

    fun openMain(activity: AppCompatActivity) {
        activity.startActivity(
            Intent(activity, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        activity.finish()
    }

    /** Usado quando o Android fecha o app em segundo plano e a lista some da memória. */
    fun ensureLoaded(activity: AppCompatActivity): Boolean {
        val active = VetorApp.prefs.active()
        if (PlaylistRepository.isLoaded && PlaylistRepository.loadedPlaylistId == active?.id) return true
        activity.startActivity(
            Intent(activity, SplashActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        activity.finish()
        return false
    }
}
