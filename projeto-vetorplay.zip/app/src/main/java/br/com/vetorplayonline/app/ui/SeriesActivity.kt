package br.com.vetorplayonline.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.Channel
import br.com.vetorplayonline.app.data.PlaylistRepository
import br.com.vetorplayonline.app.data.SeriesGroup
import coil.load
import com.google.android.material.button.MaterialButton

/** Detalhe da série: temporadas e episódios. */
class SeriesActivity : AppCompatActivity() {

    private lateinit var series: SeriesGroup
    private lateinit var seasonAdapter: CategoryAdapter
    private val episodeAdapter = EpisodeAdapter { ep -> play(ep) }
    private lateinit var favButton: MaterialButton
    private var seasons: List<Int> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DeviceUi.lockPhonePortrait(this)
        if (!Loader.ensureLoaded(this)) return
        val name = intent.getStringExtra(EXTRA_NAME).orEmpty()
        val s = PlaylistRepository.series(name)
        if (s == null) { finish(); return }
        series = s
        setContentView(if (DeviceUi.useWideLayout(this)) R.layout.activity_series_tv else R.layout.activity_series)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageView>(R.id.seriesPoster).load(s.logo) {
            placeholder(R.drawable.ic_tile_placeholder)
            error(R.drawable.ic_tile_placeholder)
            fallback(R.drawable.ic_tile_placeholder)
        }
        findViewById<TextView>(R.id.seriesTitle).text = s.name
        seasons = s.episodes.map { it.season }.distinct().sorted()
        findViewById<TextView>(R.id.seriesInfo).text =
            "${s.group}\n${seasons.size} temporada(s) • ${s.episodes.size} episódio(s)"

        favButton = findViewById(R.id.btnFav)
        updateFav()
        favButton.setOnClickListener { VetorApp.prefs.toggleFavorite(s.key); updateFav() }

        findViewById<MaterialButton>(R.id.btnPlay).setOnClickListener { play(nextToWatch()) }

        val seasonList = findViewById<RecyclerView>(R.id.seasons)
        seasonList.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        seasonAdapter = CategoryAdapter { index, _ ->
            seasonAdapter.select(index)
            showSeason(seasons[index])
        }
        seasonList.adapter = seasonAdapter
        seasonAdapter.submit(
            seasons.map { it.toString() },
            seasons.map { if (it == 0) "Episódios" else "Temporada $it" }
        )
        seasonList.visibility = if (seasons.size > 1) View.VISIBLE else View.GONE

        val episodes = findViewById<RecyclerView>(R.id.episodes)
        episodes.layoutManager = LinearLayoutManager(this)
        episodes.adapter = episodeAdapter
        showSeason(seasons.firstOrNull() ?: 0)
    }

    override fun onResume() {
        super.onResume()
        if (::series.isInitialized) episodeAdapter.notifyDataSetChanged()
    }

    private fun showSeason(season: Int) {
        episodeAdapter.submit(series.episodes.filter { it.season == season })
    }

    /** Primeiro episódio ainda não assistido (segundo o histórico). */
    private fun nextToWatch(): Channel {
        val recents = VetorApp.prefs.recents()
        val lastIdx = series.episodes.indexOfFirst { recents.contains(it.url) }
        if (lastIdx < 0) return series.episodes.first()
        val last = series.episodes[lastIdx]
        return if (VetorApp.prefs.position(last.url) > 0) last
        else series.episodes.getOrNull(lastIdx + 1) ?: last
    }

    private fun play(ep: Channel) {
        Nav.play(this, series.episodes, series.episodes.indexOf(ep).coerceAtLeast(0))
    }

    private fun updateFav() {
        val fav = VetorApp.prefs.isFavorite(series.key)
        favButton.text = if (fav) "★ Favorito" else "☆ Favoritar"
    }

    class EpisodeAdapter(private val onClick: (Channel) -> Unit) : RecyclerView.Adapter<EpisodeAdapter.VH>() {
        private var items: List<Channel> = emptyList()
        fun submit(list: List<Channel>) { items = list; notifyDataSetChanged() }
        override fun getItemCount() = items.size

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val number: TextView = v.findViewById(R.id.epNumber)
            val title: TextView = v.findViewById(R.id.epTitle)
            val status: TextView = v.findViewById(R.id.epStatus)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_episode, parent, false)
            v.tvFocusEffect(null)
            if (DeviceUi.useWideLayout(parent.context)) {
                v.findViewById<TextView>(R.id.epTitle).textSize = 17f
            }
            return VH(v)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val ep = items[position]
            h.number.text = if (ep.episode > 0) ep.episode.toString() else (position + 1).toString()
            h.title.text = ep.name
            val prefs = VetorApp.prefs
            h.status.text = when {
                prefs.position(ep.url) > 0 -> "▶ Continuar de ${PlayerActivity.fmt(prefs.position(ep.url))}"
                prefs.recents().contains(ep.url) -> "✓ Assistido"
                else -> ""
            }
            h.status.visibility = if (h.status.text.isNullOrEmpty()) View.GONE else View.VISIBLE
            h.itemView.setOnClickListener { onClick(ep) }
        }
    }

    companion object {
        const val EXTRA_NAME = "series_name"
    }
}
