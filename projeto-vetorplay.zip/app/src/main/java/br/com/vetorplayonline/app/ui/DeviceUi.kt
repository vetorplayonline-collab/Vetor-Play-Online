package br.com.vetorplayonline.app.ui

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration

/**
 * Decide qual diagramação usar.
 * TV: Android TV, TV Box (muitas usam Android de celular, por isso também olha
 * a falta de tela de toque) e tablets grandes deitados.
 */
object DeviceUi {

    private var cached: Boolean? = null

    fun isTv(ctx: Context): Boolean {
        cached?.let { return it }
        val pm = ctx.packageManager
        val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        val tvMode = ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
        val leanback = pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            pm.hasSystemFeature("android.software.leanback_only")
        val noTouch = !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
        val result = tvMode || leanback || noTouch
        cached = result
        return result
    }

    /** Celular: telas do app ficam em pé (o player continua deitado). */
    fun lockPhonePortrait(activity: android.app.Activity) {
        if (!isTv(activity) && activity.resources.configuration.smallestScreenWidthDp < 600) {
            activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    /** TV ou tablet grande na horizontal: usa a diagramação de tela grande. */
    fun useWideLayout(ctx: Context): Boolean {
        if (isTv(ctx)) return true
        val c = ctx.resources.configuration
        return c.smallestScreenWidthDp >= 600 && c.orientation == Configuration.ORIENTATION_LANDSCAPE
    }
}
