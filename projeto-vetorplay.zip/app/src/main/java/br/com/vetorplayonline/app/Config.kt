package br.com.vetorplayonline.app

/**
 * Configurações da revenda Vetor Play Online.
 *
 * DEFAULT_SERVER: coloque aqui o seu DNS (ex.: "http://meudns.com:8080").
 * Com ele preenchido, o campo "Servidor" some da tela de login e o cliente
 * só precisa digitar usuário e senha. Deixe "" para o cliente digitar o servidor.
 *
 * JOGOS_URL: link do arquivo JSON com os jogos do dia (veja jogos.json na raiz do projeto).
 * Ex.: "https://raw.githubusercontent.com/SEU_USUARIO/SEU_REPOSITORIO/main/jogos.json"
 * Também dá para trocar o link dentro do app, em Configurações > Jogos do dia.
 */
object Config {
    const val DEFAULT_SERVER = ""
    const val WHATSAPP_SUPORTE = "" // ex.: "5544999999999" (mostra o botão de suporte no login)
    const val JOGOS_URL = ""

    /**
     * Ativação por MAC/KEY: o app lê as listas enviadas pelo Gestor Vetor Play Online
     * (aba "Painel MAC"), no Realtime Database do projeto gestor-vetorplayonline.
     * Deixe "" para esconder a ativação por MAC.
     */
    const val FIREBASE_DB_URL = "https://gestor-vetorplayonline-default-rtdb.firebaseio.com"
}
