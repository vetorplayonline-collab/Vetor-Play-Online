package br.com.vetorplayonline.app

/**
 * Configurações da revenda Vetor Play Online.
 *
 * DEFAULT_SERVER: coloque aqui o seu DNS (ex.: "http://meudns.com:8080").
 * Com ele preenchido, o campo "Servidor" some da tela de login e o cliente
 * só precisa digitar usuário e senha. Deixe "" para o cliente digitar o servidor.

 */
object Config {
    const val DEFAULT_SERVER = ""
    /** WhatsApp da Vetor Play Online (renovação e suporte). */
    const val WHATSAPP_SUPORTE = "5544997213054"
    const val WHATSAPP_EXIBICAO = "(44) 99721-3054"

    /**
     * Ativação por MAC/KEY: o app lê as listas enviadas pelo Gestor Vetor Play Online
     * (aba "Painel MAC"), no Realtime Database do projeto gestor-vetorplayonline.
     * Deixe "" para esconder a ativação por MAC.
     */
    /** Repositório do GitHub onde ficam as versões novas do app (atualização automática). */
    const val UPDATE_REPO = "vetorplayonline-collab/Vetor-Play-Online"

    const val FIREBASE_DB_URL = "https://gestor-vetorplayonline-default-rtdb.firebaseio.com"
}
