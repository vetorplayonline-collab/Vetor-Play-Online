package br.com.vetorplayonline.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer

/** Mantém a lista ativa carregada em memória, já separada em TV, Filmes e Séries. */
object PlaylistRepository {

    const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 10) VetorPlayOnline/1.0"
    private val adultRegex = Regex("(?i)(adult|xxx|\\+18|18\\+|adulto|porn|er[óo]tic)")

    @Volatile var loadedPlaylistId: String? = null
        private set

    var all: List<Channel> = emptyList(); private set
    private var byUrl: Map<String, Channel> = emptyMap()
    private var liveGroups: LinkedHashMap<String, MutableList<Channel>> = LinkedHashMap()
    private var movieGroups: LinkedHashMap<String, MutableList<Channel>> = LinkedHashMap()
    private var seriesGroups: LinkedHashMap<String, MutableList<SeriesGroup>> = LinkedHashMap()
    private var seriesByName: Map<String, SeriesGroup> = emptyMap()

    val isLoaded: Boolean get() = all.isNotEmpty()

    fun isAdult(category: String) = adultRegex.containsMatchIn(category)

    private fun cacheFile(ctx: Context, id: String) = File(ctx.filesDir, "playlist_$id.m3u")

    fun hasCache(ctx: Context, id: String) = cacheFile(ctx, id).let { it.exists() && it.length() > 0 }

    fun deleteCache(ctx: Context, id: String) { cacheFile(ctx, id).delete() }

    /** Copia um arquivo .m3u escolhido no aparelho para o armazenamento do app. */
    suspend fun importFile(ctx: Context, id: String, uri: Uri) = withContext(Dispatchers.IO) {
        val target = cacheFile(ctx, id)
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { input.copyTo(it) }
        } ?: throw IOException("Não foi possível abrir o arquivo")
        validate(target)
    }

    /**
     * Carrega a lista: usa o arquivo salvo, ou baixa de novo se [forceDownload] for true
     * (ou se ainda não existir). Retorna a quantidade de itens.
     */
    suspend fun load(ctx: Context, playlist: Playlist, forceDownload: Boolean): Int =
        withContext(Dispatchers.IO) {
            val file = cacheFile(ctx, playlist.id)
            if (playlist.kind != "file" && (forceDownload || !file.exists() || file.length() == 0L)) {
                download(playlist.url, file)
            }
            if (!file.exists()) throw IOException("Lista não encontrada. Adicione novamente.")
            val list = file.bufferedReader(Charsets.UTF_8).use { M3uParser.parse(it) }
            if (list.isEmpty()) throw IOException("A lista está vazia ou não é uma lista M3U válida.")
            index(list)
            loadedPlaylistId = playlist.id
            list.size
        }

    private fun open(address: String): HttpURLConnection {
        var url = URL(address)
        repeat(7) {
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 180_000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", DEFAULT_UA)
                setRequestProperty("Accept", "*/*")
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank()) throw IOException("Redirecionamento inválido do servidor.")
                url = URL(url, loc)
                return@repeat
            }
            if (code != 200) {
                conn.disconnect()
                throw IOException(
                    when (code) {
                        401, 403 -> "Acesso negado pelo servidor (código $code). Confira usuário e senha."
                        404 -> "Endereço da lista não encontrado (404)."
                        else -> "O servidor respondeu com erro $code."
                    }
                )
            }
            return conn
        }
        throw IOException("Muitos redirecionamentos.")
    }

    private fun download(address: String, target: File) {
        val conn = open(address)
        val tmp = File(target.parentFile, target.name + ".tmp")
        conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it, 64 * 1024) } }
        conn.disconnect()
        validate(tmp)
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) { tmp.copyTo(target, true); tmp.delete() }
    }

    private fun validate(file: File) {
        val head = file.inputStream().use { s ->
            val buf = ByteArray(4096)
            val n = s.read(buf)
            if (n <= 0) "" else String(buf, 0, n, Charsets.UTF_8)
        }
        if (!head.contains("#EXTM3U", true) && !head.contains("#EXTINF", true)) {
            file.delete()
            throw IOException("O servidor não devolveu uma lista M3U. Confira os dados de acesso.")
        }
    }

    private fun index(list: List<Channel>) {
        val live = LinkedHashMap<String, MutableList<Channel>>()
        val movies = LinkedHashMap<String, MutableList<Channel>>()
        val seriesEpisodes = LinkedHashMap<String, MutableList<Channel>>()   // nome -> episódios
        val seriesCategory = HashMap<String, String>()
        val map = HashMap<String, Channel>(list.size * 2)

        for (c in list) {
            map[c.url] = c
            when (c.type) {
                ContentType.LIVE -> live.getOrPut(c.group) { ArrayList() }.add(c)
                ContentType.MOVIE -> movies.getOrPut(c.group) { ArrayList() }.add(c)
                ContentType.SERIES -> {
                    val name = c.seriesName ?: c.name
                    seriesEpisodes.getOrPut(name) { ArrayList() }.add(c)
                    seriesCategory.putIfAbsent(name, c.group)
                }
            }
        }

        val sGroups = LinkedHashMap<String, MutableList<SeriesGroup>>()
        val sByName = HashMap<String, SeriesGroup>()
        for ((name, eps) in seriesEpisodes) {
            val sorted = eps.sortedWith(compareBy<Channel>({ it.season }, { it.episode }))
            val sg = SeriesGroup(
                name = name,
                group = seriesCategory[name] ?: "Séries",
                logo = eps.firstNotNullOfOrNull { it.logo },
                episodes = sorted
            )
            sGroups.getOrPut(sg.group) { ArrayList() }.add(sg)
            sByName[name] = sg
        }

        all = list
        byUrl = map
        liveGroups = live
        movieGroups = movies
        seriesGroups = sGroups
        seriesByName = sByName
    }

    // ---------- Consultas usadas pelas telas ----------

    fun categories(type: ContentType): List<String> = when (type) {
        ContentType.LIVE -> liveGroups.keys.toList()
        ContentType.MOVIE -> movieGroups.keys.toList()
        ContentType.SERIES -> seriesGroups.keys.toList()
    }

    fun count(type: ContentType): Int = when (type) {
        ContentType.LIVE -> liveGroups.values.sumOf { it.size }
        ContentType.MOVIE -> movieGroups.values.sumOf { it.size }
        ContentType.SERIES -> seriesByName.size
    }

    fun tiles(type: ContentType, category: String): List<Tile> = when (type) {
        ContentType.LIVE -> liveGroups[category].orEmpty().map { it.toTile() }
        ContentType.MOVIE -> movieGroups[category].orEmpty().map { it.toTile() }
        ContentType.SERIES -> seriesGroups[category].orEmpty().map { it.toTile() }
    }

    fun allTiles(type: ContentType, hideAdult: Boolean): List<Tile> = categories(type)
        .filter { !hideAdult || !isAdult(it) }
        .flatMap { tiles(type, it) }

    fun channel(url: String): Channel? = byUrl[url]

    fun series(name: String): SeriesGroup? = seriesByName[name]

    /** Converte uma chave salva (favorito/recente) de volta em item. */
    fun tileForKey(key: String): Tile? =
        if (key.startsWith("series:")) series(key.removePrefix("series:"))?.toTile()
        else channel(key)?.toTile()

    fun typeOfKey(key: String): ContentType? =
        if (key.startsWith("series:")) ContentType.SERIES else channel(key)?.type

    /** Últimos filmes da lista (normalmente os lançamentos ficam no fim). */
    fun latestMovies(limit: Int, hideAdult: Boolean): List<Tile> =
        movieGroups.entries.filter { !hideAdult || !isAdult(it.key) }
            .flatMap { it.value }.takeLast(limit).reversed().map { it.toTile() }

    fun latestSeries(limit: Int, hideAdult: Boolean): List<Tile> =
        seriesGroups.entries.filter { !hideAdult || !isAdult(it.key) }
            .flatMap { it.value }.takeLast(limit).reversed().map { it.toTile() }

    fun search(query: String, hideAdult: Boolean, limit: Int = 300): List<Tile> {
        val q = normalize(query)
        if (q.length < 2) return emptyList()
        val out = ArrayList<Tile>()
        for (type in listOf(ContentType.LIVE, ContentType.MOVIE, ContentType.SERIES)) {
            for (t in allTiles(type, hideAdult)) {
                if (normalize(t.title).contains(q)) {
                    out.add(t)
                    if (out.size >= limit) return out
                }
            }
        }
        return out
    }

    private val marks = Regex("\\p{Mn}+")

    fun normalize(s: String): String =
        marks.replace(Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD), "")

    private fun Channel.toTile() = Tile(title = name, logo = logo, channel = this)
    private fun SeriesGroup.toTile() = Tile(title = name, logo = logo, series = this)
}
