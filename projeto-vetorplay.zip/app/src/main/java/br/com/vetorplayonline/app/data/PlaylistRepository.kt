package br.com.vetorplayonline.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Mantém a lista ativa carregada em memória, já separada em TV, Filmes e Séries. */
object PlaylistRepository {

    const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 10) VetorPlayOnline/1.0"
    private val adultRegex = Regex("(?i)(adult|xxx|\\+18|18\\+|adulto|porn|er[óo]tic)")

    @Volatile var loadedPlaylistId: String? = null
        private set

    var all: List<Channel> = emptyList(); private set
    private var liveGroups: LinkedHashMap<String, MutableList<Channel>> = LinkedHashMap()
    private var movieGroups: LinkedHashMap<String, MutableList<Channel>> = LinkedHashMap()
    private var seriesGroups: LinkedHashMap<String, MutableList<SeriesGroup>> = LinkedHashMap()
    private var seriesByName: Map<String, SeriesGroup> = emptyMap()

    val isLoaded: Boolean get() = all.isNotEmpty()

    fun isAdult(category: String) = adultRegex.containsMatchIn(category)

    private fun cacheFile(ctx: Context, id: String) = File(ctx.filesDir, "playlist_$id.m3u")

    /** Lista já interpretada, em formato binário: abre várias vezes mais rápido que reler o texto M3U. */
    private fun binFile(ctx: Context, id: String) = File(ctx.filesDir, "playlist_$id.bin")

    /** Depois deste tempo a lista é baixada de novo em segundo plano (vale na próxima abertura). */
    private const val REFRESH_AFTER_MS = 24L * 60 * 60 * 1000
    private const val BIN_MAGIC = 0x56504232 // "VPB2"

    fun hasCache(ctx: Context, id: String) = cacheFile(ctx, id).let { it.exists() && it.length() > 0 }

    fun deleteCache(ctx: Context, id: String) { cacheFile(ctx, id).delete(); binFile(ctx, id).delete() }

    /** Copia um arquivo .m3u escolhido no aparelho para o armazenamento do app. */
    suspend fun importFile(ctx: Context, id: String, uri: Uri) = withContext(Dispatchers.IO) {
        val target = cacheFile(ctx, id)
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { input.copyTo(it) }
        } ?: throw IOException("Não foi possível abrir o arquivo")
        validate(target)
        binFile(ctx, id).delete()
    }

    /**
     * Carrega a lista: usa o arquivo salvo, ou baixa de novo se [forceDownload] for true
     * (ou se ainda não existir). Retorna a quantidade de itens.
     */
    suspend fun load(ctx: Context, playlist: Playlist, forceDownload: Boolean): Int =
        withContext(Dispatchers.IO) {
            val file = cacheFile(ctx, playlist.id)
            val bin = binFile(ctx, playlist.id)
            if (playlist.kind != "file" && (forceDownload || ((!file.exists() || file.length() == 0L) && !bin.exists()))) {
                download(playlist.url, file)
                bin.delete()
            }
            // 1) Caminho rápido: lista já interpretada (binário) e mais nova que o texto M3U
            val fast: List<Channel>? =
                if (bin.exists() && bin.length() > 0 && (!file.exists() || bin.lastModified() >= file.lastModified())) {
                    try { readBin(bin) } catch (e: OutOfMemoryError) { throw e } catch (e: Throwable) { bin.delete(); null }
                } else null
            // 2) Caminho normal: lê o texto M3U e já guarda o binário para as próximas aberturas
            val list: List<Channel> = fast ?: run {
                if (!file.exists()) throw IOException("Lista não encontrada. Adicione novamente.")
                val parsed = java.io.BufferedReader(java.io.InputStreamReader(java.io.FileInputStream(file), Charsets.UTF_8), 1 shl 16)
                    .use { M3uParser.parse(it) }
                if (parsed.isEmpty()) throw IOException("A lista está vazia ou não é uma lista M3U válida.")
                try { writeBin(bin, parsed) } catch (e: Throwable) { bin.delete() }
                parsed
            }
            if (list.isEmpty()) throw IOException("A lista está vazia ou não é uma lista M3U válida.")
            index(list)
            loadedPlaylistId = playlist.id
            list.size
        }

    /** A lista salva já passou do tempo de atualizar? (nunca para arquivo local) */
    fun needsRefresh(ctx: Context, playlist: Playlist): Boolean {
        if (playlist.kind == "file") return false
        val f = cacheFile(ctx, playlist.id).takeIf { it.exists() } ?: binFile(ctx, playlist.id)
        return !f.exists() || System.currentTimeMillis() - f.lastModified() > REFRESH_AFTER_MS
    }

    /**
     * Baixa a lista de novo em segundo plano, sem mexer no que está aberto na tela.
     * Só baixa o arquivo (pouca memória); ele é interpretado uma única vez na próxima abertura.
     */
    @Volatile private var refreshing = false
    suspend fun refreshInBackground(ctx: Context, playlist: Playlist) = withContext(Dispatchers.IO) {
        if (refreshing || playlist.kind == "file") return@withContext
        refreshing = true
        try {
            val file = cacheFile(ctx, playlist.id)
            download(playlist.url, file)
        } catch (e: Throwable) {
            // sem internet ou servidor fora: continua com a lista salva
        } finally { refreshing = false }
    }

    // ---------- Formato binário ----------
    private fun java.io.DataOutputStream.str(v: String?) {
        if (v == null) { writeInt(-1); return }
        val b = v.toByteArray(Charsets.UTF_8); writeInt(b.size); write(b)
    }

    private fun java.io.DataInputStream.str(buf: ByteArray): String? {
        val n = readInt()
        if (n < 0) return null
        val b = if (n <= buf.size) buf else ByteArray(n)
        readFully(b, 0, n)
        return String(b, 0, n, Charsets.UTF_8)
    }

    private fun writeBin(target: File, list: List<Channel>) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        java.io.DataOutputStream(java.io.BufferedOutputStream(tmp.outputStream(), 1 shl 16)).use { o ->
            val groups = LinkedHashMap<String, Int>()
            for (c in list) groups.getOrPut(c.group) { groups.size }
            o.writeInt(BIN_MAGIC)
            o.writeInt(groups.size)
            for (g in groups.keys) o.str(g)
            o.writeInt(list.size)
            for (c in list) {
                o.str(c.name); o.str(c.url); o.str(c.logo)
                o.writeInt(groups[c.group] ?: 0)
                o.writeByte(c.type.ordinal)
                o.str(c.userAgent); o.str(c.referer); o.str(c.seriesName)
                o.writeShort(c.season); o.writeShort(c.episode)
            }
        }
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) { tmp.copyTo(target, true); tmp.delete() }
    }

    private fun readBin(file: File): List<Channel> {
        java.io.DataInputStream(java.io.BufferedInputStream(file.inputStream(), 1 shl 16)).use { i ->
            if (i.readInt() != BIN_MAGIC) throw IOException("formato antigo")
            val buf = ByteArray(4096)
            val ng = i.readInt()
            val groups = Array(ng) { i.str(buf) ?: "Sem categoria" }
            val types = ContentType.values()
            val n = i.readInt()
            val out = ArrayList<Channel>(n)
            val pool = HashMap<String, String>() // séries/logos repetidos usam o mesmo texto (menos memória)
            repeat(n) {
                val name = i.str(buf) ?: ""
                val url = i.str(buf) ?: ""
                val logo = i.str(buf)?.let { pool.getOrPut(it) { it } }
                val group = groups[i.readInt()]
                val type = types[i.readByte().toInt()]
                val ua = i.str(buf); val ref = i.str(buf)
                val sName = i.str(buf)?.let { pool.getOrPut(it) { it } }
                val season = i.readShort().toInt(); val ep = i.readShort().toInt()
                out.add(Channel(name, url, logo, group, type, null, ua, ref, sName, season, ep))
            }
            return out
        }
    }

    private fun open(address: String): HttpURLConnection {
        var url = URL(address)
        repeat(7) {
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 180_000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", DEFAULT_UA)
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Encoding", "gzip")
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank()) throw IOException("Redirecionamento inválido do servidor.")
                url = URL(url, loc)
                return@repeat
            }
            if (code != 200) {
                conn.disconnect()
                throw IOException(
                    when (code) {
                        401, 403 -> "Acesso negado pelo servidor (código $code). Confira usuário e senha."
                        404 -> "Endereço da lista não encontrado (404)."
                        else -> "O servidor respondeu com erro $code."
                    }
                )
            }
            return conn
        }
        throw IOException("Muitos redirecionamentos.")
    }

    private fun download(address: String, target: File) {
        val conn = open(address)
        val tmp = File(target.parentFile, target.name + ".tmp")
        val raw = conn.inputStream
        // Lista compactada (gzip) chega até 10x mais rápido
        val input = if ("gzip".equals(conn.contentEncoding, true)) java.util.zip.GZIPInputStream(raw, 1 shl 16) else raw
        input.use { inp -> tmp.outputStream().buffered(1 shl 16).use { inp.copyTo(it, 1 shl 16) } }
        conn.disconnect()
        validate(tmp)
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) { tmp.copyTo(target, true); tmp.delete() }
    }

    private fun validate(file: File) {
        val head = file.inputStream().use { s ->
            val buf = ByteArray(4096)
            val n = s.read(buf)
            if (n <= 0) "" else String(buf, 0, n, Charsets.UTF_8)
        }
        if (!head.contains("#EXTM3U", true) && !head.contains("#EXTINF", true)) {
            file.delete()
            throw IOException("O servidor não devolveu uma lista M3U. Confira os dados de acesso.")
        }
    }

    private fun index(list: List<Channel>) {
        val live = LinkedHashMap<String, MutableList<Channel>>()
        val movies = LinkedHashMap<String, MutableList<Channel>>()
        val seriesEpisodes = LinkedHashMap<String, MutableList<Channel>>()   // nome -> episódios
        val seriesCategory = HashMap<String, String>()

        for (c in list) {
            when (c.type) {
                ContentType.LIVE -> live.getOrPut(c.group) { ArrayList() }.add(c)
                ContentType.MOVIE -> movies.getOrPut(c.group) { ArrayList() }.add(c)
                ContentType.SERIES -> {
                    val name = c.seriesName ?: c.name
                    seriesEpisodes.getOrPut(name) { ArrayList() }.add(c)
                    seriesCategory.putIfAbsent(name, c.group)
                }
            }
        }

        val sGroups = LinkedHashMap<String, MutableList<SeriesGroup>>()
        val sByName = HashMap<String, SeriesGroup>()
        for ((name, eps) in seriesEpisodes) {
            val sorted = eps.sortedWith(compareBy<Channel>({ it.season }, { it.episode }))
            val sg = SeriesGroup(
                name = name,
                group = seriesCategory[name] ?: "Séries",
                logo = eps.firstNotNullOfOrNull { it.logo },
                episodes = sorted
            )
            sGroups.getOrPut(sg.group) { ArrayList() }.add(sg)
            sByName[name] = sg
        }

        all = list
        searchIndex = null
        liveGroups = live
        movieGroups = movies
        seriesGroups = sGroups
        seriesByName = sByName
    }

    // ---------- Consultas usadas pelas telas ----------

    fun categories(type: ContentType): List<String> = when (type) {
        ContentType.LIVE -> liveGroups.keys.toList()
        ContentType.MOVIE -> movieGroups.keys.toList()
        ContentType.SERIES -> seriesGroups.keys.toList()
    }

    fun count(type: ContentType): Int = when (type) {
        ContentType.LIVE -> liveGroups.values.sumOf { it.size }
        ContentType.MOVIE -> movieGroups.values.sumOf { it.size }
        ContentType.SERIES -> seriesByName.size
    }

    /** Quantidade de itens de uma categoria (sem montar a lista). */
    fun categorySize(type: ContentType, category: String): Int = when (type) {
        ContentType.LIVE -> liveGroups[category]?.size ?: 0
        ContentType.MOVIE -> movieGroups[category]?.size ?: 0
        ContentType.SERIES -> seriesGroups[category]?.size ?: 0
    }

    /** Total visível (sem as categorias adultas quando bloqueadas). */
    fun visibleCount(type: ContentType, hideAdult: Boolean): Int =
        categories(type).filter { !hideAdult || !isAdult(it) }.sumOf { categorySize(type, it) }

    fun tiles(type: ContentType, category: String): List<Tile> = when (type) {
        ContentType.LIVE -> liveGroups[category].orEmpty().map { it.toTile() }
        ContentType.MOVIE -> movieGroups[category].orEmpty().map { it.toTile() }
        ContentType.SERIES -> seriesGroups[category].orEmpty().map { it.toTile() }
    }

    fun allTiles(type: ContentType, hideAdult: Boolean): List<Tile> = categories(type)
        .filter { !hideAdult || !isAdult(it) }
        .flatMap { tiles(type, it) }

    fun series(name: String): SeriesGroup? = seriesByName[name]

    /**
     * Converte chaves salvas (favoritos/recentes) de volta em itens, numa única passada pela lista.
     * Não guardamos um índice por endereço: em listas grandes ele ocuparia dezenas de MB na TV Box.
     */
    fun tilesForKeys(keys: List<String>): List<Tile> {
        if (keys.isEmpty()) return emptyList()
        val found = HashMap<String, Tile>(keys.size * 2)
        val wanted = HashSet<String>(keys.size * 2)
        for (k in keys) {
            if (k.startsWith("series:")) series(k.removePrefix("series:"))?.let { found[k] = it.toTile() }
            else wanted.add(k)
        }
        if (wanted.isNotEmpty()) {
            for (c in all) {
                if (c.url in wanted) { found[c.url] = c.toTile(); wanted.remove(c.url); if (wanted.isEmpty()) break }
            }
        }
        return keys.mapNotNull { found[it] }
    }

    /** Últimos filmes da lista (normalmente os lançamentos ficam no fim). */
    fun latestMovies(limit: Int, hideAdult: Boolean): List<Tile> {
        val out = ArrayList<Tile>(limit)
        for (entry in movieGroups.entries.reversed()) {
            if (hideAdult && isAdult(entry.key)) continue
            val l = entry.value
            for (i in l.indices.reversed()) { out.add(l[i].toTile()); if (out.size >= limit) return out }
        }
        return out
    }

    fun latestSeries(limit: Int, hideAdult: Boolean): List<Tile> {
        val out = ArrayList<Tile>(limit)
        for (entry in seriesGroups.entries.reversed()) {
            if (hideAdult && isAdult(entry.key)) continue
            val l = entry.value
            for (i in l.indices.reversed()) { out.add(l[i].toTile()); if (out.size >= limit) return out }
        }
        return out
    }

    /** Índice da busca: montado uma vez (na primeira busca) e reaproveitado. */
    @Volatile private var searchIndex: Pair<Array<Tile>, Array<String>>? = null
    @Volatile private var searchIndexAdult: Boolean? = null

    private fun searchIndexFor(hideAdult: Boolean): Pair<Array<Tile>, Array<String>> {
        val cur = searchIndex
        if (cur != null && searchIndexAdult == hideAdult) return cur
        val tiles = ArrayList<Tile>(all.size)
        for (type in listOf(ContentType.LIVE, ContentType.MOVIE, ContentType.SERIES)) tiles.addAll(allTiles(type, hideAdult))
        val arr = tiles.toTypedArray()
        val keys = Array(arr.size) { normalize(arr[it].title) }
        val built = arr to keys
        searchIndex = built
        searchIndexAdult = hideAdult
        return built
    }

    fun search(query: String, hideAdult: Boolean, limit: Int = 300): List<Tile> {
        val q = normalize(query.trim())
        if (q.length < 2) return emptyList()
        val (tiles, keys) = searchIndexFor(hideAdult)
        val out = ArrayList<Tile>()
        for (i in keys.indices) {
            if (keys[i].contains(q)) {
                out.add(tiles[i])
                if (out.size >= limit) break
            }
        }
        return out
    }

    /** Minúsculas e sem acento, sem expressões regulares (rápido em TV Box). */
    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val c = ch.lowercaseChar()
            sb.append(
                when (c) {
                    'á', 'à', 'â', 'ã', 'ä', 'å' -> 'a'
                    'é', 'è', 'ê', 'ë' -> 'e'
                    'í', 'ì', 'î', 'ï' -> 'i'
                    'ó', 'ò', 'ô', 'õ', 'ö' -> 'o'
                    'ú', 'ù', 'û', 'ü' -> 'u'
                    'ç' -> 'c'
                    'ñ' -> 'n'
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    private fun Channel.toTile() = Tile(title = name, logo = logo, channel = this)
    private fun SeriesGroup.toTile() = Tile(title = name, logo = logo, series = this)
}
