package br.com.vetorplayonline.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.text.InputFilter
import android.text.InputType
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.Channel
import br.com.vetorplayonline.app.data.ContentType
import br.com.vetorplayonline.app.data.PlaylistRepository
import br.com.vetorplayonline.app.data.Tile
import coil.load
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

/** Estado da sessão (some quando o app é fechado). */
object Session {
    var adultUnlocked = false
    val hideAdult: Boolean get() = VetorApp.prefs.adultLock && !adultUnlocked
}

/** ImageView que mantém a proporção (1.0 = quadrado, 1.5 = pôster). */
class RatioImageView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {
    var ratio: Float = 1f
        set(v) { field = v; requestLayout() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (w * ratio).toInt()
        super.onMeasure(
            MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
        )
    }
}

/** Efeito de foco para controle remoto (Android TV / TV Box). */
fun View.tvFocusEffect(card: MaterialCardView? = this as? MaterialCardView) {
    val yellow = ContextCompat.getColor(context, R.color.vetor_yellow)
    val border = ContextCompat.getColor(context, R.color.card_stroke)
    onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
        v.animate().scaleX(if (hasFocus) 1.06f else 1f).scaleY(if (hasFocus) 1.06f else 1f)
            .setDuration(120).start()
        card?.strokeColor = if (hasFocus) yellow else border
        card?.strokeWidth = if (hasFocus) context.dp(2) else context.dp(1)
        v.elevation = if (hasFocus) context.dp(8).toFloat() else 0f
    }
}

// ------------------------------------------------------------------------------------
// Grade de canais / filmes / séries
// ------------------------------------------------------------------------------------
class TileAdapter(
    private val poster: Boolean,
    private val horizontal: Boolean = false,
    private val onClick: (Tile, List<Tile>) -> Unit,
    private val onLongClick: (Tile) -> Unit
) : RecyclerView.Adapter<TileAdapter.VH>() {

    private var items: List<Tile> = emptyList()

    fun submit(list: List<Tile>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: MaterialCardView = v as MaterialCardView
        val image: RatioImageView = v.findViewById(R.id.tileImage)
        val title: TextView = v.findViewById(R.id.tileTitle)
        val fav: ImageView = v.findViewById(R.id.tileFav)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_tile, parent, false)
        val tv = DeviceUi.useWideLayout(parent.context)
        if (horizontal) {
            v.layoutParams = v.layoutParams.apply {
                width = parent.context.dp(
                    when {
                        tv && poster -> 150
                        tv -> 175
                        poster -> 118
                        else -> 130
                    }
                )
            }
        }
        if (tv) v.findViewById<TextView>(R.id.tileTitle).textSize = 14f
        v.tvFocusEffect()
        return VH(v)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val t = items[position]
        h.title.text = t.title
        h.image.ratio = if (poster) 1.5f else 0.75f
        h.image.scaleType = if (poster) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        val pad = if (poster) 0 else h.itemView.context.dp(10)
        h.image.setPadding(pad, pad, pad, pad)
        h.image.load(t.logo) {
            placeholder(R.drawable.ic_tile_placeholder)
            error(R.drawable.ic_tile_placeholder)
            fallback(R.drawable.ic_tile_placeholder)
        }
        h.fav.visibility = if (VetorApp.prefs.isFavorite(t.key)) View.VISIBLE else View.GONE
        h.itemView.setOnClickListener { onClick(t, items) }
        h.itemView.setOnLongClickListener {
            onLongClick(t)
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos)
            true
        }
    }
}

// ------------------------------------------------------------------------------------
// Faixa de categorias (chips)
// ------------------------------------------------------------------------------------
class CategoryAdapter(
    private val itemLayout: Int = R.layout.item_category,
    private val onFocusSelect: Boolean = false,
    private val onSelect: (Int, String) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    private var items: List<String> = emptyList()
    private var labels: List<String> = emptyList()
    var selected = 0
        private set

    fun submit(values: List<String>, display: List<String> = values, selectedIndex: Int = 0) {
        items = values
        labels = display
        selected = selectedIndex
        notifyDataSetChanged()
    }

    fun select(index: Int) {
        val old = selected
        selected = index
        notifyItemChanged(old)
        notifyItemChanged(index)
    }

    override fun getItemCount() = items.size

    /** Celular: selecionada = amarela. TV: com foco = amarela; selecionada sem foco = amarelo escuro. */
    private fun applyColors(tv: TextView, selected: Boolean, focused: Boolean) {
        val ctx = tv.context
        val (bg, fg) = when {
            focused -> R.color.vetor_yellow to R.color.vetor_black
            selected && onFocusSelect -> R.color.sel_dim to R.color.vetor_yellow
            selected -> R.color.vetor_yellow to R.color.vetor_black
            else -> R.color.surface_2 to R.color.text_primary
        }
        tv.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, bg))
        tv.setTextColor(ContextCompat.getColor(ctx, fg))
    }

    class VH(val text: TextView) : RecyclerView.ViewHolder(text)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = LayoutInflater.from(parent.context).inflate(itemLayout, parent, false) as TextView
        if (!onFocusSelect) tv.tvFocusEffect(null)
        return VH(tv)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val ctx = h.text.context
        h.text.text = labels[position]
        val isSel = position == selected
        h.text.isSelected = isSel
        applyColors(h.text, isSel, h.text.hasFocus())
        h.text.setOnClickListener {
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onSelect(pos, items[pos])
        }
        if (onFocusSelect) {
            // TV: ao passar o foco pela categoria, ela abre sozinha (sem precisar apertar OK)
            h.text.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                if (hasFocus) {
                    applyColors(v as TextView, h.bindingAdapterPosition == selected, true)
                    v.removeCallbacks(v.getTag(R.id.categories) as? Runnable)
                    val r = Runnable {
                        val pos = h.bindingAdapterPosition
                        if (v.hasFocus() && pos != RecyclerView.NO_POSITION && pos != selected &&
                            !(PlaylistRepository.isAdult(items[pos]) && Session.hideAdult)
                        ) onSelect(pos, items[pos])
                    }
                    v.setTag(R.id.categories, r)
                    v.postDelayed(r, 450)
                } else {
                    applyColors(v as TextView, h.bindingAdapterPosition == selected, false)
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------
// Navegação: abrir canal, filme, série ou episódio
// ------------------------------------------------------------------------------------
object Nav {

    fun open(activity: Activity, tile: Tile, context: List<Tile>) {
        val series = tile.series
        if (series != null) {
            activity.startActivity(
                Intent(activity, SeriesActivity::class.java).putExtra(SeriesActivity.EXTRA_NAME, series.name)
            )
            return
        }
        val ch = tile.channel ?: return
        when (ch.type) {
            ContentType.LIVE -> {
                val queue = context.mapNotNull { it.channel }.filter { it.type == ContentType.LIVE }
                play(activity, queue.ifEmpty { listOf(ch) }, queue.indexOf(ch).coerceAtLeast(0))
            }
            ContentType.MOVIE -> play(activity, listOf(ch), 0)
            ContentType.SERIES -> {
                val eps = ch.seriesName?.let { PlaylistRepository.series(it)?.episodes } ?: listOf(ch)
                play(activity, eps, eps.indexOf(ch).coerceAtLeast(0))
            }
        }
    }

    fun play(activity: Activity, queue: List<Channel>, index: Int) {
        if (queue.isEmpty()) return
        PlayerQueue.set(queue, index)
        activity.startActivity(Intent(activity, PlayerActivity::class.java))
    }

    fun toggleFavorite(ctx: Context, tile: Tile) {
        val added = VetorApp.prefs.toggleFavorite(tile.key)
        ctx.toast(if (added) "★ Adicionado aos favoritos" else "Removido dos favoritos")
    }
}

// ------------------------------------------------------------------------------------
// PIN do controle dos pais
// ------------------------------------------------------------------------------------
object PinDialog {

    private fun pinField(ctx: Context, hint: String) = EditText(ctx).apply {
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        filters = arrayOf(InputFilter.LengthFilter(8))
        gravity = Gravity.CENTER
        textSize = 22f
    }

    private fun wrap(ctx: Context, vararg views: View): View =
        android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            val p = ctx.dp(24)
            setPadding(p, ctx.dp(8), p, 0)
            views.forEach { addView(it) }
        }

    fun ask(ctx: Context, title: String, onOk: () -> Unit) {
        val field = pinField(ctx, "PIN")
        MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setMessage("Digite o PIN do controle dos pais (padrão: 0000)")
            .setView(wrap(ctx, field))
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("OK") { _, _ ->
                if (field.text.toString() == VetorApp.prefs.pin) onOk() else ctx.toast("PIN incorreto")
            }
            .show()
        field.requestFocus()
    }

    fun change(ctx: Context) {
        val old = pinField(ctx, "PIN atual")
        val new1 = pinField(ctx, "Novo PIN (4 a 8 números)")
        val new2 = pinField(ctx, "Repita o novo PIN")
        MaterialAlertDialogBuilder(ctx)
            .setTitle("Alterar PIN")
            .setView(wrap(ctx, old, new1, new2))
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar") { _, _ ->
                val n = new1.text.toString()
                when {
                    old.text.toString() != VetorApp.prefs.pin -> ctx.toast("PIN atual incorreto")
                    n.length < 4 -> ctx.toast("O PIN precisa ter pelo menos 4 números")
                    n != new2.text.toString() -> ctx.toast("Os PINs não conferem")
                    else -> { VetorApp.prefs.pin = n; ctx.toast("PIN alterado") }
                }
            }
            .show()
    }
}

// ------------------------------------------------------------------------------------
// Lista de categorias (celular): nome, quantidade e seta
// ------------------------------------------------------------------------------------
data class CategoryRow(val key: String, val label: String, val count: Int, val icon: Int, val locked: Boolean)

class CategoryListAdapter(
    private val onClick: (CategoryRow) -> Unit
) : RecyclerView.Adapter<CategoryListAdapter.VH>() {

    private var items: List<CategoryRow> = emptyList()

    fun submit(list: List<CategoryRow>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.crIcon)
        val name: TextView = v.findViewById(R.id.crName)
        val count: TextView = v.findViewById(R.id.crCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_category_row, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        h.name.text = r.label
        h.icon.setImageResource(if (r.locked) R.drawable.ic_lock else r.icon)
        h.count.text = if (r.locked) "PIN" else r.count.toString()
        h.itemView.setOnClickListener { onClick(r) }
    }
}
