package br.com.vetorplayonline.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.ContentType
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var nav: NavigationBarView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DeviceUi.lockPhonePortrait(this)
        if (!Loader.ensureLoaded(this)) return
        setContentView(if (DeviceUi.useWideLayout(this)) R.layout.activity_main_tv else R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        nav = findViewById(R.id.bottomNav)
        val wide = DeviceUi.useWideLayout(this)
        if (wide) {
            // TV / TV Box: Buscar, Atualizar e Configurações ficam no menu da esquerda,
            // onde o controle remoto chega fácil (os ícones do topo não recebem o foco do controle)
            nav.menu.add(0, R.id.action_search, 10, "Buscar").setIcon(R.drawable.ic_search)
            nav.menu.add(0, R.id.action_refresh, 11, "Atualizar").setIcon(R.drawable.ic_refresh)
            nav.menu.add(0, R.id.action_settings, 12, "Configurações").setIcon(R.drawable.ic_settings)
        }
        nav.setOnItemSelectedListener { item ->
            if (item.itemId == R.id.action_search || item.itemId == R.id.action_refresh || item.itemId == R.id.action_settings) {
                onOptionsItemSelected(item)
                return@setOnItemSelectedListener false
            }
            // TV / TV Box: "TV ao Vivo" abre a tela de canais em 4 colunas (tela cheia)
            if (item.itemId == R.id.nav_live && DeviceUi.useWideLayout(this)) {
                startActivity(Intent(this, LiveTvActivity::class.java))
                false
            } else {
                show(item.itemId)
                true
            }
        }
        if (savedInstanceState == null) {
            show(R.id.nav_home)
            Updater.check(this, manual = false)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (nav.selectedItemId != R.id.nav_home) {
                    nav.selectedItemId = R.id.nav_home
                } else {
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle("Sair do Vetor Play Online?")
                        .setNegativeButton("Não", null)
                        .setPositiveButton("Sair") { _, _ -> finishAffinity() }
                        .show()
                }
            }
        })
    }

    fun goTo(itemId: Int) { nav.selectedItemId = itemId }

    private fun show(itemId: Int) {
        val tag = "tab_$itemId"
        val fm = supportFragmentManager
        val tx = fm.beginTransaction()
        fm.fragments.forEach { if (it.tag?.startsWith("tab_") == true) tx.hide(it) }
        var f: Fragment? = fm.findFragmentByTag(tag)
        if (f == null) {
            f = when (itemId) {
                R.id.nav_live -> CatalogFragment.newInstance(ContentType.LIVE)
                R.id.nav_movies -> CatalogFragment.newInstance(ContentType.MOVIE)
                R.id.nav_series -> CatalogFragment.newInstance(ContentType.SERIES)
                else -> HomeFragment()
            }
            tx.add(R.id.container, f, tag)
        } else {
            tx.show(f)
        }
        tx.commitAllowingStateLoss()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Na TV esses botões já estão no menu da esquerda
        if (DeviceUi.useWideLayout(this)) return false
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    /** Botão "Menu" ou "Configurações" do controle remoto abre as Configurações. */
    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_MENU || keyCode == android.view.KeyEvent.KEYCODE_SETTINGS) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_search -> { startActivity(Intent(this, SearchActivity::class.java)); true }
        R.id.action_refresh -> { refresh(); true }
        R.id.action_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
        else -> super.onOptionsItemSelected(item)
    }

    private fun refresh() {
        val pl = VetorApp.prefs.active() ?: return
        Loader.load(this, pl, force = pl.kind != "file") { total ->
            toast("Lista atualizada: $total itens")
            recreateTabs()
        }
    }

    /** Recria as abas depois de trocar ou atualizar a lista. */
    fun recreateTabs() {
        val fm = supportFragmentManager
        val tx = fm.beginTransaction()
        fm.fragments.forEach { tx.remove(it) }
        tx.commitNowAllowingStateLoss()
        show(nav.selectedItemId)
    }

    override fun onResume() {
        super.onResume()
        Updater.resumePending(this)
    }

    override fun onRestart() {
        super.onRestart()
        // Pode ter trocado de lista nas configurações
        if (!Loader.ensureLoaded(this)) return
        val loaded = br.com.vetorplayonline.app.data.PlaylistRepository.loadedPlaylistId
        if (loaded != lastPlaylistId) recreateTabs()
        lastPlaylistId = loaded
    }

    private var lastPlaylistId: String? = br.com.vetorplayonline.app.data.PlaylistRepository.loadedPlaylistId
}
