package br.com.vetorplayonline.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.ContentType
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var nav: NavigationBarView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DeviceUi.lockPhonePortrait(this)
        if (!Loader.ensureLoaded(this)) return
        setContentView(if (DeviceUi.useWideLayout(this)) R.layout.activity_main_tv else R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        nav = findViewById(R.id.bottomNav)
        nav.setOnItemSelectedListener { item -> show(item.itemId); true }
        if (savedInstanceState == null) {
            show(R.id.nav_home)
            Updater.check(this, manual = false)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (nav.selectedItemId != R.id.nav_home) {
                    nav.selectedItemId = R.id.nav_home
                } else {
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle("Sair do Vetor Play Online?")
                        .setNegativeButton("Não", null)
                        .setPositiveButton("Sair") { _, _ -> finishAffinity() }
                        .show()
                }
            }
        })
    }

    fun goTo(itemId: Int) { nav.selectedItemId = itemId }

    private fun show(itemId: Int) {
        val tag = "tab_$itemId"
        val fm = supportFragmentManager
        val tx = fm.beginTransaction()
        fm.fragments.forEach { if (it.tag?.startsWith("tab_") == true) tx.hide(it) }
        var f: Fragment? = fm.findFragmentByTag(tag)
        if (f == null) {
            f = when (itemId) {
                R.id.nav_live -> CatalogFragment.newInstance(ContentType.LIVE)
                R.id.nav_movies -> CatalogFragment.newInstance(ContentType.MOVIE)
                R.id.nav_series -> CatalogFragment.newInstance(ContentType.SERIES)
                else -> HomeFragment()
            }
            tx.add(R.id.container, f, tag)
        } else {
            tx.show(f)
        }
        tx.commitAllowingStateLoss()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_search -> { startActivity(Intent(this, SearchActivity::class.java)); true }
        R.id.action_refresh -> { refresh(); true }
        R.id.action_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
        else -> super.onOptionsItemSelected(item)
    }

    private fun refresh() {
        val pl = VetorApp.prefs.active() ?: return
        Loader.load(this, pl, force = pl.kind != "file") { total ->
            toast("Lista atualizada: $total itens")
            recreateTabs()
        }
    }

    /** Recria as abas depois de trocar ou atualizar a lista. */
    fun recreateTabs() {
        val fm = supportFragmentManager
        val tx = fm.beginTransaction()
        fm.fragments.forEach { tx.remove(it) }
        tx.commitNowAllowingStateLoss()
        show(nav.selectedItemId)
    }

    override fun onResume() {
        super.onResume()
        Updater.resumePending(this)
    }

    override fun onRestart() {
        super.onRestart()
        // Pode ter trocado de lista nas configurações
        if (!Loader.ensureLoaded(this)) return
        val loaded = br.com.vetorplayonline.app.data.PlaylistRepository.loadedPlaylistId
        if (loaded != lastPlaylistId) recreateTabs()
        lastPlaylistId = loaded
    }

    private var lastPlaylistId: String? = br.com.vetorplayonline.app.data.PlaylistRepository.loadedPlaylistId
}
