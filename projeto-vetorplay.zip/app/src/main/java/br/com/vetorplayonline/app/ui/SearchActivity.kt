package br.com.vetorplayonline.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.data.PlaylistRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Busca em canais, filmes e séries ao mesmo tempo (ignora acentos). */
class SearchActivity : AppCompatActivity() {

    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DeviceUi.lockPhonePortrait(this)
        if (!Loader.ensureLoaded(this)) return
        setContentView(R.layout.activity_search)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        val input = findViewById<EditText>(R.id.searchInput)
        val info = findViewById<TextView>(R.id.searchInfo)
        val grid = findViewById<RecyclerView>(R.id.searchGrid)

        val widthDp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
        grid.layoutManager = GridLayoutManager(this, (widthDp / (if (DeviceUi.useWideLayout(this)) 150f else 112f)).toInt().coerceIn(3, 10))
        val adapter = TileAdapter(
            poster = true,
            onClick = { tile, list -> Nav.open(this, tile, list) },
            onLongClick = { tile -> Nav.toggleFavorite(this, tile) }
        )
        grid.adapter = adapter

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().trim()
                job?.cancel()
                job = lifecycleScope.launch {
                    delay(350)
                    val results = withContext(Dispatchers.Default) {
                        PlaylistRepository.search(q, Session.hideAdult)
                    }
                    adapter.submit(results)
                    info.text = when {
                        q.length < 2 -> "Digite pelo menos 2 letras"
                        results.isEmpty() -> "Nada encontrado para \"$q\""
                        else -> "${results.size} resultado(s)"
                    }
                }
            }
        })
        input.requestFocus()
    }
}
