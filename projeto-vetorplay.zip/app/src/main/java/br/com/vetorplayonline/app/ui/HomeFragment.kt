package br.com.vetorplayonline.app.ui

import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.com.vetorplayonline.app.Config
import br.com.vetorplayonline.app.R
import br.com.vetorplayonline.app.data.AccountInfo
import br.com.vetorplayonline.app.data.AccountRepository
import br.com.vetorplayonline.app.VetorApp
import br.com.vetorplayonline.app.data.ContentType
import br.com.vetorplayonline.app.data.PlaylistRepository
import br.com.vetorplayonline.app.data.Tile
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tela inicial: atalhos para TV, Filmes e Séries + fileiras de Continuar, Favoritos e Lançamentos. */
class HomeFragment : Fragment() {

    private lateinit var sections: LinearLayout

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View =
        inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        sections = view.findViewById(R.id.sections)
        val prefs = VetorApp.prefs
        view.findViewById<TextView>(R.id.homeHello).text =
            "Lista: ${prefs.active()?.name ?: "-"}"

        bindShortcut(view, R.id.cardLive, R.id.countLive, ContentType.LIVE, "canais", R.id.nav_live)
        bindShortcut(view, R.id.cardMovies, R.id.countMovies, ContentType.MOVIE, "filmes", R.id.nav_movies)
        bindShortcut(view, R.id.cardSeries, R.id.countSeries, ContentType.SERIES, "séries", R.id.nav_series)
        if (DeviceUi.useWideLayout(requireContext())) {
            // TV: cartão do sinal e jogos de hoje lado a lado
            val row = view.findViewById<LinearLayout>(R.id.topCards)
            row.orientation = LinearLayout.HORIZONTAL
            for (i in 0 until row.childCount) {
                val child = row.getChildAt(i)
                val lp = child.layoutParams as LinearLayout.LayoutParams
                lp.width = 0
                lp.weight = 1f
                child.layoutParams = lp
            }
        }
        view.findViewById<View>(R.id.cardAccount).tvFocusEffect()
        view.findViewById<View>(R.id.cardGames).apply {
            tvFocusEffect()
            setOnClickListener { (activity as? MainActivity)?.goTo(R.id.nav_games) }
        }
        view.findViewById<View>(R.id.cardLive).requestFocus()
    }

    private fun bindShortcut(root: View, cardId: Int, countId: Int, type: ContentType, noun: String, navId: Int) {
        val card = root.findViewById<View>(cardId)
        card.tvFocusEffect()
        card.setOnClickListener { (activity as? MainActivity)?.goTo(navId) }
        root.findViewById<TextView>(countId).text = "${PlaylistRepository.count(type)} $noun"
    }

    override fun onResume() {
        super.onResume()
        buildRows()
        refreshAccount()
    }

    // ---------------------------------------------------------------------------------
    // Vencimento do sinal
    // ---------------------------------------------------------------------------------
    private fun refreshAccount() {
        val v = view ?: return
        val pl = VetorApp.prefs.active() ?: return
        val card = v.findViewById<View>(R.id.cardAccount)
        if (!AccountRepository.supports(pl)) { card.visibility = View.GONE; return }
        val cached = VetorApp.prefs.account(pl.id)
        cached?.let { showAccount(it, fromCache = true) }
        // consulta o painel no máximo a cada 10 minutos
        if (cached != null && System.currentTimeMillis() - cached.checkedAt < 10 * 60_000) return
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val info = AccountRepository.fetch(pl) ?: return@launch
                VetorApp.prefs.saveAccount(pl.id, info)
                showAccount(info, fromCache = false)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // sem internet: fica o último valor salvo
            }
        }
    }

    private fun showAccount(info: AccountInfo, fromCache: Boolean) {
        val v = view ?: return
        val ctx = requireContext()
        val card = v.findViewById<MaterialCardView>(R.id.cardAccount)
        val title = v.findViewById<TextView>(R.id.accTitle)
        val detail = v.findViewById<TextView>(R.id.accDetail)
        val badge = v.findViewById<TextView>(R.id.accBadge)
        card.visibility = View.VISIBLE
        val fmt = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        val exp = info.expiresAt
        val days = info.daysLeft
        val color: Int
        when {
            exp == null && !info.isExpired -> {
                title.text = "Sem data de vencimento"
                badge.text = "ATIVO"
                color = R.color.live_green
            }
            info.isExpired -> {
                title.text = if (exp != null) "Venceu em ${fmt.format(Date(exp))}" else "Sinal vencido"
                badge.text = "VENCIDO"
                color = R.color.alert_red
            }
            else -> {
                title.text = "Vence em ${fmt.format(Date(exp!!))}"
                badge.text = when (days) {
                    0L -> "HOJE"
                    1L -> "1 dia"
                    else -> "$days dias"
                }
                color = if ((days ?: 99) <= 5) R.color.alert_red
                else if ((days ?: 99) <= 10) R.color.vetor_orange else R.color.live_green
            }
        }
        badge.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, color))
        card.strokeColor = ContextCompat.getColor(ctx, if (color == R.color.live_green) R.color.card_stroke else color)
        val conns = if (info.maxConnections.isNotBlank()) "Telas: ${info.activeConnections.ifBlank { "0" }}/${info.maxConnections}" else ""
        val renew = if (info.isExpired || (days != null && days <= 10)) "Renove para não ficar sem sinal" else ""
        detail.text = listOf(renew, conns).filter { it.isNotBlank() }.joinToString("  •  ")
            .ifBlank { if (fromCache) "Última consulta salva" else "Atualizado agora" }
        detail.visibility = View.VISIBLE
        card.setOnClickListener {
            if (Config.WHATSAPP_SUPORTE.isNotBlank()) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${Config.WHATSAPP_SUPORTE}?text=" +
                        Uri.encode("Olá! Quero renovar meu sinal da Vetor Play Online."))))
                } catch (e: Exception) { ctx.toast("WhatsApp: ${Config.WHATSAPP_SUPORTE}") }
            } else {
                VetorApp.prefs.active()?.let { p ->
                    VetorApp.prefs.account(p.id)?.let { a -> VetorApp.prefs.saveAccount(p.id, a.copy(checkedAt = 0)) }
                }
                refreshAccount()
            }
        }
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden && view != null) buildRows()
    }

    private var rowsJob: kotlinx.coroutines.Job? = null

    private fun buildRows() {
        rowsJob?.cancel()
        rowsJob = viewLifecycleOwner.lifecycleScope.launch {
            val rows = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                val prefs = VetorApp.prefs
                val hide = Session.hideAdult
                fun visible(t: Tile): Boolean {
                    if (!hide) return true
                    val g = t.series?.group ?: t.channel?.group ?: return true
                    return !PlaylistRepository.isAdult(g)
                }
                listOf(
                    Triple("Continuar assistindo", prefs.recents().mapNotNull { PlaylistRepository.tileForKey(it) }.filter(::visible), false),
                    Triple("Meus favoritos", prefs.favorites().mapNotNull { PlaylistRepository.tileForKey(it) }.filter(::visible), false),
                    Triple("Filmes adicionados recentemente", PlaylistRepository.latestMovies(30, hide), true),
                    Triple("Séries adicionadas recentemente", PlaylistRepository.latestSeries(30, hide), true)
                )
            }
            sections.removeAllViews()
            rows.forEach { (label, tiles, poster) -> addRow(label, tiles, poster) }
        }
    }

    private fun addRow(label: String, tiles: List<Tile>, poster: Boolean) {
        if (tiles.isEmpty()) return
        val row = layoutInflater.inflate(R.layout.item_section, sections, false)
        row.findViewById<TextView>(R.id.sectionTitle).text = label
        val rv = row.findViewById<RecyclerView>(R.id.sectionList)
        rv.layoutManager = LinearLayoutManager(requireContext(), RecyclerView.HORIZONTAL, false)
        val adapter = TileAdapter(
            poster = poster,
            horizontal = true,
            onClick = { tile, list -> Nav.open(requireActivity(), tile, list) },
            onLongClick = { tile -> Nav.toggleFavorite(requireContext(), tile) }
        )
        rv.adapter = adapter
        adapter.submit(tiles)
        sections.addView(row)
    }
}
