package br.com.vetorplayonline.app.data

import java.io.BufferedReader

/**
 * Leitor de listas M3U / M3U8 (formato #EXTINF, inclusive m3u_plus do Xtream Codes).
 * Lê linha a linha, então aguenta listas com centenas de milhares de itens.
 */
object M3uParser {

    private val attrRegex = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")
    private val episodeRegex = Regex("(?i)\\bS(\\d{1,2})\\s*[ ._-]?\\s*E(\\d{1,3})\\b")
    private val seriesGroupRegex = Regex("(?i)(s[ée]rie|series|novela|temporada|anime|desenho)")
    private val movieGroupRegex = Regex("(?i)(filme|movie|vod|cinema|lan[çc]amento|4k uhd|legendado|dublado)")
    private val liveHintRegex = Regex("(?i)(24\\s?h|24 horas|ao vivo|canais|tv\\b|live)")
    private val vodExtensions = listOf(".mp4", ".mkv", ".avi", ".mov", ".wmv", ".m4v", ".flv")

    fun parse(reader: BufferedReader): List<Channel> {
        val out = ArrayList<Channel>(8192)
        var info: String? = null
        var userAgent: String? = null
        var referer: String? = null
        var groupOverride: String? = null

        while (true) {
            val raw = reader.readLine() ?: break
            val line = raw.trim().removePrefix("﻿")
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    info = line
                    userAgent = null
                    referer = null
                    groupOverride = null
                }
                line.startsWith("#EXTVLCOPT", ignoreCase = true) -> {
                    val opt = line.substringAfter(':')
                    val value = opt.substringAfter('=').trim()
                    when {
                        opt.startsWith("http-user-agent", true) -> userAgent = value
                        opt.startsWith("http-referrer", true) || opt.startsWith("http-referer", true) -> referer = value
                    }
                }
                line.startsWith("#EXTGRP", ignoreCase = true) -> groupOverride = line.substringAfter(':').trim()
                line.startsWith("#") -> Unit
                else -> {
                    val header = info
                    if (header != null) {
                        out.add(build(header, line, userAgent, referer, groupOverride))
                    } else if (line.contains("://")) {
                        // URL sem #EXTINF: adiciona assim mesmo
                        out.add(build("#EXTINF:-1,${line.substringAfterLast('/')}", line, null, null, null))
                    }
                    info = null
                }
            }
        }
        return out
    }

    private fun build(
        header: String,
        url: String,
        userAgent: String?,
        referer: String?,
        groupOverride: String?
    ): Channel {
        val attrs = HashMap<String, String>()
        attrRegex.findAll(header).forEach { attrs[it.groupValues[1].lowercase()] = it.groupValues[2].trim() }

        val name = titleFrom(header).ifBlank { attrs["tvg-name"].orEmpty() }.ifBlank { url.substringAfterLast('/') }
        val group = (groupOverride ?: attrs["group-title"]).orEmpty().ifBlank { "Sem categoria" }
        val logo = attrs["tvg-logo"]?.takeIf { it.startsWith("http") }
        val type = detectType(url, group, name)

        var seriesName: String? = null
        var season = 0
        var episode = 0
        if (type == ContentType.SERIES) {
            val m = episodeRegex.find(name)
            if (m != null) {
                season = m.groupValues[1].toIntOrNull() ?: 0
                episode = m.groupValues[2].toIntOrNull() ?: 0
                seriesName = name.substring(0, m.range.first).trim().trimEnd('-', '|', ':', '.', '(', '[').trim()
            }
            if (seriesName.isNullOrBlank()) seriesName = name
        }

        return Channel(
            name = name,
            url = url,
            logo = logo,
            group = group,
            type = type,
            epgId = attrs["tvg-id"]?.takeIf { it.isNotBlank() },
            userAgent = userAgent ?: attrs["user-agent"],
            referer = referer,
            seriesName = seriesName,
            season = season,
            episode = episode
        )
    }

    /** O título fica depois da primeira vírgula que não está entre aspas. */
    private fun titleFrom(header: String): String {
        var inQuotes = false
        for (i in header.indices) {
            val c = header[i]
            if (c == '"') inQuotes = !inQuotes
            else if (c == ',' && !inQuotes) return header.substring(i + 1).trim()
        }
        return ""
    }

    private fun detectType(url: String, group: String, name: String): ContentType {
        val u = url.lowercase()
        return when {
            "/series/" in u -> ContentType.SERIES
            "/movie/" in u -> ContentType.MOVIE
            "/live/" in u -> ContentType.LIVE
            liveHintRegex.containsMatchIn(group) && !episodeRegex.containsMatchIn(name) -> ContentType.LIVE
            episodeRegex.containsMatchIn(name) -> ContentType.SERIES
            seriesGroupRegex.containsMatchIn(group) -> ContentType.SERIES
            movieGroupRegex.containsMatchIn(group) -> ContentType.MOVIE
            vodExtensions.any { u.substringBefore('?').endsWith(it) } -> ContentType.MOVIE
            else -> ContentType.LIVE
        }
    }
}
