package br.com.vetorplayonline.app.data

import java.io.BufferedReader

/**
 * Leitor de listas M3U / M3U8 (formato #EXTINF, inclusive m3u_plus do Xtream Codes).
 * Feito para ser rápido em listas enormes (centenas de milhares de linhas):
 * - lê os atributos tvg-* / group-title sem expressões regulares;
 * - descobre o tipo (TV, filme, série) pelo endereço (/live/, /movie/, /series/) antes de tudo;
 * - guarda o resultado por categoria, para não repetir o mesmo cálculo em cada canal.
 */
object M3uParser {

    private val episodeRegex = Regex("(?i)\\bS(\\d{1,2})\\s*[ ._-]?\\s*E(\\d{1,3})\\b")
    private val seriesGroupRegex = Regex("(?i)(s[ée]rie|series|novela|temporada|anime|desenho)")
    private val movieGroupRegex = Regex("(?i)(filme|movie|vod|cinema|lan[çc]amento|4k uhd|legendado|dublado)")
    private val liveHintRegex = Regex("(?i)(24\\s?h|24 horas|ao vivo|canais|tv\\b|live)")
    private val vodExtensions = arrayOf(".mp4", ".mkv", ".avi", ".mov", ".wmv", ".m4v", ".flv")

    fun parse(reader: BufferedReader): List<Channel> {
        val out = ArrayList<Channel>(16384)
        val groupPool = HashMap<String, String>()              // reaproveita o mesmo texto da categoria
        val groupHint = HashMap<String, ContentType?>()       // tipo sugerido pelo nome da categoria
        var info: String? = null
        var userAgent: String? = null
        var referer: String? = null
        var groupOverride: String? = null

        while (true) {
            val raw = reader.readLine() ?: break
            if (raw.isEmpty()) continue
            val line = if (raw[0] == '﻿' || raw[0] == ' ' || raw.last() == ' ' || raw.last() == '\r') raw.trim().removePrefix("﻿") else raw
            if (line.isEmpty()) continue
            if (line[0] == '#') {
                when {
                    line.startsWith("#EXTINF", ignoreCase = true) -> {
                        info = line; userAgent = null; referer = null; groupOverride = null
                    }
                    line.startsWith("#EXTVLCOPT", ignoreCase = true) -> {
                        val opt = line.substringAfter(':')
                        val value = opt.substringAfter('=').trim()
                        if (opt.startsWith("http-user-agent", true)) userAgent = value
                        else if (opt.startsWith("http-referrer", true) || opt.startsWith("http-referer", true)) referer = value
                    }
                    line.startsWith("#EXTGRP", ignoreCase = true) -> groupOverride = line.substringAfter(':').trim()
                }
                continue
            }
            val header = info
            if (header != null) {
                out.add(build(header, line, userAgent, referer, groupOverride, groupPool, groupHint))
            } else if (line.contains("://")) {
                out.add(build("#EXTINF:-1,${line.substringAfterLast('/')}", line, null, null, null, groupPool, groupHint))
            }
            info = null
        }
        out.trimToSize()
        return out
    }

    /** Lê os atributos key="valor" e o título (depois da primeira vírgula fora de aspas). */
    private class Extinf(val logo: String?, val group: String?, val tvgName: String?, val tvgId: String?, val ua: String?, val title: String)

    private fun readExtinf(h: String): Extinf {
        var logo: String? = null; var group: String? = null; var tvgName: String? = null
        var tvgId: String? = null; var ua: String? = null
        var i = h.indexOf(':').let { if (it < 0) 0 else it + 1 }
        val n = h.length
        var title = ""
        while (i < n) {
            val c = h[i]
            if (c == ',') { title = h.substring(i + 1).trim(); break }
            if (c == '=' && i + 1 < n && h[i + 1] == '"') {
                // nome do atributo: volta até o espaço anterior
                var s = i - 1
                while (s >= 0 && h[s] != ' ' && h[s] != ':') s--
                val key = h.substring(s + 1, i)
                val end = h.indexOf('"', i + 2).let { if (it < 0) n else it }
                val value = h.substring(i + 2, end).trim()
                when {
                    key.equals("tvg-logo", true) -> logo = value
                    key.equals("group-title", true) -> group = value
                    key.equals("tvg-name", true) -> tvgName = value
                    key.equals("tvg-id", true) -> tvgId = value
                    key.equals("user-agent", true) -> ua = value
                }
                i = end + 1
                continue
            }
            i++
        }
        return Extinf(logo, group, tvgName, tvgId, ua, title)
    }

    private fun build(
        header: String,
        url: String,
        userAgent: String?,
        referer: String?,
        groupOverride: String?,
        groupPool: HashMap<String, String>,
        groupHint: HashMap<String, ContentType?>
    ): Channel {
        val e = readExtinf(header)
        val name = e.title.ifBlank { e.tvgName.orEmpty() }.ifBlank { url.substringAfterLast('/') }
        val groupRaw = (groupOverride ?: e.group).orEmpty().ifBlank { "Sem categoria" }
        val group = groupPool.getOrPut(groupRaw) { groupRaw }
        val logo = e.logo?.takeIf { it.startsWith("http") }
        val type = detectType(url, group, name, groupHint)

        var seriesName: String? = null
        var season = 0
        var episode = 0
        if (type == ContentType.SERIES) {
            val m = episodeRegex.find(name)
            if (m != null) {
                season = m.groupValues[1].toIntOrNull() ?: 0
                episode = m.groupValues[2].toIntOrNull() ?: 0
                seriesName = name.substring(0, m.range.first).trim().trimEnd('-', '|', ':', '.', '(', '[').trim()
            }
            if (seriesName.isNullOrBlank()) seriesName = name
        }

        return Channel(
            name = name,
            url = url,
            logo = logo,
            group = group,
            type = type,
            epgId = e.tvgId?.takeIf { it.isNotBlank() },
            userAgent = userAgent ?: e.ua,
            referer = referer,
            seriesName = seriesName,
            season = season,
            episode = episode
        )
    }

    private fun detectType(url: String, group: String, name: String, groupHint: HashMap<String, ContentType?>): ContentType {
        // 1) Pelo endereço (listas Xtream): o mais rápido e o mais confiável
        if (url.contains("/series/", true)) return ContentType.SERIES
        if (url.contains("/movie/", true)) return ContentType.MOVIE
        if (url.contains("/live/", true)) return ContentType.LIVE

        // 2) Pelo nome da categoria (calculado uma vez por categoria)
        val hint = if (groupHint.containsKey(group)) groupHint[group] else {
            val h = when {
                liveHintRegex.containsMatchIn(group) -> ContentType.LIVE
                seriesGroupRegex.containsMatchIn(group) -> ContentType.SERIES
                movieGroupRegex.containsMatchIn(group) -> ContentType.MOVIE
                else -> null
            }
            groupHint[group] = h
            h
        }
        val looksEpisode = name.length > 4 && episodeRegex.containsMatchIn(name)
        if (looksEpisode) return ContentType.SERIES
        if (hint != null) return hint

        // 3) Pela extensão do arquivo
        val path = url.substringBefore('?')
        for (ext in vodExtensions) if (path.endsWith(ext, true)) return ContentType.MOVIE
        return ContentType.LIVE
    }
}
