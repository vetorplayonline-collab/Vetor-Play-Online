plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.vetorplayonline.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "br.com.vetorplayonline.app"
        minSdk = 21
        targetSdk = 34
        // Cada APK gerado pelo GitHub ganha um número novo, então instala por cima da versão anterior
        val runNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionCode = runNumber
        versionName = "1.0.$runNumber"
        multiDexEnabled = true
    }

    // Chave fixa da Vetor Play Online (vem do GitHub, guardada como segredo do repositório).
    // Sempre a MESMA chave: é isso que permite instalar uma versão nova por cima da antiga.
    val keystorePath = System.getenv("VETOR_KEYSTORE")
    signingConfigs {
        create("vetor") {
            if (keystorePath != null && file(keystorePath).exists()) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("VETOR_KEYSTORE_PASS")
                keyAlias = "vetorplay"
                keyPassword = System.getenv("VETOR_KEYSTORE_PASS")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (keystorePath != null && file(keystorePath).exists())
                signingConfigs.getByName("vetor") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-ui:$media3")

    implementation("androidx.annotation:annotation-experimental:1.4.1")
    implementation("io.coil-kt:coil:2.6.0")
}
