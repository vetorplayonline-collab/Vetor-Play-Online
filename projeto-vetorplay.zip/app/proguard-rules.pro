# Mantém as classes do próprio app (são poucas e referenciadas pelo Android)
-keep class br.com.vetorplayonline.app.** { *; }

# Bibliotecas usadas pelo Coil/OkHttp que podem não existir no aparelho
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**
-dontwarn kotlinx.coroutines.debug.**

# Remove logs de depuração do Android na versão final
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
}
