﻿# Publicar APK - Vetor Play Online
# Envia o projeto para o GitHub, espera o APK ser gerado e salva o VetorPlayOnline.apk nesta pasta.
# (Mensagens sem acento de proposito, para aparecerem certas em qualquer Windows.)

$Repo = 'vetorplayonline-collab/Vetor-Play-Online'   # usuario/repositorio no GitHub
$Workflow = 'build-apk.yml'

$ErrorActionPreference = 'Continue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Step($t) { Write-Host ''; Write-Host "=== $t ===" -ForegroundColor Yellow }
function Fail($t) { Write-Host ''; Write-Host "ERRO: $t" -ForegroundColor Red; Write-Host 'Tire um print desta tela e envie ao Claude.'; exit 1 }

function Find-Gh {
  $c = Get-Command gh -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  foreach ($p in @("$env:ProgramFiles\GitHub CLI\gh.exe", "${env:ProgramFiles(x86)}\GitHub CLI\gh.exe", "$env:LOCALAPPDATA\Programs\GitHub CLI\gh.exe")) {
    if ($p -and (Test-Path $p)) { return $p }
  }
  return $null
}

# 1) GitHub CLI
Step 'Conferindo o GitHub CLI'
$gh = Find-Gh
if (-not $gh) {
  Write-Host 'Instalando o GitHub CLI (so na primeira vez)...'
  winget install --id GitHub.cli -e --silent --accept-source-agreements --accept-package-agreements
  $gh = Find-Gh
  if (-not $gh) { Fail 'Nao consegui instalar o GitHub CLI. Instale em https://cli.github.com e rode de novo.' }
}
Write-Host "OK: $gh"

# 2) Login
Step 'Login no GitHub'
& $gh auth status -h github.com *> $null
if ($LASTEXITCODE -ne 0) {
  Write-Host 'Vai abrir o navegador: copie o codigo que aparece aqui e confirme no GitHub.'
  & $gh auth login -h github.com -p https -w
  # O gh pode reclamar de nao achar o Git no fim, mesmo com o login feito: confere de novo
  & $gh auth status -h github.com *> $null
  if ($LASTEXITCODE -ne 0) { Fail 'Login no GitHub nao foi concluido.' }
}
Write-Host 'OK: conectado.'

# 2b) Chave de assinatura (sempre a mesma, para o app atualizar por cima)
Step 'Conferindo a chave de assinatura'
$KeyDir = Join-Path (Split-Path -Parent $Root) 'VetorPlayOnline-CHAVE'
$KeyFile = Join-Path $KeyDir 'vetorplay.jks'
$PassFile = Join-Path $KeyDir 'senha.txt'
if ((Test-Path $KeyFile) -and (Test-Path $PassFile)) {
  # Tem a chave no computador: envia para o GitHub (rapido) usando --body, sem quebras de linha extras
  $b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($KeyFile))
  & $gh secret set VETOR_KEYSTORE_B64 -R $Repo --body $b64
  if ($LASTEXITCODE -ne 0) { Fail 'Nao consegui cadastrar a chave no GitHub.' }
  $pass = (Get-Content $PassFile -Raw).Trim()
  & $gh secret set VETOR_KEYSTORE_PASS -R $Repo --body $pass
  if ($LASTEXITCODE -ne 0) { Fail 'Nao consegui cadastrar a senha da chave no GitHub.' }
} else {
  # Sem a chave no computador: usa a que ja esta guardada no GitHub (continua sendo a MESMA chave)
  $secrets = (& $gh secret list -R $Repo) -join "`n"
  if ($LASTEXITCODE -ne 0 -or $secrets -notmatch 'VETOR_KEYSTORE_B64' -or $secrets -notmatch 'VETOR_KEYSTORE_PASS') {
    Fail "Nao achei a chave em $KeyDir nem guardada no GitHub. Sem ela o app nao atualiza por cima. Fale com o Claude antes de continuar."
  }
  Write-Host 'Chave nao esta no computador, mas esta guardada no GitHub. Usando a do GitHub.'
}
Write-Host 'OK: chave conferida no GitHub.'

# 3) Compactar o projeto
Step 'Compactando o projeto'
$zip = Join-Path $env:TEMP 'projeto-vetorplay.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
# Compacta com caminhos e permissoes no formato que o GitHub (Linux) entende
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$skipDirs = @('.gradle', 'build', '.idea', 'saida', '.git')
$files = Get-ChildItem -Path $Root -Recurse -File -Force | Where-Object {
  $rel = $_.FullName.Substring($Root.Length).TrimStart('\')
  $parts = $rel.Split('\')
  -not ($parts | Where-Object { $skipDirs -contains $_ }) -and
  $_.Extension -ne '.apk' -and $_.Name -ne 'local.properties'
}
$fs = [IO.File]::Open($zip, [IO.FileMode]::Create)
$za = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
foreach ($f in $files) {
  $rel = $f.FullName.Substring($Root.Length).TrimStart('\').Replace('\', '/')
  $entry = $za.CreateEntry($rel, [IO.Compression.CompressionLevel]::Optimal)
  try {
    if ($f.Name -eq 'gradlew') { $entry.ExternalAttributes = 0x81ED -shl 16 }   # rwxr-xr-x
    else { $entry.ExternalAttributes = 0x81A4 -shl 16 }                        # rw-r--r--
  } catch { }
  $in = [IO.File]::OpenRead($f.FullName)
  $out = $entry.Open()
  $in.CopyTo($out)
  $out.Dispose(); $in.Dispose()
}
$za.Dispose(); $fs.Dispose()
if (-not (Test-Path $zip)) { Fail 'Nao consegui compactar o projeto.' }
Write-Host ('OK: {0:N1} MB' -f ((Get-Item $zip).Length / 1MB))

# 4) Enviar para o GitHub
Step 'Enviando para o GitHub'
$sha = (& $gh api "repos/$Repo/contents/projeto-vetorplay.zip" --jq '.sha' 2> $null)
$body = @{
  message = 'Atualiza projeto ' + (Get-Date -Format 'dd/MM/yyyy HH:mm')
  content = [Convert]::ToBase64String([IO.File]::ReadAllBytes($zip))
  branch  = 'main'
}
if ($LASTEXITCODE -eq 0 -and $sha) { $body.sha = "$sha".Trim() }
$bodyFile = Join-Path $env:TEMP 'vetor-publicar.json'
($body | ConvertTo-Json -Compress) | Set-Content -Path $bodyFile -Encoding ASCII
$commit = (& $gh api -X PUT "repos/$Repo/contents/projeto-vetorplay.zip" --input $bodyFile --jq '.commit.sha')
Remove-Item $bodyFile -Force -ErrorAction SilentlyContinue
if ($LASTEXITCODE -ne 0 -or -not $commit) { Fail 'O GitHub recusou o envio do projeto.' }
$commit = "$commit".Trim()
Write-Host "OK: enviado (commit $($commit.Substring(0,7)))."

# 5) Esperar o GitHub comecar a compilar
Step 'Esperando o GitHub comecar a gerar o APK'
$runId = $null
for ($i = 0; $i -lt 18 -and -not $runId; $i++) {
  Start-Sleep -Seconds 5
  $runs = (& $gh run list -R $Repo --workflow $Workflow -L 10 --json databaseId,headSha) | ConvertFrom-Json
  $match = $runs | Where-Object { $_.headSha -eq $commit } | Select-Object -First 1
  if ($match) { $runId = $match.databaseId }
}
if (-not $runId) {
  Write-Host 'Iniciando a geracao manualmente...'
  & $gh workflow run $Workflow -R $Repo --ref main
  Start-Sleep -Seconds 8
  $runs = (& $gh run list -R $Repo --workflow $Workflow -L 1 --json databaseId) | ConvertFrom-Json
  if ($runs) { $runId = $runs[0].databaseId }
}
if (-not $runId) { Fail 'O GitHub nao iniciou a geracao do APK.' }
Write-Host "OK: geracao #$runId iniciada. Leva uns 3 a 6 minutos..."

# 6) Acompanhar
Step 'Gerando o APK (pode deixar rodando)'
& $gh run watch $runId -R $Repo --exit-status --interval 15
if ($LASTEXITCODE -ne 0) {
  Write-Host ''
  Write-Host 'Ultimas linhas do erro:' -ForegroundColor Red
  & $gh run view $runId -R $Repo --log-failed | Select-Object -Last 40
  Fail 'A geracao do APK falhou.'
}

# 7) Baixar o APK
Step 'Baixando o APK'
$out = Join-Path $env:TEMP "vetor-apk-$runId"
if (Test-Path $out) { Remove-Item $out -Recurse -Force }
& $gh run download $runId -R $Repo -n 'VetorPlayOnline-apk' -D $out
$apk = Get-ChildItem -Path $out -Filter *.apk -Recurse | Select-Object -First 1
if (-not $apk) { Fail 'Nao encontrei o APK no resultado.' }
$dest = Join-Path $Root 'VetorPlayOnline.apk'
Copy-Item $apk.FullName $dest -Force

Write-Host ''
Write-Host '============================================================' -ForegroundColor Green
Write-Host ' PRONTO! APK gerado:' -ForegroundColor Green
Write-Host " $dest" -ForegroundColor Green
Write-Host '============================================================' -ForegroundColor Green
Start-Process explorer.exe "/select,`"$dest`""
