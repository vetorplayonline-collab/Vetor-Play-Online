@echo off
chcp 65001 >nul
title Publicar APK - Vetor Play Online
cd /d "%~dp0"

if not exist "app\build.gradle.kts" (
  echo ERRO: rode este arquivo de dentro da pasta do projeto VetorPlayOnline.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publicar-apk.ps1"
echo.
pause
